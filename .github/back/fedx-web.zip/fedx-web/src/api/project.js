// import service from '@/utils/service'
import service from '@/utils/poseidonRequest'
// 项目管理
export const projectApi = {
  // 校验名称是否重复
  checkName: function(params) {
    return service({
      url: '/project/name/check',
      method: 'get',
      params
    })
  },
  // 用户权限列表获取项目
  getAuthList: function(data) {
    return service({
      url: '/prosup/getProjectPermissionList',
      method: 'post',
      data
    })
  },
  // 添加项目成员
  addAuthProject: function(data) {
    return service({
      url: '/projectAuth/addAuthProject',
      method: 'post',
      data
    })
  },
  // 修改项目成员
  updateAuthProject: function(data) {
    return service({
      url: '/projectAuth/updateAuthProject',
      method: 'put',
      data
    })
  },
  // 获取项目参与方
  orgByProjectId: function(params) {
    return service({
      url: '/project/partyIdByProjectId',
      method: 'get',
      params
    })
  },
  // 获取项目资源详情
  projectResource: function() {
    return service({
      url: '/project/resource',
      method: 'get'
    })
  },
  // 工作流，模型仓库 按钮权限
  btnRole: function(params) {
    return service({
      url: '/projectManager/role',
      method: 'get',
      params
    })
  },
  // 项目类型下拉
  projectTypeList: function(params) {
    return service({
      url: '/project/projectTypeList',
      method: 'get',
      params
    })
  },
  // 获取列表
  getList: function(data) {
    return service({
      url: '/project/query',
      method: 'post',
      data
    })
  },
  // 新建项目
  add: function(data) {
    return service({
      url: '/project',
      method: 'post',
      data
    })
  },
  // 项目名称去重
  checkProjectName: function(params) {
    return service({
      url: '/projectManager/checkProjectName',
      method: 'GET',
      params
    })
  },
  // 项目详情
  getDetail: function(params) {
    return service({
      url: '/project/detail',
      method: 'GET',
      params
    })
  },
  // 编辑项目
  update: function(params) {
    return service({
      url: '/project',
      method: 'PUT',
      data: params
    })
  },
  // 删除项目
  deletePj: function(data) {
    return service({
      url: '/project/remove',
      method: 'post',
      data
    })
  },
  // 项目审核通过/拒绝
  projectAudit: function(data) {
    return service({
      url: '/proflow/audit',
      method: 'post',
      data
    })
  },
  // 获取全部用户
  getProjectUser: function(data) {
    return service({
      url: '/projectAuth/projectUser',
      method: 'post',
      data
    })
  }
}
