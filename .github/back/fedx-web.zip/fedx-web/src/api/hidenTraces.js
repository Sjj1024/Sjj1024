import flRequest from '@/utils/poseidonRequest'

// 匿踪服务查询
function queryHidenList(data) {
  return flRequest({
    url: '/pir/stealth/query',
    method: 'post',
    data
  })
}

// 创建匿踪查询
function creatHiden(data) {
  return flRequest({
    url: '/pir/stealth',
    method: 'post',
    data
  })
}

// 服务上线
function onlineHiden(data) {
  return flRequest({
    url: '/pir/stealth/online',
    method: 'post',
    data
  })
}

// 服务下线
function offlineHiden(data) {
  return flRequest({
    url: '/pir/stealth/offline',
    method: 'post',
    data
  })
}

// 服务详情
function detailHiden(params) {
  return flRequest({
    url: '/pir/stealth/detail',
    method: 'get',
    params
  })
}

// 服务调用详情
function useDetailHiden(data) {
  return flRequest({
    url: '/pir/stealth/record',
    method: 'post',
    data
  })
}

// 测试服务
function verifyHiden(data, url) {
  return flRequest({
    url: url,
    method: 'post',
    data
  })
}

// 删除匿踪查询
function delHiden(data) {
  return flRequest({
    url: '/pir/remove',
    method: 'post',
    data
  })
}

export default {
  queryHidenList,
  creatHiden,
  onlineHiden,
  offlineHiden,
  detailHiden,
  useDetailHiden,
  verifyHiden,
  delHiden
}
