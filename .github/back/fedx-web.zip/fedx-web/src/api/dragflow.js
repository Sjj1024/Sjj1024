
import service from '@/utils/poseidonRequest'
import flapi from '@/utils/flapi'
export default {
  // 算子清单列表
  getListOperator(data) {
    return service({
      url: '/workFlowOperator/list',
      method: 'post',
      data
    })
  },
  // 工作流详情获取
  getWorkFlowVersionDetail(data) {
    return flapi({
      url: '/v1/workFlowVersion/detail',
      method: 'post',
      data
    })
  },
  // 组件参数获取
  // getWorkFlowComponentConfig(data) {
  //   return service({
  //     url: '/component/params/list',
  //     method: 'post',
  //     data
  //   })
  // },
  // 组件参数修改
  // updateWorkFlowComponentConfig(data) {
  //   return service({
  //     url: '/component/params/update',
  //     method: 'post',
  //     data
  //   })
  // },
  // 画板数据保存
  saveWorkFlow(data) {
    return service({
      url: '/workflow/workFlowJsonUpdate',
      method: 'post',
      data
    })
  }
}

