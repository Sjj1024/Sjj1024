import service from '@/utils/poseidonRequest'
// sso登录
export function ssologin() {
  return service({
    url: '/sso/toSso',
    method: 'get'
  })
}

export function isSpdb() {
  return service({
    url: '/module/get',
    method: 'get'
  })
}
export function login(data) {
  return service({
    url: '/login',
    method: 'post',
    data
  })
}
export function vertyCode() {
  return service({
    url: '/login/img',
    method: 'get'
  })
}
// 根据token获取用户信息
export function getuserInfo(data) {
  const token = decodeURI(`${data.data}`)
  // console.log('data', token)
  return service({
    url: '/users/userinfo',
    headers: {
      'Authorization': token
    },
    method: 'get'
  })
}

export function haveSelfOrg(params) {
  return service({
    url: '/organization/haveSelfOrg',
    method: 'get',
    params
  })
}

export function logout() {
  return service({
    url: '/login/logout',
    method: 'post'
  })
}
// 用户管理列表接口
export function newUserList(data) {
  return service({
    url: '/users/userList',
    method: 'post',
    data
  })
}
export function resetpwd(data) {
  return service({
    url: '/users/resetpwd',
    method: 'post',
    data
  })
}

// 修改密码接口
export function updatePwd(data) {
  return service({
    url: '/user/updatePassword',
    method: 'post',
    data
  })
}
// 修改信息接口
export function updateInfo(data) {
  return service({
    url: '/user/updateUserInfo',
    method: 'post',
    data
  })
}
// 更新项目角色
export function updateProjectRole(data) {
  return service({
    url: '/user/updateProjectRole',
    method: 'post',
    data
  })
}
// 当前用户的现有权限
export function getProjectRoleList(data) {
  return service({
    url: '/prosup/getProjectRoleList',
    method: 'post',
    data
  })
}
