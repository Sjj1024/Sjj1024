import poseidonRequest from '@/utils/poseidonRequest'
// 数据集
export const dataSetApi = {
  // 获取数据集合详情
  getDatasetDetail: function(data) {
    return poseidonRequest({
      url: '/v1/dataset/detail',
      method: 'post',
      data
    })
  },
  // 根据命名空间获取表列表
  getlistByNamespaceId: function(data) {
    return poseidonRequest({
      url: '/v1/dataset/listByNamespaceId',
      method: 'post',
      data
    })
  },
  // 命名空间列表
  getNamespaceList: function() {
    return poseidonRequest({
      url: '/v1/dataset/namespaceList',
      method: 'post'
    })
  },
  // 联邦学习类型列表
  getRalMlTypeList: function() {
    return poseidonRequest({
      url: '/v1/workFlow/federalMlTypeList',
      method: 'post'
    })
  },
  // 模版列表
  getFlowTemplateList: function(data) {
    return poseidonRequest({
      url: '/v1/workFlowTemplate/listByType',
      method: 'post',
      data
    })
  }
}

// 工作流
export const workFlowApi = {
  // 校验名称是否重复
  checkName: function(params) {
    return poseidonRequest({
      url: '/workflow/name/check',
      method: 'get',
      params
    })
  },
  resourceInfo: function(params) {
    return poseidonRequest({
      url: '/workflow/resource',
      method: 'get',
      params
    })
  },
  federalMlTypeList: function(params) {
    return poseidonRequest({
      url: '/workflow/federalMlTypeList',
      method: 'get',
      params
    })
  },
  delWorkFlow: function(params) {
    return poseidonRequest({
      url: '/workflow/delete',
      method: 'get',
      params
    })
  },
  // 工作流模版删除
  workFlowTemplateDlete: function(data) {
    return poseidonRequest({
      url: '/workFlowTemplate/delete',
      method: 'post',
      data
    })
  },
  // 工作流更新
  workFlowTemplateUpdate: function(data) {
    return poseidonRequest({
      url: '/workFlowTemplate/update',
      method: 'post',
      data
    })
  },
  // 工作流模版保存
  workFlowTemplateSave: function(data) {
    return poseidonRequest({
      url: '/workFlowTemplate',
      method: 'post',
      data
    })
  },
  // 工作流模版详情
  workFlowTemplateDetail: function(params) {
    return poseidonRequest({
      url: '/workFlowTemplate/detail',
      method: 'get',
      params
    })
  },
  newPredictedInfo: function(params) {
    return poseidonRequest({
      url: '/workflow/newPredictedInfo',
      method: 'get',
      params
    })
  },
  // 工作流模版list
  workFlowTemplateList: function(data) {
    return poseidonRequest({
      url: '/workFlowTemplate/list',
      method: 'post',
      data
    })
  },
  // 列表
  getList: function(data) {
    return poseidonRequest({
      url: '/workflow/query',
      method: 'post',
      data
    })
  },
  // 新建
  add: function(data) {
    return poseidonRequest({
      url: '/v1/workFlow/add',
      method: 'post',
      data
    })
  },
  // 保存数据集
  save: function(data) {
    return poseidonRequest({
      url: '/workFlowTemplate/update',
      method: 'post',
      data
    })
  },
  // 新建加确定按钮
  saveNew: function(data) {
    return poseidonRequest({
      url: '/workflow/add',
      method: 'post',
      data
    })
  },
  // 获取工作流详情
  getSingleDetail: function(params) {
    return poseidonRequest({
      url: '/workflow',
      method: 'get',
      params
    })
  },
  // 获取工作流参数json
  getConfigJson: function(data) {
    return poseidonRequest({
      url: '/v1/workFlowVersion/getConfigJson',
      method: 'post',
      data
    })
  },
  // 保存工作流参数json
  saveConfigJson: function(data) {
    return poseidonRequest({
      url: '/workflow/workFlowJsonUpdate',
      method: 'post',
      data
    })
  },
  // 运行
  run: function(data) {
    return poseidonRequest({
      url: '/workflow/run',
      method: 'post',
      data
    })
  },
  // 添加工作流版本
  versionAdd: function(data) {
    return poseidonRequest({
      url: '/workflow/version/add',
      method: 'post',
      data
    })
  },
  // 工作流版本查询
  versionQuery: function(data) {
    return poseidonRequest({
      url: '/workflow/version/query',
      method: 'post',
      data
    })
  },
  // 工作流版本删除
  versionDelete: function(data) {
    return poseidonRequest({
      url: '/workflow/version/delete',
      method: 'post',
      data
    })
  },
  // 工作流版本详情
  versionDetail: function(params) {
    return poseidonRequest({
      url: '/workflow/version/detail',
      method: 'get',
      params
    })
  }
}

// 历史记录
export const historyApi = {
  getList: function(data) {
    return poseidonRequest({
      url: '/v1/workFlowVersion/jobHistory',
      method: 'post',
      data
    })
  }
}

// 调参
export const paramsApi = {
  getParams: function(data) {
    return poseidonRequest({
      url: '/v1/algorithmUnit/param',
      method: 'post',
      data
    })
  }
}

// 模型仓库
export const modelApi = {
  // 校验名称是否重复
  checkName: function(params) {
    return poseidonRequest({
      url: '/model/name/check',
      method: 'get',
      params
    })
  },
  // 求交算子 psi 输出数据保存到hdfs是否显示
  psiOutputIsEnable: function(params) {
    return poseidonRequest({
      url: '/fedxJob/psi/isOpen',
      method: 'get',
      params
    })
  },
  // 求交算子 输出数据保存到 hdfs
  psiUploadJob: function(data) {
    return poseidonRequest({
      url: '/fedxJob/create/psiUploadJob',
      method: 'post',
      data
    })
  },
  // 输出数据保存
  outputDataSave: function(data) {
    return poseidonRequest({
      url: '/v1/tracking/component/output/saveData',
      method: 'post',
      data
    })
  },
  // 输出数据保存到hdfs是否显示
  outputIsEnable: function(params) {
    return poseidonRequest({
      url: '/v1/tracking/isEnable',
      method: 'get',
      params
    })
  },
  // 日志保存
  loggerSave: function(params) {
    return poseidonRequest({
      url: '/auditlog/loggerSave',
      method: 'get',
      params
    })
  },
  // 是否显示 审计日志保存按钮
  isEnable: function(params) {
    return poseidonRequest({
      url: '/auditlog/isEnable',
      method: 'get',
      params
    })
  },
  // 下载模型
  exportModel: function(params) {
    return poseidonRequest({
      url: '/model/exportModel',
      method: 'get',
      params
    })
  },
  // 下载模型new
  export: function(params) {
    return poseidonRequest({
      url: '/model/export',
      method: 'get',
      responseType: 'blob',
      params
    })
  },
  // 模型上传
  importModel: function(data) {
    return poseidonRequest({
      url: '/model/importModel',
      method: 'post',
      cancelToken: data.cancelToken,
      headers: {
        'Content-Type': 'multipart/form-data'
      },
      data: data.formData
    })
  },
  // 模型上传new
  import: function(data) {
    return poseidonRequest({
      url: '/model/import',
      method: 'post',
      cancelToken: data.cancelToken,
      headers: {
        'Content-Type': 'multipart/form-data'
      },
      data: data.formData
    })
  },

  // 模型部署
  deployModel: function(data) {
    return poseidonRequest({
      url: '/model/deploy',
      method: 'post',
      cancelToken: data.cancelToken,
      data: data
    })
  },
  // 模型部署new
  deployImportModel: function(data) {
    return poseidonRequest({
      url: '/model/import/deploy',
      method: 'post',
      cancelToken: data.cancelToken,
      data: data
    })
  },
  // 发布为模型
  flowToModel: function(data) {
    return poseidonRequest({
      url: '/model/deploy',
      method: 'post',
      data
    })
  },
  // 删除模型
  deleteModel: function(data) {
    return poseidonRequest({
      url: '/model/remove',
      method: 'post',
      data
    })
  },
  // 更新模型
  updateModel: function(data) {
    return poseidonRequest({
      url: '/v1/model/updateModel',
      method: 'post',
      data
    })
  },
  // 模型组下的模型列表
  getGoroupModelList: function(data) {
    return poseidonRequest({
      url: '/v1/model/listByModelGroup',
      method: 'post',
      data
    })
  },
  // 模型列表
  getList: function(data) {
    return poseidonRequest({
      url: '/model/list',
      method: 'post',
      data
    })
  },
  // 模型详情
  getModelDetail: function(data) {
    return poseidonRequest({
      url: '/v1/model/detail',
      method: 'post',
      data
    })
  },
  // 下载模型批量预测结果
  batchPredictDownload: function(data) {
    return poseidonRequest({
      url: '/v1/model/batchPredictDownload',
      method: 'post',
      data
    })
  },
  // 批量预测结果列表
  batchPredictResults: function(data) {
    return poseidonRequest({
      url: '/v1/model/batchPredictResults',
      method: 'post',
      data
    })
  },
  // 模型批量预测
  batchPredict: function(data) {
    return poseidonRequest({
      url: '/model/predict',
      method: 'post',
      data
    })
  }
}
