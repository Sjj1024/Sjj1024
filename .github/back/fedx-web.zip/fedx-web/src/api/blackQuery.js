// import flRequest from '@/utils/poseidonRequest'

function queryBlackList(data) {
  // console.log(data)
  // return flRequest({
  //   url: '/task/query',
  //   method: 'post',
  //   data
  // })
  return {
    'data': {
      'total': 2,
      'list': [
        {
          'id': '202210260554073094160',
          'serviceName': '服务名称',
          'partnerName': '合作机构名称',
          'dataName': '数据集',
          'useColumns': '使用列',
          'serviceState': '运行中',
          'createPerson': '创建人',
          'createTime': '2022-10-26 13:54:08',
          'editTime': '',
          'action': '上下线'
        },
        {
          'id': '202210260554073094240',
          'serviceName': '服务名称',
          'partnerName': '合作机构名称',
          'dataName': '数据集',
          'useColumns': '使用列',
          'serviceState': '运行中',
          'createPerson': '创建人',
          'createTime': '2022-10-26 13:54:08',
          'editTime': '2022-10-26 13:54:08',
          'action': '上下线'
        }
      ],
      'pageNum': 1,
      'pageSize': 10
    },
    'retmsg': 'success',
    'retcode': 0
  }
}

export default {
  queryBlackList
}
