import service from '@/utils/poseidonRequest'

export default {
  // 创建
  creat(data) {
    return service({
      url: '/mpc/add',
      method: 'post',
      data
    })
  },
  // 查询
  query(data) {
    return service({
      url: '/mpc/query',
      method: 'post',
      data
    })
  },
  // 详情
  detail(data) {
    return service({
      url: '/mpc/detail',
      method: 'post',
      data
    })
  },
  // 重试
  retry(data) {
    return service({
      url: '/mpc/retry',
      method: 'post',
      data
    })
  },
  // 取消
  cancel(data) {
    return service({
      url: '/mpc/cancel',
      method: 'post',
      data
    })
  },
  // 删除
  remove(data) {
    return service({
      url: '/mpc/remove',
      method: 'post',
      data
    })
  },
  // 下载日志
  download(params) {
    return service({
      url: `/mpc/log/download`,
      method: 'get',
      responseType: 'blob',
      params
    })
  },
  // 下载结果
  downLoadRes(params) {
    return service({
      url: `/mpc/result/download`,
      method: 'get',
      responseType: 'blob',
      params
    })
  }
}
