import service from '@/utils/poseidonRequest'

export default {
  // 修改密码
  resetUserPwd(data) {
    return service({
      url: '/users/resetUserPwd',
      method: 'post',
      data
    })
  },
  // 姓名校验
  checkName(params) {
    return service({
      url: '/users/name/check',
      method: 'get',
      params
    })
  },
  // 用户（菜单权限查看）
  hasSysAdm(data) {
    return service({
      url: `/menu/hasSysAdm/${data}`,
      method: 'get'
    })
  },
  // 用户名去重
  unameUniq(data) {
    return service({
      url: `/user/checkUserName/${data}`,
      method: 'get'
    })
  },
  list(data) {
    return service({
      url: '/user/page',
      method: 'get',
      data
    })
  },
  add(data) {
    return service({
      url: '/users/signup',
      method: 'post',
      data
    })
  },
  userinfo(data) {
    return service({
      url: '/users/userinfo',
      method: 'get',
      data
    })
  },
  roleList(data) {
    return service({
      url: '/role/rolelist',
      method: 'post',
      data
    })
  },
  changePassword(data) {
    return service({
      url: '/v1/user/update',
      method: 'post',
      data
    })
  },
  deleteUser(data) {
    return service({
      url: '/users/delete',
      method: 'post',
      data
    })
  },
  updateInfo(data) {
    return service({
      url: '/user/update',
      method: 'post',
      data
    })
  },
  // 证书解绑
  unbind(data) {
    return service({
      url: '/license/unbind',
      method: 'post',
      data
    })
  },
  // 证书有效的token列表
  tokenList(params) {
    return service({
      url: '/license/tokenList',
      method: 'get',
      params
    })
  }
}

