import flRequest from '@/utils/poseidonRequest'

// 隐匿求交列表
function queryHidenList(data) {
  return flRequest({
    url: '/psi/queryList',
    method: 'post',
    data
  })
}

// 创建隐匿求交
function creatHidenSubmission(data) {
  return flRequest({
    url: '/psi/add',
    method: 'post',
    data
  })
}

// 获取隐匿求交详情
function getDetail(data) {
  return flRequest({
    url: '/psi/detail',
    method: 'post',
    data
  })
}

// 取消
function killJob(data) {
  return flRequest({
    url: '/psi/v1/pipeline/job/stop',
    method: 'post',
    data
  })
}

// 重试
function retryJob(data) {
  return flRequest({
    url: '/psi/v1/rerun',
    method: 'post',
    data
  })
}

// 结果下载
function downloadRes(params) {
  return flRequest({
    url: '/psi/jobData/download',
    method: 'get',
    responseType: 'blob',
    params
  })
}

// 详情的输出数据tab
export function getDataOutput(params) {
  return flRequest({
    url: '/psi/jobData/show',
    method: 'get',
    params
  })
}

// 日志审计下载
function exportMission({ jobId, projectId }) {
  return flRequest({
    url: `/psi/loggerDownload?jobId=${jobId}&projectId=${projectId}`,
    method: 'get',
    responseType: 'blob'
  })
}

// 删除隐匿求交
function delHiden(data) {
  return flRequest({
    url: '/psi/remove',
    method: 'post',
    data
  })
}

// 发布结果
function publishRes(data) {
  return flRequest({
    url: '/psi/psiToDataset',
    method: 'post',
    data
  })
}

export default {
  queryHidenList,
  creatHidenSubmission,
  getDetail,
  killJob,
  retryJob,
  downloadRes,
  getDataOutput,
  exportMission,
  delHiden,
  publishRes
}
