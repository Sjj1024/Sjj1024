import service from '@/utils/poseidonRequest'

export default {
  logoAdd(data) {
    return service({
      url: '/logo/add',
      method: 'post',
      data
    })
  },
  logoQuery(data) {
    return service({
      url: '/logo/query',
      method: 'post',
      data
    })
  }
}
