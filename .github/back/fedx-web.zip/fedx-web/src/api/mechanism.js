import service from '@/utils/poseidonRequest'

export default {
  getQuery(data) {
    return service({
      url: '/party/query',
      method: 'post',
      data
    })
  },
  getAdd(data) {
    return service({
      url: '/party/add',
      method: 'post',
      data
    })
  },
  getUpdate(data) {
    return service({
      url: '/party/update',
      method: 'post',
      data
    })
  },
  getdel(data) {
    return service({
      url: '/party/delete?id=' + data.id,
      method: 'get',
      data
    })
  },
  // get 加密方式列表
  getEncryptions(params) {
    return service({
      url: '/party/encryptions',
      method: 'get',
      params
    })
  },
  getCheck(params) {
    return service({
      url: '/party/check',
      method: 'get',
      params
    })
  },
  getConnectTest(params) {
    return service({
      url: '/party/connection/test',
      method: 'get',
      params
    })
  },
  getReConnect(params) {
    return service({
      url: '/party/getPartyState',
      method: 'get',
      params
    })
  },
  queryOwnOrg(params) {
    console.log(params, 'params')
    return service({
      url: '/party/queryOwnOrg',
      method: 'get',
      params
    })
  }
}

