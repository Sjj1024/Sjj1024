import service from '@/utils/service'

export default {
  namespacelist(data) {
    return service({
      url: '/v1/dataset/namespaceList',
      method: 'post',
      data
    })
  },
  datasetlist(data) {
    return service({
      url: '/v1/dataset/listByNamespaceId',
      method: 'post',
      data
    })
  },
  detail(data) {
    return service({
      url: '/v1/dataset/detail',
      method: 'post',
      data
    })
  },
  add(data) {
    return service({
      url: '/v1/dataset/add',
      method: 'post',
      data
    })
  },
  updateBind(data) {
    return service({
      url: '/v1/dataset/changeBind',
      method: 'post',
      data
    })
  },
  getNamespaceListByOrg(data) {
    return service({
      url: '/v1/dataset/data/namespaceList',
      method: 'post',
      data
    })
  },
  getTableListByNamespace(data) {
    return service({
      url: '/v1/dataset/data/listByNamespaceId',
      method: 'post',
      data
    })
  }
}
