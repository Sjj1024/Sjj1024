import flRequest from '@/utils/poseidonRequest'

function queryMissionList(data) {
  // console.log(data)
  return flRequest({
    url: '/task/query',
    method: 'post',
    data
  })
}

function camcelMission({ jobId }) {
  return flRequest({
    url: `/task/cancel?jobId=${jobId}`,
    method: 'get'
  })
}

function rerunMission({ jobId }) {
  return flRequest({
    url: `/task/rerun?jobId=${jobId}`,
    method: 'get'
  })
}

function exportMission({ jobId, projectId }) {
  return flRequest({
    url: `/auditlog/loggerDownload?jobId=${jobId}&projectId=${projectId}`,
    method: 'get',
    responseType: 'blob'
  })
}

export default {
  queryMissionList,
  camcelMission,
  rerunMission,
  exportMission
}
