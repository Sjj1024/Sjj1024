import service from '@/utils/poseidonRequest'

export default {
  getList(data) {
    return service({
      url: '/message/list',
      method: 'post',
      data
    })
  },
  changeStatus(data) {
    return service({
      url: '/message/isReads',
      method: 'post',
      data
    })
  },
  getMsgType(params) {
    return service({
      url: '/message/messageType',
      method: 'get',
      params
    })
  },
  deleteMsg(data) {
    return service({
      url: '/message/delete',
      method: 'post',
      data
    })
  }
}
