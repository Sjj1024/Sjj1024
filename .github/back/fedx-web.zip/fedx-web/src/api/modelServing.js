import poseidonRequest from '@/utils/poseidonRequest'
import fateRequest from '@/utils/fateRequest'
import grafanaRequest from '@/utils/grafanaRequest'

export const servingApi = {
  // 校验模型服务名称是否重复
  checkName: function(params) {
    return poseidonRequest({
      url: '/model-serving/name/check',
      method: 'get',
      params
    })
  },
  delServing: function(params) {
    return poseidonRequest({
      url: '/model-serving/delete',
      method: 'get',
      params
    })
  },
  // 获取模型服务列表
  getList: function(data) {
    return poseidonRequest({
      url: '/model-serving/list',
      method: 'post',
      data
    })
  },
  // 创建服务
  createServing: function(data) {
    return poseidonRequest({
      url: '/model-serving/create',
      method: 'post',
      data
    })
  },
  // 操作服务（上线、下线、删除）
  oprateServing: function(data) {
    return poseidonRequest({
      url: '/model-serving/operate',
      method: 'post',
      data
    })
  },
  // 获取服务详情
  getDetail: function(data) {
    return poseidonRequest({
      url: '/model-serving/detail',
      method: 'get',
      params: data
    })
  },
  // 获取服务入参
  queryDataset: function(data) {
    return poseidonRequest({
      url: '/model-serving/dataset/query',
      method: 'post',
      data
    })
  },
  // 测试服务
  verifyServing: function(data) {
    return poseidonRequest({
      url: '/model-serving/verify',
      method: 'post',
      data
    })
  },
  // 获取测试服务的请求参数
  getParams: function(data) {
    return poseidonRequest({
      url: '/model-serving/demo',
      method: 'get',
      params: data
    })
  },
  // 原生模型服务平台登录
  login: function(data) {
    return fateRequest({
      url: '/admin/login',
      method: 'post',
      data
    })
  },
  // grafana监控服务平台登录
  grafanaLogin: function(data) {
    return grafanaRequest({
      url: '/login',
      method: 'post',
      data
    })
  },
  // 获取fate-serving线形图query
  getChartQuery: function(data) {
    return fateRequest({
      url: '/monitor/query',
      method: 'get',
      params: data
    })
  },
  // 获取fate-serving线形图list
  getComponentList: function(data) {
    return fateRequest({
      url: '/component/list',
      method: 'get',
      params: data
    })
  }
}
