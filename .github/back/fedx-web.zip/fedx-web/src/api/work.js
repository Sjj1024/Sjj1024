import service from '@/utils/poseidonRequest'
export default {
  //   作业添加接口
  workerList(data) {
    return service({
      url: '/fedxJob/list',
      method: 'post',
      data
    })
  },
  retry(params) {
    return service({
      url: '/fedxJob/retry',
      method: 'get',
      params
    })
  },
  bdbind(params) {
    return service({
      url: '/table/bind',
      method: 'get',
      params
    })
  },
  // 文件管理 list
  fileList(params) {
    return service({
    //   url: `/hdfs/file/list/${params.proid}/${params.page}/${params.size}`,
      url: `/hdfs/file/list/${params.proid}/${params.page}/${params.size}`,
      method: 'get'
    })
  },
  // 文件管理 上传文件到fate
  fileUploadJob(data) {
    return service({
      url: `/hdfs/file/uploadjob/${data}`,
      method: 'get'
    })
  }
}
