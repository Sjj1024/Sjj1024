import request from '@/utils/flRequest'
import poseidonRequest from '@/utils/poseidonRequest'

export default {
  // 根据工作流id 获取任务id
  getWfInfo(params) {
    return request({
      url: '/wfmanager/wfInfo',
      method: 'get',
      params
    })
  },
  // 跳转波塞冬
  goPoseidon(params) {
    return poseidonRequest({
      url: '/systemConfig/list',
      method: 'get',
      params
    })
  },
  // 获取用户信息
  userInfo(data) {
    return poseidonRequest({
      url: '/login/userInfo',
      method: 'post',
      data
    })
  },
  // 获取 当前平台（浦发or银联）
  getApsOrganizationByPartyId(data) {
    return request({
      url: '/dataset/getApsOrganizationByPartyId',
      method: 'post',
      data
    })
  },
  // 工作里校验名称重复
  checkWorkFlowName(params) {
    return request({
      url: '/modelWarehouse/checkWorkFlowName',
      method: 'get',
      params
    })
  },
  modeInfo(params) {
    return request({
      url: '/modelWarehouse/modeInfo',
      method: 'get',
      params
    })
  },
  // 获取 文件夹
  listAddDirName(params) {
    return request({
      url: '/dataset/listAddDirName',
      method: 'get',
      params
    })
  },
  // 获取 fl自由数据集
  getLisDir(data) {
    return request({
      url: '/dataset/listdir',
      method: 'post',
      data
    })
  },
  // HDFS 校验
  readHdfsFile(data) {
    return request({
      url: '/dataset/readHdfsFile',
      method: 'post',
      data
    })
  },
  // 文件夹详情
  datasetlist(data) {
    return request({
      url: '/dataset/listinfo',
      method: 'post',
      data
    })
  },
  // 自由数据集添加
  add(data) {
    return request({
      url: '/dataset/adddataset',
      method: 'post',
      data
    })
  },
  // 数据集详情
  detail(data) {
    return request({
      url: '/dataset/info',
      method: 'post',
      data
    })
  },
  // 数据集删除
  delete(params) {
    return request({
      url: '/dataset/delete',
      method: 'get',
      params
    })
  },
  // 数据集文件上传
  fileUpload(data) {
    return request({
      url: '/dataset/upload',
      method: 'post',
      cancelToken: data.cancelToken,
      headers: {
        'Content-Type': 'multipart/form-data'
      },
      data: data.formData
    })
  },
  // 数据集下拉
  namespaceList(params) {
    return request({
      url: '/modelWarehouse/namespaceList',
      method: 'get',
      params
    })
  },
  // 表名 下拉
  tableList(params) {
    return request({
      url: '/modelWarehouse/tableList',
      method: 'get',
      params
    })
  },
  // 授权机构下拉
  listOrg(params) {
    return request({
      url: '/dataset/listOrg',
      method: 'get',
      params
    })
  },
  // 跑批预测
  propHesy(data) {
    return request({
      url: '/modelWarehouse/datasetlist',
      method: 'post',
      data
    })
  }
}
