import service from '@/utils/service'

export default {
  list(data) {
    return service({
      url: '/v1/user/list',
      method: 'post',
      data
    })
  },
  add(data) {
    return service({
      url: '/v1/user/add',
      method: 'post',
      data
    })
  },
  changePassword(data) {
    return service({
      url: '/v1/user/update',
      method: 'post',
      data
    })
  },
  updateInfo(data) {
    return service({
      url: '/v1/user/update_info',
      method: 'post',
      data
    })
  }
}
