import service from '@/utils/poseidonRequest'

export default {
  creat(data) {
    return service({
      url: '/comm/create',
      method: 'post',
      data
    })
  },
  getList(data) {
    return service({
      url: '/comm/list',
      method: 'post',
      data
    })
  },
  update(data) {
    return service({
      url: '/comm/update',
      method: 'post',
      data
    })
  },
  delete(data) {
    return service({
      url: '/comm/delete',
      method: 'post',
      data
    })
  }
}
