import service from '@/utils/poseidonRequest'

export default {
  // 角色名称校验
  checkName(params) {
    return service({
      url: '/role/name/check',
      method: 'get',
      params
    })
  },
  // 英文名称校验
  checkNum(params) {
    return service({
      url: '/role/num/check',
      method: 'get',
      params
    })
  },
  // 角色列表
  getRoleList(data) {
    return service({
      url: '/role/rolelist',
      method: 'post',
      data
    })
  },
  newMenuQuery(data) {
    return service({
      url: '/newmenu/query',
      method: 'post',
      data
    })
  },
  newMenuRoleQuery(data) {
    return service({
      url: '/newmenu/role/query',
      method: 'post',
      data
    })
  },
  newMenuAdd(data) {
    return service({
      url: '/newmenu/add',
      method: 'post',
      data
    })
  },
  newMenuUpdate(data) {
    return service({
      url: '/newmenu/update',
      method: 'put',
      data
    })
  },
  newMenuRemove(params) {
    return service({
      url: '/newmenu/delete',
      method: 'delete',
      params
    })
  },
  // 添加角色
  addRole(data) {
    return service({
      url: '/role/save',
      method: 'post',
      data
    })
  },
  // 删除角色
  deleteRole(params) {
    return service({
      url: '/role/delete',
      method: 'get',
      params
    })
  }
}

