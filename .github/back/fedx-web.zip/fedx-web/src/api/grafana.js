import grafanaRequest from '@/utils/grafanaRequest'

// 登录
function grafanaLogin(data) {
  return grafanaRequest({
    url: '/login',
    method: 'post',
    data
  })
}
// 获取节点数
// function grafanaValues(data) {
//   return grafanaRequest({
//     url: '/api/datasources/proxy/1/api/v1/label/kubernetes_io_hostname/values',
//     method: 'get',
//     params: data
//   })
// }
// 获取节点数
function grafanaValues(data) {
  return grafanaRequest({
    url: '/api/datasources/proxy/1/api/v1/series',
    method: 'get',
    params: data
  })
}

// 查询数据
function grafanaSearch(data) {
  return grafanaRequest({
    url: '/api/datasources/proxy/1/api/v1/query_range',
    method: 'get',
    params: data
  })
}

export default {
  grafanaLogin,
  grafanaValues,
  grafanaSearch
}
