import request from '@/utils/poseidonRequest'
export default {
  list(data) {
    return request({
      url: '/party/query',
      method: 'post',
      data
    })
  },
  save(data) {
    return request({
      url: '/v1/org/save',
      method: 'post',
      data
    })
  },
  update(data) {
    return request({
      url: '/v1/org/update',
      method: 'post',
      data
    })
  },
  remove(data) {
    return request({
      url: '/v1/org/remove',
      method: 'post',
      data
    })
  },
  detail(data) {
    return request({
      url: '/v1/org/queryById',
      method: 'post',
      data
    })
  },
  dict(data) {
    return request({// request
    //  url: '/v1/org/dict',
      url: '/party/query',
      method: 'post',
      data
    })
  }
}
