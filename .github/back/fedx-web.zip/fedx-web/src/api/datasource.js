import service from '@/utils/poseidonRequest'

export default {
  getQuery(data) {
    return service({
      url: '/datasource/page',
      method: 'post',
      data
    })
  },
  getAdd(data) {
    return service({
      url: '/datasource',
      method: 'post',
      data
    })
  },
  getUpdate(data) {
    return service({
      url: '/datasource/update',
      method: 'post',
      data
    })
  },
  getdel(data) {
    return service({
      url: '/datasource?id=' + data.id,
      method: 'delete',
      data
    })
  },
  // get 加密方式列表
  getEncryptions(params) {
    return service({
      url: '/party/encryptions',
      method: 'get',
      params
    })
  },
  getCheck(params) {
    return service({
      url: '/party/check',
      method: 'get',
      params
    })
  },
  queryOwnOrg(params) {
    console.log(params, 'params')
    return service({
      url: '/party/queryOwnOrg',
      method: 'get',
      params
    })
  }
}

