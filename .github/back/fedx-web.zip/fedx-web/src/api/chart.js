// import request from '@/utils/request'
import flfate from '@/utils/poseidonRequest'

export function getMetrics(data) {
  return flfate({
    url: '/v1/tracking/component/metrics',
    method: 'post',
    data
  })
}
export function getMetricData(data) {
  return flfate({
    url: '/v1/tracking/component/metric_data',
    method: 'post',
    data
  })
}

export function getMetricsData(data) {
  return flfate({
    url: '/v1/tracking/component/metric_data/batch',
    method: 'post',
    data
  })
}

export function getDataOutput(data) {
  return flfate({
    url: '/v1/tracking/component/output/data',
    method: 'post',
    data
  })
}
export function getModelOutput(data) {
  return flfate({
    url: '/v1/tracking/component/output/model',
    method: 'post',
    data
  })
}

