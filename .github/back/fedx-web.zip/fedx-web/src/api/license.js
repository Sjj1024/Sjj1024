import service from '@/utils/poseidonRequest'

export default {
  // 创建
  upload(data) {
    return service({
      url: '/license/upload',
      method: 'post',
      data
    })
  },
  // 查询列表
  query(data) {
    return service({
      url: '/license/queryList',
      method: 'post',
      data
    })
  },
  // 绑定日志查询
  queryLog(tokenId) {
    return service({
      url: `/license/log?tokenId=${tokenId}`,
      method: 'get'
    })
  }
}
