import service from '@/utils/poseidonRequest'

export default {
  list(data) {
    return service({
      url: '/fedxlog/list',
      method: 'post',
      data
    })
  },
  getList(data) {
    return service({
      url: '/audit/log/list',
      method: 'post',
      data
    })
  },
  getLogType(params) {
    return service({
      url: '/audit/log/type/list',
      method: 'get',
      params
    })
  },
  selectCount(params) {
    return service({
      url: '/fedxlog/selectCount',
      method: 'get',
      params
    })
  }
}
