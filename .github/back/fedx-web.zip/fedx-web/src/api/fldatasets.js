import service from '@/utils/poseidonRequest'

export default {
  getClouType(params) {
    return service({
      url: '/dataset/columnType',
      method: 'get',
      params
    })
  },
  // 自由数据集文件夹列表
  namespacelist(params) {
    return service({
      url: '/dataset/namespaceList',
      method: 'get',
      params
    })
  },
  // 被授权数据集文件夹列表
  authnamespacelist(params) {
    return service({
      url: '/dataset/beAuthorizationFolderList',
      method: 'get',
      params
    })
  },
  //  数据集提交审核
  tjShenhe(data) {
    return service({
      url: '/datasetAudit/startAudit',
      method: 'post',
      data
    })
  },
  setapprove(data) {
    return service({
      url: '/datasetAudit/approve',
      method: 'post',
      data
    })
  },
  //  自由数据集列表
  datasetlist(params) {
    return service({
      url: '/dataset/queryList',
      method: 'post',
      data: params
    })
  },
  //  被授权数据集列表
  authdatasetlist(params) {
    return service({
      url: '/dataset/beAuthorizationList',
      method: 'get',
      params
    })
  },
  // 测试数据完整性
  checksum(params) {
    return service({
      url: '/dataset/checksum',
      method: 'get',
      params
    })
  },
  //   添加接口
  add(data) {
    return service({
      url: '/dataset/addDataset',
      method: 'post',
      data
    })
  },
  //   添加接口
  newadd(data) {
    return service({
      url: '/dataset',
      method: 'post',
      data
    })
  },
  //  数据集详情
  detail(params) {
    return service({
      url: '/dataset',
      method: 'get',
      params
    })
  },
  //  被授权数据集详情
  authdetail(params) {
    return service({
      url: '/dataset/beAuthorizationDetail',
      method: 'get',
      params
    })
  },
  //  hdfs校验
  changeHdfs(data) {
    return service({
      url: '/dataset/readHdfsFile',
      method: 'post',
      data
    })
  },
  //   csv文件上传
  fileUpload(data) {
    return service({
      url: '/dataset/upload',
      method: 'post',
      cancelToken: data.cancelToken,
      headers: {
        'Content-Type': 'multipart/form-data'
      },
      data: data.formData
    })
  },
  // 数据集审批列表
  GetdatasetAuditList(params) {
    return service({
      url: '/datasetAudit/list',
      method: 'get',
      params
    })
  },
  // 数据集审批列表post
  getAuditList(data) {
    return service({
      url: '/datasetAudit/list',
      method: 'post',
      data
    })
  },
  //   数据集删除接口
  delete(params) {
    return service({
      url: '/dataset/delete',
      method: 'get',
      params
    })
  },
  //   被授权数据集删除接口
  authdelete(params) {
    return service({
      url: '/dataset/beAuthorizationDelete',
      method: 'get',
      params
    })
  },
  //  机构下拉
  getaddorg(params) {
    return service({
      url: '/dataset/queryOrganizationList',
      method: 'post',
      params
    })
  },
  //   数据集校验接口
  checkData(params) {
    return service({
      url: '/dataset/tableNameNotExist',
      method: 'get',
      params
    })
  },
  //   JDBC链接测试
  testJdbcConnect(data) {
    return service({
      url: '/jdbcintegret/mysql',
      method: 'post',
      data
    })
  },
  //   JDBC数据库和表列表
  getJdbcDatabaseList(data) {
    return service({
      url: '/jdbcintegret/data',
      method: 'post',
      data
    })
  },
  //   hice链接测试
  testHiveConnect() {
    return service({
      url: '/hiveApi/con',
      method: 'get'
    })
  },
  //   hive 数据库列表
  getHiveDatabaseList(params) {
    return service({
      url: '/hiveApi/databases',
      method: 'get',
      params
    })
  },
  //   hive 表列表
  getHiveTableList(params) {
    return service({
      url: '/hiveApi/tables',
      method: 'get',
      params
    })
  },
  // 元数据获取
  getMetaData(data) {
    return service({
      url: '/dataset/getMetaData',
      method: 'post',
      data
    })
  },
  // 数据用途获取
  getUsageRange(params) {
    return service({
      url: '/dataset/datasetUsageRange',
      method: 'get',
      params
    })
  },
  // 获取授权显示项
  getColumnDetail(params) {
    return service({
      url: '/dataset/datasetColumnDetail',
      method: 'get',
      params
    })
  },
  // 数据集下线
  offLine(data) {
    return service({
      url: '/dataset/offline',
      method: 'post',
      data
    })
  }
}
