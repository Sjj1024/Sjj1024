/**
 *
 *  Copyright 2023.4.7,Sam Zhao. All Rights Reserved.
 *
 */
import { wrapGroupComponent } from './common'
const fn = (modelData, metricsData, partyId, role, componentName, jobId) => {
  const { data: { data: res }} = modelData
  const { names, localP, localStat } = res

  const getTable = (list, header) => {
    let obj = {}
    const arr = []
    list.map((e, i) => {
      const index = (i + 1) % header.length
      if (index || !i) {
        obj[header[index - 1]] = e === 'NaN' ? '' : e
      } else {
        obj['index'] = header[arr.length]
        obj[header[header.length - 1]] = e === 'NaN' ? '' : e
        arr.push(obj)
        obj = {}
      }
    })
    return arr
  }

  const anonyHeader = names.map((e, i) => ({
    label: e,
    prop: e,
    showOverflowTooltip: true
  }))

  const pValue = getTable(localP, names)
  const statValue = getTable(localStat, names)

  anonyHeader.splice(0, 0, {
    label: '',
    prop: 'index',
    showOverflowTooltip: true
  })

  const group = [
    {
      type: 'group',
      props: {
        options: [
          {
            type: 'form',
            props: {
              form: [{
                type: 'search',
                props: {
                  placeholder: '搜索变量'
                }
              }],
              inrow: 'left'
            }
          },
          {
            type: 'text',
            props: {
              content: '原假设：两个分类变量独立；设定显著性水平：0.05',
              className: 'medium-form-text'
            }
          },
          {
            type: 'table',
            props: {
              header: anonyHeader,
              data: pValue,
              remarks: '*p值小于等于0.05表示拒绝原假设，即两个分类变量相关；反之，则两个分类变量独立。'
            }
          },
          {
            type: 'table',
            props: {
              header: anonyHeader,
              data: statValue,
              remarks: '*stat是卡方检验统计值和卡方分布查表值得差值，大于等于0表示拒绝原假设，即两个分类变量相关；反之，则两个分类变量独立。'
            }
          }
        ]
      }
    }
  ]
  return [wrapGroupComponent(group)]
}
export default fn
