<template>
  <div id="mainApp">
    <router-view />
    <water-mark />
  </div>
</template>

<script>
import WaterMark from './components/WaterMark'
import { mapActions } from 'vuex'

export default {
  name: 'MainApp',
  components: { WaterMark },
  data: () => {
    return {
      version: 'v1.5.0',
      packageTime: '2020/10/22 20:18'
    }
  },
  mounted() {
    this.getLogoData({
      setTitle: (name, value) => {
        document.getElementById('borwser_title').innerHTML = name
        document.querySelector('link[rel="shortcut icon"]').href = value
      }
    })
  },
  methods: {
    ...mapActions('logo', ['getLogoData'])
  }
}
</script>
<style lang="scss">
#nprogress .bar {
  background: rgb(31, 118, 119) !important; //自定义颜色
}
#nprogress .spinner {
  display: none !important;
}
</style>
