<template>
  <div id="userLayout" class="user-layout-wrapper">
    <div class="container">
      <div class="user-layout-content">
        <div class="main">
          <slot />
        </div>
        <div class="banner">
          <img src="../assets/login-img.png" alt="123" >
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {
  name: 'UserLayout'
}
</script>

<style scoped rel="stylesheet/scss" lang="scss">
#userLayout.user-layout-wrapper {
  height: 100vh;
  background-color: #fff;
  .container {
    width: 100%;
    min-height: 100%;
    display: flex;
    align-items: center;
    justify-content: center;
    background-position: bottom center;
    background-size: 100%;
    .user-layout-content {
      width: 1031px;
      height: 520px;
      box-sizing: border-box;
      background: #fff;
      box-shadow: 3px 4px 16px #e3e3e3;
      flex-flow: row nowrap;
      display: flex;
      .banner{
        width: 530px;
        padding: 0;
        display: flex;
        align-items: center;
        justify-content: center;
        text-align: center;
        background-image: linear-gradient(to bottom,#69c0ff,#096dd9);
        img{
          width: 360px;
        }
      }
    }
    .main{
      flex: 1;
      padding: 70px;
    }

    a {
      text-decoration: none;
    }
  }
}
</style>
