<template>
  <div style="height:100vh">
    <AppLayout @upadeslot="upadeslots">
      <div v-if="isMain && isRouterAlive" class="app-main">
        <transition name="fade-transform" mode="out-in">
          <router-view></router-view>
        </transition>
      </div>
      <div id="sub-container" style="min-width: calc(100vw - 240px);min-height: 100vh;">
        <div v-if="!isMain && isRouterAlive" id="subapp-viewport"></div>
      </div>
    </AppLayout>
  </div>
</template>

<script>
import { filterApps } from '@/qiankun/registerApp'
import { loadMicroApp } from 'qiankun'
import AppLayout from './App-Layout.vue'
import { mapGetters } from 'vuex'
import { Loading } from 'element-ui'
/**
 *
 *  Copyright 2019 The FATE Authors. All Rights Reserved.
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 *
 */

export default {
  name: 'AppMain',
  components: {
    AppLayout
  },
  data() {
    return {
      isRouterAlive: true,
      isMain: true,
      microApp: null
    }
  },
  watch: {
    $route(val) {
      this.isMainPage(val)
    }
  },
  mounted() {
    console.log(this.$route, 'lay -- out')
    this.isMainPage(this.$route)
  },
  destroyed() {
    if (this.microApp) {
      this.microApp.unmount()
      this.microApp = null
    }
  },
  // eslint-disable-next-line vue/order-in-components
  computed: {
    ...mapGetters(['isOpenMenu'])
  },
  methods: {
    upadeslots() {
      if (!this.isMain) {
        this.isMainPage(this.$route)
      }
      // this.routerAlive()
    },
    routerAlive() {
      this.isRouterAlive = false
      this.$nextTick(() => {
        this.isRouterAlive = true
      })
    },
    isMainPage(value) {
      const subApps = filterApps()
      const [sub] = subApps.filter(item =>
        value.path.startsWith(item.activeRule)
      )
      if (value.meta.moduleName !== 'undefined') {
        if (value.meta.moduleName === 'sub') {
          this.isMain = false
          const loadingInstance = Loading.service({ target: '#sub-container' })
          // eslint-disable-next-line no-unused-vars
          let timeout = null
          this.$nextTick(() => {
            if (this.microApp) {
              this.microApp.unmount()
              this.microApp = null
            }
            this.microApp = loadMicroApp(sub)
            timeout = setTimeout(() => {
              loadingInstance.close()
              timeout = null
            }, 2000)
            // console.log('我执行了 --- 888', this.microApp)
          })
        } else {
          this.isMain = true
        }
      } else {
        this.isMain = true
      }
      // console.log(this.isMain, 'this.isMain')
    }
  }
}
</script>

<style scoped>
.app-main {
  display: flex;
  flex-direction: column;
  align-items: center;
  height: calc(100vh - 49px);
  position: relative;
  overflow: auto;
  padding: 15px;
}
</style>
