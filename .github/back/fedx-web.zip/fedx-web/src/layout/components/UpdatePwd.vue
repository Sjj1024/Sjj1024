<template>
  <el-dialog
    :visible.sync="visible"
    :close-on-click-modal="false"
    :title="type === 1 ? '修改密码' : '修改信息'"
    width="510px"
    @close="closeDialog"
  >
    <el-form ref="form" :model="form" label-width="120px">
      <el-form-item label="用户名">
        {{ username }}
      </el-form-item>
      <el-form-item v-if="type === 1" :rules="[{ required: true, message: '请输入密码', trigger: 'blur' },{ min: 6, max: 16, message: '长度在 6 到 16 个字符', trigger: 'blur' },{ pattern: /^(?![a-zA-Z]+$)(?![A-Z0-9]+$)(?![A-Z\W_!@#$%^&*`~()-+=]+$)(?![a-z0-9]+$)(?![a-z\W_!@#$%^&*`~()-+=]+$)(?![0-9\W_!@#$%^&*`~()-+=]+$)[a-zA-Z0-9\W_!@#$%^&*`~()-+=]{6,16}$/, message: '密码必须是大写字母，小写字母，数字，特殊字符中的任意三种组合', trigger: 'blur' }]" label="新密码" prop="password">
        <el-input
          v-model="form.password"
          placeholder="请输入新密码"
          size="small"
          type="password"
          autocomplete="off"
          style="width: 80%"
        />
      </el-form-item>
      <el-form-item v-if="type === 1" :rules="[{ validator: validateConfirmPwd, trigger: 'blur' }]" label="再次输入新密码" prop="confirmPassword">
        <el-input
          v-model="form.confirmPassword"
          placeholder="请再次输入新密码"
          size="small"
          type="password"
          autocomplete="off"
          style="width: 80%"
        />
      </el-form-item>
      <el-form-item v-if="type === 2" label="联系方式" prop="contactInfo">
        <el-input v-model="form.contactInfo" type="tel" placeholder="请输入联系方式" size="small" style="width: 80%" />
      </el-form-item>
      <el-form-item v-if="type === 2" label="备注" prop="remarks">
        <el-input v-model="form.remarks" placeholder="请输入备注" size="small" style="width: 80%" />
      </el-form-item>
    </el-form>
    <div slot="footer" class="flex justify-right">
      <el-button size="small" @click="closeDialog">取 消</el-button>
      <el-button
        size="small"
        type="primary"
        style="margin-left: 23px;"
        @click="onSubmit"
      >确 定</el-button
      >
    </div>
  </el-dialog>
</template>

<script>
import userApi from '@/api/user'
import { mapGetters } from 'vuex'
import { doSM3 } from '@/utils/index'
export default {
  name: 'UpdatePwd',
  data() {
    return {
      type: 1,
      visible: false,
      form: {
        remarks: '',
        password: '',
        contactInfo: '',
        confirmPassword: ''
      }
    }
  },
  computed: {
    ...mapGetters(['username', 'userid', 'userinfo'])
  },
  methods: {
    show(type) {
      this.type = type
      this.visible = true
      // type 1 修改密码 2 修改信息
      if (type === 2) {
        this.form = {
          password: '',
          confirmPassword: '',
          remarks: this.userinfo.remarks || '',
          contactInfo: this.userinfo.contactInfo || ''
        }
      }
    },
    closeDialog() {
      this.visible = false
      this.form = {
        password: '',
        remarks: '',
        contactInfo: '',
        confirmPassword: ''
      }
      this.$refs.form.clearValidate()
    },
    onSubmit() {
      this.$refs.form.validate(valid => {
        if (!valid) return
        if (this.type === 1) {
          this.changePass()
        } else {
          this.changeInfo()
        }
      })
    },
    changePass() {
      const { CryptoJS, SM3Digest } = window
      const data = {
        password: doSM3(this.form.password, CryptoJS, SM3Digest),
        username: this.username,
        id: Number(this.userid)
      }
      this.$store.dispatch('UpdatePwd', data).then((res) => {
        this.$message.success('密码修改成功, 请重新登录...')
        setTimeout(() => {
          localStorage.removeItem('token')
          localStorage.removeItem('username')
          localStorage.removeItem('userid')
          this.$router.push('/login')
        }, 600)
      })
    },
    changeInfo() {
      const data = {
        id: Number(this.userid),
        remarks: this.form.remarks,
        contactInfo: this.form.contactInfo
      }
      userApi.updateInfo(data).then(() => {
        const userInfo = Object.assign(this.userinfo, {
          remarks: this.form.remarks,
          contactInfo: this.form.contactInfo
        })
        this.$message.success('信息修改成功')
        this.$store.dispatch('UpdateUserInfo', userInfo)
        localStorage.setItem('user', JSON.stringify(userInfo))
        this.closeDialog()
      })
    },
    validatePwd(rule, value, callback) {
      const passwordreg = /^(?![a-zA-Z]+$)(?![A-Z0-9]+$)(?![A-Z\W_!@#$%^&*`~()-+=]+$)(?![a-z0-9]+$)(?![a-z\W_!@#$%^&*`~()-+=]+$)(?![0-9\W_!@#$%^&*`~()-+=]+$)[a-zA-Z0-9\W_!@#$%^&*`~()-+=]{6,16}$/
      if (value === '') {
        callback(new Error('请输入新密码'))
      } else if (!passwordreg.test(value)) {
        callback(new Error('密码必须是大写字母，小写字母，数字，特殊字符中的任意三种组合'))
      } else {
        if (this.form.confirmPassword !== '') {
          this.$refs.form.validateField('confirmPassword')
        }
        callback()
      }
    },
    validateConfirmPwd(rule, value, callback) {
      if (value === '') {
        callback(new Error('请再次输入新密码'))
      } else if (value !== this.form.password) {
        callback(new Error('两次输入新密码不一致'))
      } else {
        if (value.length >= 6 && value.length <= 16) {
          callback()
        } else {
          callback(new Error('长度在 6 到 16 个字符'))
        }
      }
    }
  }
}
</script>

<style></style>
