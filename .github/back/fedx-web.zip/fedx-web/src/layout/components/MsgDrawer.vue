<template>
  <div class="custom-drawer">
    <el-drawer
      :visible="drawerVisible"
      :with-header="false"
      :modal="false"
      :modal-append-to-body="false"
      :wrapper-closable="true"
      size="400px"
      title="标题"
      @close="handleClose">
      <div class="msgWrapper">
        <div class="flex msg-head">
          <div class="msg-head-left flex">
            <div
              v-for="(item,index) in msgType"
              :key="index"
              :class="[item.active&&'active']"
              @click="activeHandler(item.text)">{{ item.text }}</div>
          </div>
          <div class="msg-head-right flex">
            <span class="total" @click="readHandler">全部标为已读</span>
            <el-dropdown @command="dropDownHandler">
              <span class="options">{{ labelText }}</span>
              <el-dropdown-menu slot="dropdown">
                <el-dropdown-item command="">
                  <p>所有分类</p>
                </el-dropdown-item>
                <el-dropdown-item v-for="item in msgTypelist" :key="item.id" :command="item.id">
                  <p>{{ item.label }}</p>
                </el-dropdown-item>
              </el-dropdown-menu>
            </el-dropdown>
          </div>
        </div>
        <ul class="msg-content">
          <li v-for="item in list" :key="item.id" @click="readMsg(item.id)">
            <div class="imgWrapper"><img :src="msgImg" alt="">
              <el-badge v-if="!item.hasRead" is-dot class="item">
                <span>{{ item.content }} <b v-if="item.remarks">（{{ item.remarks }}）</b></span>
              </el-badge>
              <span v-else>{{ item.content }}<b v-if="item.remarks">（{{ item.remarks }}）</b></span>
            </div>
            <p>你可以在<span @click.stop="openDetailPage(item)">{{ item.linkText }}</span>中查看</p>
            <div class="time">{{ item.createDate }}</div>
          </li>
        </ul>
        <div class="msg-footer flex" @click="openMsgPage">查看全部消息<span></span></div>
      </div>
    </el-drawer>
  </div>
</template>
<script>
import msgApi from '@/api/msg'
export default {
  model: {
    prop: 'drawerVisible',
    event: 'updateDrawerVisible'
  },
  props: {
    drawerVisible: {
      type: Boolean,
      default: false
    }
  },
  data() {
    return {
      // 全部/未读消息
      msgType: [
        {
          text: '全部通知',
          active: true
        },
        {
          text: '未读',
          active: false
        }
      ],
      // 消息，10条
      list: [],
      // 消息类型
      msgTypelist: [],
      // 类型文案
      labelText: '所有分类',
      // 消息详情img url
      msgImg: 'data:image/svg+xml;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiPz4KPHN2ZyB3aWR0aD0iMjhweCIgaGVpZ2h0PSIyOHB4IiB2aWV3Qm94PSIwIDAgMjggMjgiIHZlcnNpb249IjEuMSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIiB4bWxuczp4bGluaz0iaHR0cDovL3d3dy53My5vcmcvMTk5OS94bGluayI+CiAgICA8IS0tIEdlbmVyYXRvcjogU2tldGNoIDYyICg5MTM5MCkgLSBodHRwczovL3NrZXRjaC5jb20gLS0+CiAgICA8dGl0bGU+5qaC6KeIPC90aXRsZT4KICAgIDxkZXNjPkNyZWF0ZWQgd2l0aCBTa2V0Y2guPC9kZXNjPgogICAgPGcgaWQ9Iumhtemdoi0xIiBzdHJva2U9Im5vbmUiIHN0cm9rZS13aWR0aD0iMSIgZmlsbD0ibm9uZSIgZmlsbC1ydWxlPSJldmVub2RkIj4KICAgICAgICA8ZyBpZD0i6YCa55+l5bey6K+75qC35byPIiB0cmFuc2Zvcm09InRyYW5zbGF0ZSgtMjIwLjAwMDAwMCwgLTcwMy4wMDAwMDApIj4KICAgICAgICAgICAgPGcgaWQ9IuamguiniCIgdHJhbnNmb3JtPSJ0cmFuc2xhdGUoMjIwLjAwMDAwMCwgNzAzLjAwMDAwMCkiPgogICAgICAgICAgICAgICAgPGNpcmNsZSBpZD0i5qSt5ZyG5b2i5aSH5Lu9LTIzIiBmaWxsPSIjRTVGMUZGIiBjeD0iMTQiIGN5PSIxNCIgcj0iMTQiPjwvY2lyY2xlPgogICAgICAgICAgICAgICAgPGcgaWQ9IuWfuuehgOWFg+e0oC/lm77moIcv6KGo5oSPL+ezu+e7n+m7mOiupOWkh+S7vS0zIiB0cmFuc2Zvcm09InRyYW5zbGF0ZSg3LjAwMDAwMCwgNy4wMDAwMDApIiBmaWxsPSIjNDQ5Q0ZGIj4KICAgICAgICAgICAgICAgICAgICA8cGF0aCBkPSJNMS4xNTAxLDAuNzgwNSBMNS43NDA3LDAuNzgwNSBDNS43ODU1LDAuNzgwNSA1LjgyMTksMC44MTY5IDUuODIxOSwwLjg2MTcgTDUuODIxOSw1LjU0NjEgQzUuODIxOSw1LjU2NzU3MTc3IDUuODEzMzIzNTYsNS41ODgxNTQwNiA1Ljc5ODA3NTE1LDUuNjAzMjcxMDIgQzUuNzgyODI2NzMsNS42MTgzODc5OCA1Ljc2MjE3MDk1LDUuNjI2Nzg2NzEgNS43NDA3LDUuNjI2NjAzMDUgTDEuMTUwMSw1LjYyNjYwMzA1IEMxLjEwNTY0MTA4LDUuNjI2NjAzMDUgMS4wNjk2LDUuNTkwNTU4OTIgMS4wNjk2LDUuNTQ2MSBMMS4wNjk2LDAuODYxNyBDMS4wNjk2LDAuODE2OSAxLjEwNTMsMC43ODA1IDEuMTUwMSwwLjc4MDUgWiBNNi42OTQxLDYuODM4MyBMMTIuODY5NSw2LjgzODMgQzEyLjkxMzYsNi44MzgzIDEyLjk1LDYuODc0NyAxMi45NSw2LjkxOTUgTDEyLjk1LDEzLjIxOTUgQzEyLjk1LDEzLjI2Mzk1ODkgMTIuOTEzOTU4OSwxMy4zIDEyLjg2OTUsMTMuMyBMNi42OTQxLDEzLjMgQzYuNjQ5NjQxMDgsMTMuMyA2LjYxMzYsMTMuMjYzOTU4OSA2LjYxMzYsMTMuMjE5NSBMNi42MTM2LDYuOTE5NSBDNi42MTM2LDYuODc0NyA2LjY1LDYuODM4MyA2LjY5NDEsNi44MzgzIFogTTUuMzksMTEuMzcwMSBMNS4zOSwxMi45ODU3IEwxLjA1LDEyLjk4NTcgTDEuMDY5Niw3LjIzOTQgTDIuNjUzNyw3LjI0NSBMMi42Mzk3LDExLjM3MDEgTDUuMzksMTEuMzcwMSBMNS4zOSwxMS4zNzAxIFogTTcuNDE3MiwyLjM5NjEgTDcuMzk0MSwwLjc4MTIgTDEyLjk0MywwLjcgTDEyLjk0Myw1Ljg5ODIgTDExLjM1ODksNS44OTgyIEwxMS4zNTg5LDIuMzM4NyBMNy40MTcyLDIuMzk2MSBaIiBpZD0i5b2i54q2Ij48L3BhdGg+CiAgICAgICAgICAgICAgICA8L2c+CiAgICAgICAgICAgIDwvZz4KICAgICAgICA8L2c+CiAgICA8L2c+Cjwvc3ZnPg=='
    }
  },
  watch: {
    drawerVisible(val) {
      if (val) {
        this.getList()
      }
    }
  },
  mounted() {
    this.getMsgType()
  },
  methods: {
    // 关闭抽屉
    handleClose() {
      this.$emit('updateDrawerVisible', false)
    },
    // 获取消息类型
    async getMsgType() {
      try {
        const { data } = await msgApi.getMsgType()
        data && (this.msgTypelist = Object.keys(data).map((i) => {
          const obj = {}
          obj.id = +i
          obj.label = data[i]
          return obj
        }))
      } catch (error) {
        console.log(error)
      }
    },
    // 类型点击
    dropDownHandler(id) {
      this.labelText = id === '' ? '所有分类' : this.msgTypelist.find(item => item.id === id).label
      this.getList()
    },
    // 跳转全部消息页
    openMsgPage() {
      this.$router.push(`/sys/msg-center`)
      this.handleClose()
    },
    // 点击全部/未读
    activeHandler(text) {
      this.msgType = this.msgType.map(item => {
        return {
          ...item,
          active: text === item.text
        }
      })
      this.getList()
    },
    // 获取消息数据
    async getList() {
      try {
        const { data } = await msgApi.getList({
          pageSize: 10,
          pageNum: 1,
          type: this.labelText === '所有分类' ? '' : this.msgTypelist.find(item => item.label === this.labelText).id,
          isAll: this.msgType[0].active ? 1 : 0
        })
        if (data && data.list) {
          this.list = data.list
        }
      } catch (error) {
        console.log(error)
      }
    },
    // 标记已读
    async readHandler() {
      if (this.list.filter(item => !item.hasRead).length === 0) {
        return
      }
      try {
        const { retcode } = await msgApi.changeStatus({
          ids: this.list.reduce((res, cur) => {
            return cur.hasRead ? res : [...res, cur.id]
          }, [])
        })
        if (retcode === 0) {
          this.$message.success('操作成功')
          this.getList()
        }
      } catch (error) {
        console.log(error)
      }
    },
    // 读取单条消息
    async readMsg(id) {
      try {
        const { retcode } = await msgApi.changeStatus({ ids: [id] })
        if (retcode === 0) {
          this.getList()
        }
      } catch (error) {
        console.log(error)
      }
    },
    // 跳转
    openDetailPage(obj) {
      switch (+obj.typeId) {
        case 1: // 项目
          this.$router.push(`/pj/detail/${obj.projectId}`)
          break
        case 2: // 数据集
          this.$router.push(
            `/pj/detail/${obj.projectId}?t=FlDataset&name=${obj.linkText}`
          )
          break
        case 3: // 工作流
          this.$router.push(
            `/flow/drag-flow/editor/${obj.projectId}/${obj.commonId}`
          )
          break
        case 4: // 模型
          this.$router.push(
            `/pj/detail/${obj.projectId}?t=ModelList&name=${obj.linkText}`
          )
          break
        case 5: // 任务
          this.$router.push(
            `/pj/detail/${obj.projectId}?t=MissionList&taskId=${obj.commonId}`
          )
          break
        case 6: // 模型服务
          this.$router.push(
            `/pj/service-list/detail/${obj.commonId}?proId=${obj.projectId}`
          )
          break
        case 7: // 匿踪查询
          this.$router.push(
            `/pj/detail/${obj.projectId}?t=HidingTraces&id=${obj.commonId}`
          )
          break
        case 8: // 隐匿求交
          this.$router.push(
            `/pj/detail/${obj.projectId}?t=HidingSubmission&id=${obj.commonId}`
          )
          break
        default:
          this.$message.warning('数据有误，刷新后再试')
          break
      }
      if ([1, 2, 3, 4, 5, 6, 7, 8].includes(+obj.typeId)) {
        this.handleClose()
        this.readMsg(obj.id)
      }
    }
  }
}
</script>
<style lang="scss" scoped>
@import '@/reset.var.scss';
.custom-drawer ::v-deep .el-drawer {
  box-shadow: -2px 0 8px rgba(0, 0, 0, 0.15);
}

.msgWrapper {
  display: flex;
  flex-direction: column;
  height: 100%;

  .msg-head {
    width: 100%;
    justify-content: space-between;
    padding: 11px 16px;
    border-bottom: 1px solid #e9f0f7;

    &-left {
      div {
        padding: 6px 12px;
        font-size: 14px;
        line-height: 20px;
        color: #475669;
        cursor: pointer;
      }

      .active {
        color: $--color-primary;
        font-weight: 500;
        background: #ecf6fd;
        border-radius: 31px;
      }
    }

    &-right {
      align-items: center;
      position: relative;

      .total {
        font-size: 12px;
        color: $--color-primary;
        cursor: pointer;
        padding: 0 12px;
        border-right: 1px solid #e0e6ed;
        margin-left: auto;
      }

      .options {
        cursor: pointer;
        margin-left: 9px;
        margin-right: 16px;
        position: relative;
        box-sizing: border-box;
        max-width: 70px;
        overflow: hidden;
        text-overflow: ellipsis;
        display: -webkit-box;
        -webkit-box-orient: vertical;
        -webkit-line-clamp: 1;
      }

      &::after {
        content: '';
        width: 0;
        height: 0;
        border-left: 4px solid transparent;
        border-right: 4px solid transparent;
        border-top: 4px solid #2f333c;
        position: absolute;
        right: 4px;
        top: 15px;
      }
    }
  }

  .msg-content {
    flex: 1;
    width: 100%;
    display: flex;
    flex-direction: column;
    overflow-x: hidden;
    overflow-y: scroll;
    padding-bottom: 12px;

    li {
      padding: 12px 16px 0;

      .imgWrapper {
        display: flex;
        ::v-deep .el-badge__content.is-fixed.is-dot {
          right: -4px;
          top: 8px;
        }
        img {
          width: 20px;
          height: 20px;
          margin-right: 4px;
        }

        span {
          overflow: hidden;
          text-overflow: ellipsis;
          display: -webkit-box;
          -webkit-box-orient: vertical;
          -webkit-line-clamp: 1;
          font-size: 14px;
          font-weight: 500;
          line-height: 20px;
          color: #475669;

          b {
            font-weight: 400;
            color: red;
          }
        }
      }

      p {
        font-size: 14px;
        font-weight: 400;
        margin-top: 8px;
        padding-left: 22px;
        color: #333;

        span {
          color: $--color-primary;
          cursor: pointer;
        }
      }

      .time {
        padding-left: 22px;
        padding-bottom: 12px;
        font-size: 12px;
        color: #8492a6;
        font-weight: 400;
        margin-top: 8px;
        border-bottom: 1px solid #E9F0F7;
      }
    }
  }

  .msg-footer {
    display: flex;
    justify-content: center;
    align-items: center;
    height: 40px;
    border-top: 1px solid #e9f0f7;
    color: #475669;
    cursor: pointer;
    box-sizing: border-box;
    position: relative;

    span {
      margin-left: 2px;
      width: 8px;
      height: 8px;
      border-top: 2px solid #4f5d6f;
      border-right: 2px solid #4f5d6f;
      transform: rotate(45deg);
    }
  }
}
</style>
