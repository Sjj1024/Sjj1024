<template>
  <section
    v-if="isRouterAlive"
    class="app-main"
  >
    <transition
      name="fade-transform"
      mode="out-in"
    >
      <!-- or name="fade" -->
      <!-- <router-view :key="key"></router-view> -->
      <router-view v-if="isMain"></router-view>
      <div
        v-else
        id="subapp-viewport"
      ></div>
    </transition>
  </section>
</template>

<script>
import { registerApps } from '@/qiankun/index'
/**
 *
 *  Copyright 2019 The FATE Authors. All Rights Reserved.
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 *
 */

export default {
  name: 'AppMain',
  props: {
    routerView: {
      type: Boolean,
      default: true
    }
  },
  data() {
    return {
      isRouterAlive: true,
      isMain: false
    }
  },
  watch: {
    $route(val, old) {
      this.isMainPage(val)
      this.isRouterAlive = false
      this.$nextTick(() => {
        this.isRouterAlive = true
      })
    },
    routerView() {
      this.isRouterAlive = false
      this.$nextTick(() => {
        this.isRouterAlive = true
      })
    }
  },
  mounted() {
    this.isMainPage(this.$route)
    if (!window.qiankunStarted) {
      window.qiankunStarted = true
      registerApps()
    }
  },
  methods: {
    isMainPage(value) {
      if (value.meta.moduleName === 'main') {
        this.isMain = true
      } else {
        this.isMain = false
      }
    }
  }
}
</script>

<style scoped>
.app-main {
  display: flex;
  flex-direction: column;
  align-items: center;
  height: calc(100vh - 49px);
  position: relative;
  overflow: auto;
  padding: 15px 15px 15px;
}
</style>
