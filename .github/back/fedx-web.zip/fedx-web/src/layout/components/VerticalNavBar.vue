<template>
  <div
    :class="isOpenMenu ? 'isOpen' : ''"
    class="vertical-bg"
  >
    <div
      class="vertical-logo"
      @click="go('/pj/project')"
    >
      <el-image
        :src="getNavLogo"
        fit="cover"
        alt="logo"
        srcset=""
      ></el-image>
      <div
        v-if="!isOpenMenu"
        class="website-title"
      >DataCanvas PPC</div>
    </div>
    <el-menu
      ref="el-menu"
      :default-active="path"
      :popper-append-to-body="true"
      :collapse="isOpenMenu"
      background-color="rgba(0,0,0,0)"
      text-color="#fff"
      class="el-menu-vertical-demo"
      mode="vertical"
      @select="handleSelect"
    >
      <fragment
        v-for="(item, index) in newRouter"
        :key="index"
      >
        <fragment v-if="item.isEnabled">
          <el-submenu
            v-if="item.children.length > 0 && +item.url === -1"
            :index="item.url + index"
          >
            <template slot="title">
              <i
                v-if="item.icon"
                :class="item.icon"
              ></i>
              <span slot="title">{{ item.meta.title }}</span>
            </template>
            <div
              v-for="(zitem, zindex) in item.children"
              :key="zindex"
            >
              <el-menu-item
                v-if="zitem.isEnabled"
                :key="zindex"
                :index="zitem.url"
                @click="go(zitem)"
              >
                {{ zitem.meta.title }}
              </el-menu-item>
            </div>
          </el-submenu>

          <el-menu-item
            v-else
            :index="item.name"
            @click="go(item)"
          >
            <i
              v-if="item.icon"
              :class="item.icon"
            ></i>
            <span slot="title">{{ item.meta.title }}</span>
          </el-menu-item>
        </fragment>
      </fragment>
      <!-- end -->
      <!-- <el-menu-item index="/project" @click="go('/project')">
        <i class="el-icon-xmgl_sel"></i>
      <span slot="title">项目管理</span></el-menu-item>
      <el-menu-item index="/fldataset" @click="go('/fldataset')">
        <i class="el-icon-zysjj_sel"></i>
      <span slot="title">数据集管理</span></el-menu-item>
      <el-menu-item
        index="/flow-template"
        @click="go('/flow-template')"
      ><i class="el-icon-icon_gongzuoliupeizhiguanli"></i>
      <span slot="title">工作流模版</span></el-menu-item
      >
      <el-menu-item v-if="isSysMenu" index="/mechanism" @click="go('/mechanism')">
        <i class="el-icon-jggl_sel"></i>
      <span slot="title">机构管理</span></el-menu-item>
      <el-submenu index="/yinsuoyi">
        <template slot="title">
          <i class="el-icon-lbyq_sel"></i>
        <span slot="title">联邦引擎</span></template
        >
        <el-menu-item
          index="/FATE"
          @click="beforeGo(config.fateUrl)"
        >FATE</el-menu-item
        >
        <el-menu-item
          v-if="fedllearn"
          index="/FedLearner"
          @click="goFedLearn"
        >FedLearner</el-menu-item
        >
      </el-submenu>
      <el-submenu v-if="isSysMenu" index="/system">
        <template slot="title">
          <i class="el-icon-sz_sel"></i>
        <span slot="title">系统管理</span></template
        >
        <el-menu-item
          index="/user-list"
          @click="go('/user-list')"
        >用户管理</el-menu-item
        >
        <el-menu-item
          index="/log-static"
          @click="go('/log-static')"
        >日志审计</el-menu-item
        >
      </el-submenu> -->
      <!-- <el-menu-item index="/poseidon"><span @click="goHome">波塞冬</span></el-menu-item> -->
    </el-menu>
  </div>
</template>

<script>
// 这个是左边路由栏
/**
 *
 *  Copyright 2019 The FATE Authors. All Rights Reserved.
 *
 *  Licensed under the Apache License, Version 2.0 (the "License");
 *  you may not use this file except in compliance with the License.
 *  You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 *  Unless required by applicable law or agreed to in writing, software
 *  distributed under the License is distributed on an "AS IS" BASIS,
 *  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 *  See the License for the specific language governing permissions and
 *  limitations under the License.
 *
 */

import { mapActions, mapGetters, mapMutations, mapState } from 'vuex'
import { isSpdb } from '@/api/newlogin'
// import SSHConfig from './SSHConfig'
// import { getAllSSHConfig, getSSHConfig, removeSSHConfig, addSSHConfig } from '@/api/ssh'
import UpdatePwd from './UpdatePwd'
// import newUser from '@/api/newUser'
// import { routersRoutes } from '@/router/index.js'
import newMenuApi from '@/api/role'
export default {
  components: {
    // SSHConfig
    UpdatePwd
  },
  data() {
    return {
      projectsData: null,
      isSimulate: true,
      hasSysMenu: false,
      path: this.$route.meta.activePath || this.$route.path,
      showConfigModal: false,
      fedllearn: false,
      newRouter: [],
      config: {},
      routerCheckData: {}
    }
  },
  computed: {
    isSysMenu() {
      return this.hasSysMenu
    },
    routes() {
      return this.$router.options.routes[0].children.filter((item) => {
        return (
          item.path === '/data-center' ||
          item.path === '/experiment' ||
          item.path === '/job-history'
        )
      })
    },
    ...mapGetters(['isOpenMenu']),
    ...mapGetters(['isOpenReqSimulate', 'username']),
    ...mapGetters(['username']),
    ...mapGetters('logo', ['getNavTitle', 'getNavLogo']),
    pname() {
      return this.$route.query.pname || ''
    },
    pid() {
      return this.$route.query.pid || ''
    },
    ...mapState('logo', ['logoData'])
  },
  watch: {
    $route: 'getPath',
    isOpenMenu(val) {
      if (val) {
        if (this.$el.querySelector('.el-menu')) {
          this.$el.querySelector('.el-menu').style.display = 'none'
        }
      }
    }
  },
  async mounted() {
    await this.loadHasMenuSysMenu()
    const list = JSON.parse(localStorage.getItem('visitedViews'))
    if (list && list.length) {
      const hasCurrPath = list.some((e) => e.fullPath === this.$route.path)
      list.forEach((e) => {
        this.$store.commit('ADD_ROUTE_VIEWS', { ...e })
      })
      if (!hasCurrPath) {
        this.getPath()
      }
    } else {
      this.getPath()
    }

    this.isSimulate = this.isOpenReqSimulate
    this.getLogoData()
  },
  methods: {
    ...mapMutations('menu', ['ADD_ROUTE_VIEWS']),
    ...mapActions('user', ['GetNewInfoMenu']),
    ...mapActions('logo', ['getLogoData']),

    async queryRouterList() {
      const { data } = await newMenuApi.newmenuQuery()
      return data
    },
    navPermisson(roles) {
      // 权限判断返回
      return true
      // if (roles instanceof Array) {
      //   if (roles.indexOf('isroles') !== -1) {
      //     return this.hasSysMenu
      //   } else {
      //     return true
      //   }
      // } else {
      //   return true
      // }
    },

    async isShowFedLearn() {
      const res = await isSpdb()
      if (res.retcode === 0) {
        this.fedllearn = res.data.fedllearn
      }
    },

    async loadHasMenuSysMenu() {
      const res = await this.GetNewInfoMenu()
      const { menu } = res.data
      this.newRouter = [...menu]
      return res
    },

    logout() {
      this.$notify.success({
        duration: 1500,
        title: '提示',
        message: '退出登录成功'
      })
      localStorage.removeItem('token')
      localStorage.removeItem('username')
      localStorage.removeItem('userid')
      setTimeout(() => {
        this.$router.push('/login')
      }, 300)
    },
    handleSelect(key, keyPath) {
      console.log(key, keyPath)
    },
    diffUrl(e, e2) {
      let res = false
      const list = e.split('/')
      const list2 = e2 ? e2.split('/') : []
      let str2 = ''
      list2.forEach((e) => {
        if (e.indexOf(':') !== -1) {
          // str2 += '*/'
        } else {
          str2 += e + '/'
        }
      })
      if (e.indexOf(str2) !== -1 && list.length === list2.length) {
        res = true
      }
      return res
    },
    checkUrl(url, urlTow) {
      let res = false
      if (url === urlTow) {
        res = true
      } else if (this.diffUrl(url, urlTow) && urlTow.indexOf(':') !== -1) {
        // 条件1判断是否相等，条件2判断是否为带参数url
        res = true
      } else {
        res = false
      }
      return res
    },

    routerCheck(url, list) {
      for (let i = 0; i < list.length; i++) {
        const e = list[i]
        if (this.checkUrl(url, e.url)) {
          this.routerCheckData = e
          break
        } else {
          this.routerCheck(url, e.children)
        }
      }
    },

    getPath() {
      this.path = this.$route.meta.activePath || this.$route.path
      // const [currentRoute] = this.newRouter.filter(
      //   item => item.url === this.$route.path
      // )
      this.routerCheckData = {}
      this.routerCheck(this.$route.path, this.newRouter)
      const currentRoute = this.routerCheckData
      if (Object.keys(currentRoute).length > 0) {
        this.$store.commit('ADD_ROUTE_VIEWS', {
          ...this.$route,
          meta: currentRoute.meta,
          name: currentRoute.name
        })
      }
    },

    // beforeGo(path) {
    //   if (!path) return
    //   const data = localStorage.getItem('token')
    //   getuserInfo({ data }).then(res => {
    //     if (res.retcode === 0 && res.data.token && res.data.token.length > 0) {
    //       window.open(path, '_blank')
    //     } else {
    //       this.logout()
    //     }
    //   })
    // },

    go(option) {
      if (option.type === 'a链接') {
        let url = option.url
        const token = localStorage.getItem('token')
        if (option.url.includes('$token')) {
          url = option.url.replace('$token', token)
        }
        if (option.method === 'tab') {
          window.open(url)
        } else {
          window.location.href = url
        }
      } else if (option.type === 'iframe') {
        this.$router.push('/monitor')
        this.path = '/monitor'
      } else if (option.type === '按钮') {
        console.log('按钮')
      } else {
        this.$router.push(option.url)
        this.path = option.url
      }
    }
  }
}
</script>

<style lang="scss">
@import '@/reset.var.scss';
// @import "../../../styles/common/layout/navbar.scss";
.el-menu--vertical {
  left: 65px !important;
  .el-menu {
    background-color: #303133 !important;
    padding: 10px;
    & > .el-menu-item {
      &:last-child {
        margin-bottom: 0;
      }
      &.is-active,
      &:hover {
        font-weight: bold;
        color: $--color-primary !important;
        background-color: rgb(168, 31, 31) !important;
      }
      margin-bottom: 10px;
      height: 40px;
      line-height: 40px;
    }
  }
}
.vertical-bg {
  &.isOpen {
    transition: all 0.1s linear;
    .el-menu-vertical-demo.el-menu--collapse {
      & {
        width: 50px;
        .el-submenu {
          &.is-active {
            border-radius: 2px;
            background-color: #fff;
            i:first-child {
              color: $--color-primary !important;
            }
          }
        }
      }
      .el-tooltip,
      .el-submenu__title {
        display: flex !important;
        align-items: center;
        justify-content: center;
      }
      .el-menu-item,
      .el-submenu__title {
        width: 50px;
        height: 40px;
        border-radius: 2px;
      }
    }
    width: 70px;
    padding: 10px;
    .vertical-logo {
      justify-content: center;
    }
  }
  width: 200px;
  height: 100%;
  padding: 20px 0 8px 0px;
  box-sizing: border-box;
  background-color: #1b2441;
  overflow: hidden;
  .el-menu {
    border: none;
    height: calc(100% - 100px);
    width: 103%;
    &::-webkit-scrollbar {
      width: 0;
    }
    overflow-x: hidden;
    overflow-y: auto;
    .el-menu-item {
      &.is-active {
        i:first-child {
          color: $--color-primary;
        }
        background-color: #fff !important;
        font-weight: bold;
        border-top-left-radius: 2px;
        border-bottom-left-radius: 2px;
      }
    }
    /* .el-submenu {
      &.is-active {
        .el-submenu__title {
          i:first-child { }
        }
      }
    } */
    .el-menu-item,
    .el-submenu__title {
      i:first-child {
        color: #fff;
        font-size: 20px;
        position: relative;
        top: 0px;
      }
      .el-submenu__icon-arrow {
        color: #fff;
      }
      transition: all 0.1s linear;
      margin-bottom: 20px;
      height: 40px;
      line-height: 40px;
      &:focus:not(.is-active),
      &:hover:not(.is-active) {
        border-top-left-radius: 2px;
        border-bottom-left-radius: 2px;
        background-color: #fff !important;
        color: $--color-primary !important;
        i {
          color: $--color-primary;
        }
      }
    }
  }

  .vertical-logo {
    width: 100%;
    display: flex;
    align-items: center;
    box-sizing: border-box;
    justify-content: center;
    // padding: 0 20px;
    margin-bottom: 20px;
    img {
      width: 28px;
      height: 28px;
    }
    .website-title {
      margin-left: 5px;
      font-size: 16px;
      font-weight: 500;
      color: #fff;
    }
  }
}
</style>
