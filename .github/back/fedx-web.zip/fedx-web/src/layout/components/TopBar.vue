<template>
  <div class="topbar nav-container flex space-between">
    <div class="topbar-tabs">
      <tags-view />
    </div>
    <div class="help">
      <el-tooltip
        class="item"
        effect="dark"
        content="帮助中心"
        placement="bottom"
      >
        <span>
          <i
            class="el-icon-helpCenter icon-font"
            @click="openHelpPage"
          ></i>
        </span>
      </el-tooltip>
      <el-tooltip
        class="item"
        effect="dark"
        content="消息中心"
        placement="bottom"
      >
        <span>
          <el-badge
            v-if="msg"
            is-dot
            class="item"
          >
            <i
              class="el-icon-bell icon-font"
              @click="openMsgPage"
            ></i>
          </el-badge>
          <i
            v-else
            class="el-icon-bell icon-font"
            @click="openMsgPage"
          ></i>
        </span>
      </el-tooltip>
      <div class="el-dropdown-content">
        <el-tooltip
          :content="`${userinfo.partyId}-${userinfo.partyName}`"
          class="item"
          effect="dark"
          placement="bottom"
        >
          <span class="el-button el-button--text el-dropdown-content--text">{{ userinfo.partyId }}-{{ userinfo.partyName }}</span>
        </el-tooltip>
        <el-dropdown
          trigger="hover"
          @visible-change="visibleHandler"
        >
          <span class="flex flex-center el-dropdown-link">
            <!-- <img
              style="width: 28px; height: 28px;margin-right: 6px;"
              src="../../assets/avater.png"
            > -->
            {{ username }}
            <!-- <i class="el-icon-arrow-down el-icon--right"></i> -->
          </span>
          <el-dropdown-menu slot="dropdown">
            <el-dropdown-item>
              <p @click="changePwd">修改密码</p>
            </el-dropdown-item>
            <el-dropdown-item>
              <p @click="logout">退出登录</p>
            </el-dropdown-item>
          </el-dropdown-menu>
        </el-dropdown>
        <p :class="[visible&&'rotate']"></p>
      </div>
    </div>
    <!-- <SSHConfig :show-config-modal="showConfigModal" @closeSSHConfigModal="showConfigModal = false" /> -->
    <UpdatePwd ref="pwdForm" />
    <MsgDrawer v-model="drawerVisible"></MsgDrawer>
    <AddForm ref="addForm" />
  </div>
</template>

<script>
import { mapGetters, mapActions } from 'vuex'
import AddForm from '@/views/sys/user-list/form'
import UpdatePwd from './UpdatePwd'
import TagsView from './TagsView'
import MsgDrawer from './MsgDrawer'
export default {
  components: {
    // SSHConfig
    AddForm,
    UpdatePwd,
    TagsView,
    MsgDrawer
  },
  data() {
    return {
      projectsData: null,
      isSimulate: true,
      hasSysMenu: false,
      path: this.$route.path,
      showConfigModal: false,
      config: {},
      timer: null,
      msgParams: {
        hasRead: false,
        userId: localStorage.getItem('userid'),
        pageNum: 1,
        pageSize: 10
      },
      drawerVisible: false,
      visible: false
    }
  },
  computed: {
    ...mapGetters(['username', 'userinfo', 'msg']),
    pname() {
      return this.$route.query.pname || ''
    },
    pid() {
      return this.$route.query.pid || ''
    }
  },
  watch: {
    $route: 'getPath'
  },
  async created() {
    this.getMsgCount(this.msgParams)
    // this.timer = setInterval(() => {
    //   this.getMsgCount(this.msgParams)
    // }, 5000)
  },
  destroyed() {
    clearInterval(this.timer)
  },
  methods: {
    ...mapActions('user', ['getMsgCount']),
    changePwd() {
      this.$refs.addForm.show(2, { username: localStorage.getItem('username') })
    },
    openMsgPage() {
      // this.$router.push(`/sys/msg-center`)
      this.drawerVisible = true
    },
    openHelpPage() {
      window.open(
        `${window.location.protocol}//${window.location.hostname}:32210/basic/`
      )
    },
    logout() {
      this.$store
        .dispatch('user/LogOut')
        .then(() => {
          this.$notify.success({
            duration: 1500,
            title: '提示',
            message: '退出登录成功'
          })
          // 清空历史菜单列表
          localStorage.removeItem('visitedViews')
          this.$store.commit('DELETE_ROUTE_ALL_VIEWS')
          setTimeout(() => {
            this.$router.push('/login')
          }, 600)
        })
        .catch(() => {
          this.$notify.success({
            duration: 1500,
            title: '提示',
            message: '退出登录失败'
          })
          this.$router.push('/login')
        })
    },
    getPath() {
      this.path = this.$route.path
    },
    visibleHandler(val) {
      this.visible = val
    }
  }
}
</script>

<style lang="scss">
.topbar {
  width: 100%;
  height: 49px;
  box-sizing: border-box;
  background-color: #fff;
  box-shadow: 0 4px 12px rgba(31, 45, 61, 0.05);
  transition: transform 0.3s ease;
  position: relative;
  z-index: 199;

  & > .topbar-tabs {
    flex: 1;
  }

  .help {
    display: flex;
    align-items: center;
    padding-right: 20px;
    line-height: 22px;
    position: relative;

    .icon-font {
      color: #475669;
      font-weight: 700;
      font-size: 16px;
      cursor: pointer;
      margin: 0 6px;
    }
  }
}

.el-dropdown-content {
  padding-left: 6px;
  padding-right: 4px;
  cursor: pointer;
  font-size: 12px;
  display: flex;
  align-items: center;
  border-left: 1px solid #e0e6ed;
  margin-left: 10px;

  /* &:hover {
    background: #F5F8FC;
    transition: background .4s ease-in;

    .el-dropdown-content--text {
      background-color: #fff;
      color: #475669;
    }
  } */

  .el-dropdown-content--text {
    display: inline-block;
    max-width: 90px;
    background: #f0f3f6;
    border-radius: 11px;
    font-weight: 400;
    color: #475669;
    text-overflow: ellipsis;
    white-space: nowrap;
    padding: 0 8px;
    vertical-align: middle;
    overflow: hidden;
    margin: 0 8px;
    font-size: 12px;
  }

  .el-dropdown-link {
    font-size: 14px;
    font-weight: 600;
    color: #475669;
    text-align: left;
    max-width: 100px;
    white-space: nowrap;
    text-overflow: ellipsis;
    overflow: hidden;
  }

  p {
    width: 14px;
    height: 14px;
    position: relative;

    &::after {
      content: '';
      width: 0;
      height: 0;
      border-left: 4px solid transparent;
      border-right: 4px solid transparent;
      border-top: 4px solid #c0ccda;
      position: absolute;
      transition: transform 0.25s linear;
      right: 0;
      top: 5px;
    }
  }

  .rotate {
    &::after {
      border-left: 4px solid transparent;
      border-right: 4px solid transparent;
      border-top: 4px solid #111;
      transform: rotate(-180deg);
    }
  }
}
</style>
