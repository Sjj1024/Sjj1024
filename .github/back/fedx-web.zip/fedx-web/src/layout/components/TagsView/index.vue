<template>
  <div id="tags-view-container" :style="{ width: isOpenMenu ? 'calc(100vw - 328px)' : 'calc(100vw - 460px)'}" class="tags-view-container">
    <!-- <scroll-pane
      ref="scrollPane"
      class="tags-view-wrapper"
      @scroll="handleScroll"
    > -->
    <!-- :style="activeStyle(tag)" -->
    <div class="tags-view-wrapper">
      <router-link
        v-right-click="rightMenuConfig"
        v-for="(tag, index) in visitedViews"
        ref="tag"
        :index="index"
        :key="tag.path"
        :class="isActive(tag) ? 'active' : ''"
        :to="{ path: tag.path, query: tag.query, fullPath: tag.fullPath }"
        tag="span"
        class="tags-view-item"
        @click.middle.native="!isAffix(tag) ? closeSelectedTag(tag) : ''"
      >
        {{ tag.meta.title }}
        <span
          class="el-icon-close"
          @click.prevent.stop="closeSelectedTag(tag)"
        ></span>
      </router-link>
    </div>
    <!-- </scroll-pane> -->
  </div>
</template>

<script>
// 这个是顶部标题标签
// visitedViews 对象中3个字段 meta path fullPath
import ScrollPane from './ScrollPane'
import { mapGetters, mapMutations } from 'vuex'

export default {
  components: { ScrollPane },
  data() {
    return {
      visible: false,
      top: 0,
      left: 0,
      selectedTag: {},
      affixTags: []
    }
  },
  computed: {
    ...mapGetters(['visitedViews', 'isOpenMenu']),
    routes() {
      return this.visitedViews
    },
    rightMenuConfig() {
      return [
        {
          text: '关闭',
          handler: this.close
        },
        {
          text: '关闭其他',
          handler: this.closeOther
        }
      ]
    }
  },
  watch: {
    visible(value) {
      if (value) {
        document.body.addEventListener('click', this.closeMenu)
      } else {
        document.body.removeEventListener('click', this.closeMenu)
      }
    }
  },
  mounted() {
    // console.log( '--------------TagsView-visitedViews',this.visitedViews)
    // console.log(localStorage.getItem('state'))
  },
  methods: {
    ...mapMutations('menu', ['DELETE_ROUTE_VIEWS', 'DELETE_ROUTE_VIEWS_BY_INDEX', 'DELETE_OTHER_ROUTE_VIEWS_BY_INDEX']),
    isActive(route) {
      return route.path === this.$route.path
    },
    close(index) {
      this.$store.commit('DELETE_ROUTE_VIEWS_BY_INDEX', Number(index))
      this.closeTagCallback()
    },
    closeOther(index) {
      this.$store.commit('DELETE_OTHER_ROUTE_VIEWS_BY_INDEX', Number(index))
      this.closeTagCallback()
    },
    isAffix(tag) {
      return tag.meta && tag.meta.title
    },
    closeMenu() {
      this.visible = false
    },
    closeSelectedTag(tag) {
      this.$store.commit('DELETE_ROUTE_VIEWS', tag)
      this.closeTagCallback()
    },
    closeTagCallback() {
      if (this.visitedViews.length > 0) {
        const last = this.visitedViews[this.visitedViews.length - 1]
        console.log(last, 'last-closeSelectedTag', this.visitedViews)
        const path = last.fullPath
        this.$router.push(path)
      } else {
        this.$router.push('/')
      }
    },
    handleScroll() {
      this.closeMenu()
    }
  }
}
</script>

<style lang="scss" scoped>
@import '@/reset.var.scss';

.tags-view-container {
  height: 49px;
  width: 100%;
  overflow-x: scroll;
  .tags-view-wrapper {
    padding-top: 7px;
    width: max-content;
    display: flex;
    justify-content: flex-start;
    .tags-view-item {
      display: inline-block;
      position: relative;
      cursor: pointer;
      height: 26px;
      line-height: 26px;
      border: 1px solid #d8dce5;
      color: #495060;
      background: #fff;
      padding: 0 8px;
      font-size: 12px;
      margin-left: 5px;
      margin-top: 4px;
      &:first-of-type {
        margin-left: 15px;
      }
      &:last-of-type {
        margin-right: 15px;
      }
      &.active {
        background-color: $--color-primary;
        color: #fff;
        border-color: $--color-primary;
        &::before {
          content: '';
          background: #fff;
          display: inline-block;
          width: 8px;
          height: 8px;
          border-radius: 50%;
          position: relative;
          margin-right: 2px;
        }
      }
    }
  }
}
</style>

<style lang="scss">
//reset element css of el-icon-close
.tags-view-wrapper {
  .tags-view-item {
    .el-icon-close {
      width: 16px;
      height: 16px;
      vertical-align: 2px;
      border-radius: 50%;
      text-align: center;
      transition: all 0.3s cubic-bezier(0.645, 0.045, 0.355, 1);
      transform-origin: 100% 50%;
      &:before {
        transform: scale(0.6);
        display: inline-block;
        vertical-align: -3px;
      }
      &:hover {
        background-color: #b4bccc;
        color: #fff;
      }
    }
  }
}
</style>
