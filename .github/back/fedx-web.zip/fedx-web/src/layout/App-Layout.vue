<template>
  <div :class="classObj" class="app-wrapper">
    <!--<div v-if="device==='mobile' && sidebar.opened" class="drawer-bg" @click="handleClickOutside"/>-->
    <!--<sidebar class="sidebar-container"/>-->
    <div class="vertical-container flex">
      <div :class="isOpenMenu ? 'showCollapes' : ''" class="left-content">
        <VerticalNavBar />
        <div class="footer-collapse" @click="toggleIsOpenMenu">
          {{ isOpenMenu ? '' : '收起导航'
          }}<i :class="isOpenMenu ? 'el-icon-s-unfold' : 'el-icon-shouqi'"></i>
        </div>
      </div>
      <div class="right-content">
        <TopBar />
        <slot></slot>
      </div>
    </div>
  </div>
</template>

<script>
import {
  TopBar,
  Sidebar,
  AppMain,
  VerticalNavBar
} from './components/index'
import ResizeMixin from './mixin/ResizeHandler'
import { mapGetters, mapMutations } from 'vuex'
export default {
  name: 'AppLayout',
  components: {
    Sidebar,
    AppMain,
    VerticalNavBar,
    TopBar
  },
  mixins: [ResizeMixin],
  data() {
    return {}
  },
  computed: {
    ...mapGetters(['navStatus', 'isOpenMenu']),
    sidebar() {
      return this.$store.state.app.sidebar
    },
    device() {
      return this.$store.state.app.device
    },
    classObj() {
      return {
        hideSidebar: !this.sidebar.opened,
        openSidebar: this.sidebar.opened,
        withoutAnimation: this.sidebar.withoutAnimation,
        mobile: this.device === 'mobile'
      }
    }
  },
  mounted() {
    // this.$store.commit('TOGGLE_NAVBAR')
    // console.log(this.navBar, 'this.navBar')
    const token = localStorage.getItem('token')
    this.$actions.setGlobalState({
      userInfo: { ...this.$store.state.user.userinfo, token },
      isOpenMenu: this.isOpenMenu
    })
  },
  methods: {
    ...mapMutations('menu', ['TOGGLE_NAVBAR', 'TOGGLE_ISOPEN']),
    toggleIsOpenMenu() {
      this.$store.commit('TOGGLE_ISOPEN')
      this.$emit('upadeslot')
      this.$actions.setGlobalState({
        isOpenMenu: this.isOpenMenu
      })
    },
    handleClickOutside() {
      this.$store.dispatch('CloseSideBar', { withoutAnimation: false })
    }
  }
}
</script>

<style rel="stylesheet/scss" lang="scss" scoped>
@import 'src/styles/mixin.scss';

.app-wrapper {
  @include clearfix;
  position: relative;
  height: 100%;
  width: 100%;
  .vertical-container {
    justify-content: space-between;
    overflow: hidden;
    height: 100%;
    .left-content {
      position: relative;
      &.showCollapes {
        .footer-collapse {
          i {
            left: 0;
          }
        }
      }
      .footer-collapse {
        width: 100%;
        position: absolute;
        bottom: 20px;
        text-align: center;
        color: #fff;
        font-size: 14px;
        cursor: pointer;
        i {
          font-size: 16px;
          position: relative;
          left: 5px;
          top: 2px;
          &.el-icon-shouqi {
            font-weight: bold;
            font-size: 17px;
          }
        }
      }
    }
    .right-content {
      flex: 1;
      width: calc(100vw - 220px);
      height: calc(100vh - 49px);
      & > .app-main {
        background-color: #f7f9fa;
        display: inline-block;
        width: 100%;
      }
    }
  }
  &.mobile.openSidebar {
    position: fixed;
    top: 0;
  }
}

.drawer-bg {
  background: #000;
  opacity: 0.3;
  width: 100%;
  top: 0;
  height: 100%;
  position: absolute;
  z-index: 999;
}
</style>
