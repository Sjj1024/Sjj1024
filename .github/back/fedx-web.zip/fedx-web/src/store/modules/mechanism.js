import mecApi from '@/api/mechanism'

export default {
  namespaced: true,
  state: {
    MechanismTableData: [],
    MechanismAddData: {},
    MechanismUpdateData: {},
    MechanismOwnOrgData: {},
    dialogType: '1',
    dialogVisible: false,
    encryptionTypeList: []
  },
  getters: {
  },
  mutations: {
    SET_Encrytion_List(state, data) {
      state.encryptionTypeList = [...data]
    },
    SET_Mechanism_OwnOrg(state, data) {
      state.MechanismOwnOrgData = data
    },
    SET_Mechanism_QUERY(state, data) {
      state.MechanismTableData = data
    },
    SET_Mechanism_Add(state, data) {
      state.MechanismAddData = data || {}
    },
    SET_Mechanism_Update(state, data) {
      state.MechanismUpdateData = data || {}
    },
    SET_Mechanism_Del(state, data) {
      state.MechanismDelData = data || {}
    }
  },
  actions: {
    async getEncryptions({ commit }, data) {
      const res = await mecApi.getEncryptions(data)
      commit('SET_Encrytion_List', res.data)
      return res
    },
    async getMechanismAdd({ commit }, data) {
      const res = await mecApi.getAdd(data)
      commit('SET_Mechanism_Add', res.data)
      return res
    },
    async getMechanismUpdate({ commit }, data) {
      const res = await mecApi.getUpdate(data)
      commit('SET_Mechanism_Update', res.data)
      return res
    },
    async getMechanismDel({ commit }, data) {
      const res = await mecApi.getdel(data)
      commit('SET_Mechanism_Del', res.data)
      return res
    },
    async getMechanismQuery({ commit }, data) {
      const res = await mecApi.getQuery(data)
      commit('SET_Mechanism_QUERY', res.data)
      return res
    },
    async getMechanismCheck({ commit }, data) {
      const res = await mecApi.getCheck(data)
      // commit('SET_Mechanism_Check', res.data)
      return res
    },
    async getMechanismqueryOwnOrg({ commit }, data) {
      const res = await mecApi.queryOwnOrg(data)
      commit('SET_Mechanism_OwnOrg', res.data)
      return res
    }
  }
}
