import dsApi from '@/api/datasource'
import { parseTime } from '@/utils'

export default {
  namespaced: true,
  state: {
    DatasourceTableData: [],
    DatasourceAddData: {},
    DatasourceUpdateData: {},
    DatasourceOwnOrgData: {},
    dialogType: '1',
    dialogVisible: false,
    encryptionTypeList: []
  },
  getters: {
  },
  mutations: {
    SET_Encrytion_List(state, data) {
      state.encryptionTypeList = [...data]
    },
    SET_Datasource_OwnOrg(state, data) {
      state.DatasourceOwnOrgData = data
    },
    SET_Datasource_QUERY(state, data) {
      state.DatasourceTableData = data
    },
    SET_Datasource_Add(state, data) {
      state.DatasourceAddData = data || {}
    },
    SET_Datasource_Update(state, data) {
      state.DatasourceUpdateData = data || {}
    },
    SET_Datasource_Del(state, data) {
      state.DatasourceDelData = data || {}
    },
    MOCK_Datasource(state, data) {
      const date = new Date()
      data.createDate = parseTime(date)
      state.DatasourceTableData.push(data)
    }
  },
  actions: {
    async getEncryptions({ commit }, data) {
      const res = await dsApi.getEncryptions(data)
      commit('SET_Encrytion_List', res.data)
      return res
    },
    async getDatasourceAdd({ commit }, data) {
      const res = await dsApi.getAdd(data)
      commit('SET_Datasource_Add', res.data)
      return res
    },
    async getDatasourceUpdate({ commit }, data) {
      const res = await dsApi.getUpdate(data)
      commit('SET_Datasource_Update', res.data)
      return res
    },
    async getDatasourceDel({ commit }, data) {
      const res = await dsApi.getdel(data)
      commit('SET_Datasource_Del', res.data)
      return res
    },
    async getDatasourceQuery({ commit }, data) {
      const res = await dsApi.getQuery(data)
      commit('SET_Datasource_QUERY', res.data)
      return res
    },
    async getDatasourceCheck({ commit }, data) {
      const res = await dsApi.getCheck(data)
      // commit('SET_Datasource_Check', res.data)
      return res
    },
    async getDatasourcequeryOwnOrg({ commit }, data) {
      const res = await dsApi.queryOwnOrg(data)
      commit('SET_Datasource_OwnOrg', res.data)
      return res
    }
  }
}
