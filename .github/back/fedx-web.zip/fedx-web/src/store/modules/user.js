import { updatePwd, resetpwd } from '@/api/newlogin'
import { login, logout, getuserInfo, ssologin } from '@/api/newlogin'
import { getToken, removeToken } from '@/utils/auth'
import newUser from '@/api/newUser'
import msgApi from '@/api/msg'
const username = localStorage.getItem('username')
const userid = localStorage.getItem('userid')
let userInfo = localStorage.getItem('user')
try {
  userInfo = JSON.parse(userInfo)
} catch (error) {
  userInfo = undefined
}
const user = {
  namespaced: true,
  state: {
    token: getToken(),
    name: '',
    avatar: '',
    roles: [],
    username: username || '',
    userid: userid || '',
    userinfo: userInfo,
    getNewInfoMenu: [],
    msg: 0
  },
  mutations: {
    SET_TOKEN: (state, token) => {
      state.token = token
    },
    SET_NAME: (state, name) => {
      state.name = name
    },
    SET_AVATAR: (state, avatar) => {
      state.avatar = avatar
    },
    SET_ROLES: (state, roles) => {
      state.roles = roles
    },
    SET_USERNAME: (state, data) => {
      state.username = data
    },
    SET_USERID: (state, data) => {
      state.userid = data
    },
    SET_USER: (state, data) => {
      state.userinfo = data
    },
    SET_NEW_USER_MENU: (state, data) => {
      state.getNewInfoMenu = data
    },
    SET_MSG: (state, data) => {
      state.msg = data
    }
  },

  actions: {
    // sso登录
    ssoLogin({ commit }, data) {
      return new Promise((resolve, reject) => {
        ssologin()
          .then(response => {
            resolve(response)
          })
          .catch(error => {
            reject(error)
          })
      })
    },
    async getMsgCount({ commit }, data) {
      const res = await msgApi.getList(data)
      if (res.data) {
        commit('SET_MSG', res.data.total)
      }
      return res
    },
    getssoinfo({ commit }, data) {
      return getuserInfo({ data: `${data}` })
    },
    async GetNewInfoMenu({ commit }, data) {
      const res = await newUser.userinfo()
      if (res.data) {
        commit('SET_NEW_USER_MENU', res.data.menu)
      }
      return res
    },
    Login({ commit }, userInfo) {
      const username = userInfo.username.trim()
      return new Promise((resolve, reject) => {
        login({ ...userInfo, username })
          .then(res => {
            const response = res.data
            if (res.retcode === 0) {
              if (res.data) {
                const { id, username } = response.user || {}
                commit('SET_TOKEN', response.Authorization)
                localStorage.setItem('token', response.Authorization)
                localStorage.setItem('username', username)
                localStorage.setItem('userid', id)
                localStorage.setItem('user', JSON.stringify(response.user))
                commit('SET_USERNAME', username)
                commit('SET_USERID', id)
                commit('SET_USER', response.user)
                resolve(response)
              }
            } else {
              reject(response)
            }
          })
          .catch(error => {
            reject(error)
          })
      })
    },
    LogOut({ commit }) {
      commit('SET_TOKEN', '')
      commit('SET_NAME', '')
      commit('SET_ROLES', [])
      commit('SET_USERNAME', '')
      commit('SET_USERID', '')
      commit('SET_USER', {})
      return new Promise((resolve, reject) => {
        logout()
          .then(res => {
            localStorage.removeItem('token')
            localStorage.removeItem('username')
            localStorage.removeItem('userid')
            commit('SET_TOKEN', '')
            commit('SET_NAME', '')
            commit('SET_ROLES', [])
            commit('SET_USERNAME', '')
            commit('SET_USERID', '')
            commit('SET_USER', {})
            removeToken()
            resolve()
          })
          .catch(error => {
            reject(error)
          })
      })
    },
    UpdateUserInfo({ commit }, data) {
      commit('SET_USER', data)
    },
    ResetPwd({ commit }, data) {
      return new Promise((resolve, reject) => {
        resetpwd(data)
          .then(res => {
            commit('SET_TOKEN', '')
            commit('SET_NAME', '')
            commit('SET_ROLES', [])
            commit('SET_USERNAME', '')
            commit('SET_USERID', '')
            removeToken()
            resolve()
          })
          .catch(error => {
            reject(error)
          })
      })
    },
    UpdatePwd({ commit }, data) {
      return new Promise((resolve, reject) => {
        updatePwd(data)
          .then(res => {
            commit('SET_TOKEN', '')
            commit('SET_NAME', '')
            commit('SET_ROLES', [])
            commit('SET_USERNAME', '')
            commit('SET_USERID', '')
            removeToken()
            resolve()
          })
          .catch(error => {
            reject(error)
          })
      })
    }
  }
}

export default user
