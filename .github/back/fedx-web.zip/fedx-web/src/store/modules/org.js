import orgApi from '@/api/org'

export default {
  namespaced: true,
  state: {
    tableList: [],
    orgDetail: {}
  },
  mutations: {
    SET_ORG_LIST(state, data) {
      state.tableList = data
    },
    SET_ORG_DETAIL(state, data) {
      state.orgDetail = data || {}
    }
  },
  actions: {
    async getOrgList({ commit }, data) {
      const res = await orgApi.list(data)
      commit('SET_ORG_LIST', res.data.data)
      return res
    },
    async getOrgDetail({ commit }, data) {
      const res = await orgApi.detail(data)
      commit('SET_ORG_DETAIL', res.data)
      return res
    },
    async saveOrg({ commit }, data) {
      const res = await orgApi.save(data)
      commit('SET_ORG_DETAIL')
      return res
    },
    async updateOrg({ commit }, data) {
      const res = await orgApi.update(data)
      commit('SET_ORG_DETAIL')
      return res
    },
    async removeOrg({ commit }, data) {
      const res = await orgApi.remove(data)
      return res
    }
  }
}
