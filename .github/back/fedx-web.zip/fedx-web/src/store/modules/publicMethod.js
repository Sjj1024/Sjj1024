export function saveObj(obj, name, show) {
  // 每次最新的对象
  localStorage.removeItem(`${name}`)
  localStorage.setItem(`${name}`, JSON.stringify(obj))
  if (show) {
    console.log(`${name}`, JSON.stringify(obj), JSON.parse(localStorage.getItem(`${name}`)))
  }
}
