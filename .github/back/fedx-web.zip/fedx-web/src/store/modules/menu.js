import Cookies from 'js-cookie'
import { saveObj } from './publicMethod'
const navBar = {
  state: {
    navStatus: Cookies.get('navbarStatus') ? !+Cookies.get('navbarStatus') : 0,
    isOpenMenu: !+Cookies.get('isOpenMenuStatus'),
    visitedViews: [],
    btnAuth: []
  },

  mutations: {
    DELETE_OTHER_ROUTE_VIEWS_BY_INDEX: (state, payload) => {
      const routes = state.visitedViews.slice(payload, payload + 1)
      state.visitedViews = [...routes]
      saveObj(state.visitedViews, 'visitedViews', false)
    },
    DELETE_ROUTE_VIEWS_BY_INDEX: (state, payload) => {
      const routes = state.visitedViews
      routes.splice(payload, 1)
      state.visitedViews = [...routes]
      saveObj(state.visitedViews, 'visitedViews', false)
    },
    DELETE_ROUTE_VIEWS: (state, payload) => {
      const obj = { fullPath: payload.fullPath, meta: { target: payload.meta.target, title: payload.meta.title }, path: payload.path, query: payload.query }
      const index = state.visitedViews.findIndex(
        item => obj.meta.title === item.meta.title
      )
      const routes = state.visitedViews
      routes.splice(index, 1)
      state.visitedViews = [...routes]
      saveObj(state.visitedViews, 'visitedViews', false)
    },
    DELETE_ROUTE_ALL_VIEWS: state => {
      state.visitedViews = []
    },
    ADD_ROUTE_VIEWS: (state, payload) => {
      // console.log('-------------payload',payload)
      const obj = { fullPath: payload.fullPath, meta: { target: payload.meta.target, title: payload.meta.title }, path: payload.path, query: payload.query }
      if (obj.fullPath === '/flowTemplate') {
        console.log(1)
      } else {
        const index = state.visitedViews.findIndex(
          item => obj.meta.title === item.meta.title
        )
        if (index === -1) {
          const routs = state.visitedViews.concat(obj)
          state.visitedViews = [...routs]
        } else {
          const routes = state.visitedViews
          routes.splice(index, 1, obj)
          state.visitedViews = [...routes]
        }
      }
      saveObj(state.visitedViews, 'visitedViews', false)
    },
    TOGGLE_NAVBAR: state => {
      if (state.navStatus) {
        Cookies.set('navbarStatus', 1)
      } else {
        Cookies.set('navbarStatus', 0)
      }
      state.navStatus = !state.navStatus
    },
    TOGGLE_ISOPEN: (state, payload) => {
      if (state.isOpenMenu) {
        Cookies.set('isOpenMenuStatus', 1)
      } else {
        Cookies.set('isOpenMenuStatus', 0)
      }
      state.isOpenMenu = !state.isOpenMenu
    },
    SET_BTN_AUTH: (state, payload) => {
      localStorage.setItem('btnAuth', payload)
      state.btnAuth = payload
    }
  },

  actions: {}
}

export default navBar
