const nameList = ['summary_date', 'dependency_data']

function mergeJob(source, target, nameList) {
  if (!source) {
    source = {}
  }
  const result = {}
  Object.keys(target).forEach(key => {
    if (nameList.indexOf(key) > -1) {
      result[key] = Object.assign({}, source[key], target[key])
    } else {
      result[key] = target[key]
    }
  })
  return result
}

export default {
  namespaced: true,
  state: {
    job: null
  },
  getters: {
    jobId(state) {
      return state.job && state.job.summary_date && state.job.summary_date.job && state.job.summary_date.job.fJobId
    }
  },
  mutations: {
    UPDATE_JOB(state, job) {
      state.job = mergeJob(state.job, job, nameList)
    },
    CLEAN_JOB(state) {
      state.job = null
    }
  },
  actions: {
    updateJob({ commit }, payload) {
      commit('UPDATE_JOB', payload)
    },
    cleanJob({ commit }) {
      commit('CLEAN_JOB')
    }
  }
}
