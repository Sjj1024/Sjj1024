import flApi from '@/api/fldatasets'

export default {
  namespaced: true,
  state: {
    namespaceList: [],
    datasetList: [],
    datasetDetail: {},
    listLoading: false,
    dialogType: '1',
    dialogVisible: false,
    allOrgList: []
  },
  getters: {
    treeData(state) {
      const treeData = [{ dirName: '文件夹名称' }]
      const namespaceList = state.namespaceList
      if (namespaceList && namespaceList instanceof Array) {
        treeData[0].children = namespaceList
      }
      return treeData
    },
    totalCount(state) {
      return state.datasetList.length
    },
    dialogTitle(state) {
      const dialogType = state.dialogType
      return dialogType === '1' ? '添加数据集' : dialogType === '2' ? '修改' : '查看'
    },
    orgOptions(state) {
      const allOrgList = state.allOrgList
      let orgOptions = []
      if (allOrgList instanceof Array) {
        orgOptions = allOrgList.map(item => ({
          id: item.id,
          name: item.name
        }))
      }
      return orgOptions
    }
  },
  mutations: {
    SET_NAMESPACE_LIST(state, data) {
      state.namespaceList = data
    },
    SET_DATASET_LIST(state, data) {
      state.datasetList = data
    },
    SET_DATASET_DETAIL(state, data) {
      state.datasetDetail = data || {}
    },
    SET_LIST_LOADING(state, data) {
      state.listLoading = data
    },
    SET_DIALOG_TYPE(state, data) {
      state.dialogType = data
    },
    SET_DIALOG_VISIBLE(state, data) {
      state.dialogVisible = data
    },
    SET_All_ORG_LIST(state, data) {
      state.allOrgList = data || []
    }
  },
  actions: {
    async getNamespaceList({ commit }, data) {
      const res = await flApi.authnamespacelist(data)
      commit('SET_NAMESPACE_LIST', res.data)
      return res
    },
    async getDatasetList({ commit }, data) {
      commit('SET_LIST_LOADING', true)
      const res = await flApi.authdatasetlist(data)
      commit('SET_DATASET_LIST', res.data)
      commit('SET_LIST_LOADING', false)
      return res
    },
    async getDatasetDetail({ commit }, data) {
      const res = await flApi.authdetail(data)
      commit('SET_DATASET_DETAIL', res.data)
      return res
    },
    async deleteItem({ commit }, data) {
      const res = await flApi.authdelete(data)
      return res
    }
  }
}
