import logoManageApi from '@/api/logomanage'
import img from '@/assets/firm.png'
import imgTwo from '@/assets/logo-white.png'

export default {
  namespaced: true,
  state: {
    updataSuccess: false,
    logoData: []
  },
  getters: {
    getNavTitle(state) {
      let res = 'DataCanvas PPC'
      if (state.logoData.length > 0) {
        res = state.logoData[state.logoData.length - 1].name
      }
      return res
    },
    getNavLogo(state) {
      let res = img
      if (state.logoData.length > 0) {
        res = state.logoData[state.logoData.length - 1].value
      }
      return res
    },
    getLoginTitle(state) {
      let res = 'DataCanvas PPC'
      if (state.logoData.length > 0) {
        res = state.logoData[state.logoData.length - 2].name
      }
      return res
    },
    getLoginLogo(state) {
      let res = imgTwo
      if (state.logoData.length > 0) {
        res = state.logoData[state.logoData.length - 2].value
      }
      return res
    }
  },
  mutations: {
    SET_Logo_Data(state, data) {
      state.logoData = data
    }
  },
  actions: {
    async getLogoData({ commit, state }, data) {
      const res = await logoManageApi.logoQuery(data)
      commit('SET_Logo_Data', res.data)
      if (data) {
        let name = 'DataCanvas'
        let value = img
        if (state.logoData.length > 0) {
          name = state.logoData[state.logoData.length - 2].name
          value = state.logoData[state.logoData.length - 1].value
        }
        data.setTitle(name, value)
      }
      return res
    }
  }
}
