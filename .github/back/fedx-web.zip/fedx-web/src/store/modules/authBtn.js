import { projectApi } from '@/api/project'

export default {
  namespaced: true,
  state: {
    authBtnDetail: {}
  },
  getters: {
    returnAuthBtnDetail(state) {
      return state.authBtnDetail
    }
  },
  mutations: {
    SET_AUTH_DETAIL(state, data) {
      state.authBtnDetail = data
    }
  },
  actions: {
    async GetAuthBtnDetail({ commit }, data) {
      const res = await projectApi.btnRole(data)
      const params = JSON.stringify(res.data)
      localStorage.setItem('btnAuth', params)
      commit('SET_AUTH_DETAIL', res.data)
      return res
    }
  }
}
