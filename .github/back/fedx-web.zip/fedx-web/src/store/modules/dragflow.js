import dragApi from '@/api/dragflow'
import { workFlowApi } from '@/api/flow'
export default {
  namespaced: true,
  state: {
    ListOperatorData: [],
    dialogType: '1',
    dialogVisible: false
  },
  getters: {},
  mutations: {
    SET_DragFlow_ListOperator(state, data) {
      state.ListOperatorData = data
    }
  },
  actions: {
    // 算子清单
    async getDragFlowListOperator({ commit }, data) {
      const res = await dragApi.getListOperator(data)
      commit('SET_DragFlow_ListOperator', res.data)
      return res
    },
    // 工作流详情获取
    async getWorkFlowVersionDetail({ commit }, data) {
      const res = await workFlowApi.getSingleDetail(data)
      return res
    },
    // // 组件参数 获取
    // async getWorkFlowComponentConfig({ commit }, data) {
    //   const res = await dragApi.getWorkFlowComponentConfig(data)
    //   return res
    // },
    // // 组件参数 修改
    // async updateWorkFlowComponentConfig({ commit }, data) {
    //   const res = await dragApi.updateWorkFlowComponentConfig(data)
    //   return res
    // },
    // 画板保存
    async saveWorkFlow({ commit }, data) {
      const res = await dragApi.saveWorkFlow(data)
      return res
    }
  }
}
