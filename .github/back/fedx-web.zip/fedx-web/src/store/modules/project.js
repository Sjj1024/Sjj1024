import { projectApi } from '@/api/project'
// import orgApi from '@/api/org'
import router from '@/router'
export default {
  namespaced: true,
  state: {
    authProject: [],
    projectList: {},
    projectDetail: JSON.parse(localStorage.getItem('projectDetail') || '{}'),
    projectType: [],
    projectName: '',
    orgList: []
  },
  getters: {
    getterAuthtList(state) {
      return state.authProject
    },
    getterProjectList(state) {
      return state.projectList
    },
    getterProjectDetail(state) {
      return state.projectDetail
    },
    getterProjectTypeList(state) {
      return state.projectType
    }
  },
  mutations: {
    SET_AUTH_LIST: (state, data) => {
      state.authProject = [...data]
    },
    SET_PROJECT_LIST: (state, data) => {
      state.projectList = { ...data }
    },
    SET_PROJECT_DETAIL_LIST: (state, data) => {
      state.projectDetail = { ...data }
      localStorage.setItem('projectDetail', JSON.stringify(data))
    },
    SET_PROJECT_TYPE_LIST: (state, data) => {
      state.projectType = [...data]
    },
    SET_ORG_LIST: (state, data) => {
      state.orgList = [...data]
    }
  },
  actions: {
    GetProjectOrg({ commit }, data) {
      const errorMsg = '机构项未获取到'
      console.log(router.currentRoute.params, 'GetProjectOrg')
      return new Promise((resolve, reject) => {
        if (localStorage.getItem('orgSelect')) {
          const list = JSON.parse(localStorage.getItem('orgSelect'))
          if (data.type === 'index') {
            const index = list.findIndex(
              item => +item.proId === +router.currentRoute.params[data.key]
            )
            if (index > 0) {
              resolve(index)
            } else {
              reject(errorMsg)
            }
          } else {
            const [proItem] = list.filter(
              item => +item.proId === +router.currentRoute.params[data.key]
            )
            if (proItem) {
              resolve(proItem)
            } else {
              reject(errorMsg)
            }
          }
        }
      })
    },
    // 项目权限
    AuthList({ commit }, data) {
      return new Promise((resolve, reject) => {
        projectApi
          .getAuthList({ ...data })
          .then(response => {
            commit('SET_AUTH_LIST', response.data)
            resolve(response)
          })
          .catch(error => {
            reject(error)
          })
      })
    },
    // 项目列表
    ProjectList({ commit }, data) {
      return new Promise((resolve, reject) => {
        projectApi
          .getList({ ...data })
          .then(res => {
            commit('SET_PROJECT_LIST', res.data)
            resolve(res)
          })
          .catch(error => {
            reject(error)
          })
      })
    },
    // 项目详情
    ProjectDetail({ commit }, data) {
      return new Promise((resolve, reject) => {
        projectApi
          .getDetail({ ...data })
          .then(res => {
            commit('SET_PROJECT_DETAIL_LIST', res.data)
            resolve(res)
          })
          .catch(error => {
            reject(error)
          })
      })
    },
    // 项目下拉列表
    ProjectTypeList({ commit }, data) {
      return new Promise((resolve, reject) => {
        projectApi
          .projectTypeList({ ...data })
          .then(res => {
            commit('SET_PROJECT_TYPE_LIST', res.data)
            resolve(res)
          })
          .catch(error => {
            reject(error)
          })
      })
    },
    // 项目新建
    ProjectAdd({ commit }, data) {
      return new Promise((resolve, reject) => {
        projectApi
          .add({ ...data })
          .then(res => {
            resolve(res)
          })
          .catch(error => {
            reject(error)
          })
      })
    },
    // 项目编辑
    ProjectUpdate({ commit }, data) {
      return new Promise((resolve, reject) => {
        projectApi
          .update({ ...data })
          .then(res => {
            resolve(res)
          })
          .catch(error => {
            reject(error)
          })
      })
    },
    // 项目删除
    ProjectDelete({ commit }, data) {
      return new Promise((resolve, reject) => {
        projectApi
          .deletePj({ ...data })
          .then(res => {
            resolve(res)
          })
          .catch(error => {
            reject(error)
          })
      })
    },
    // 根据项目id查询机构
    OrgByProjectId({ commit }, data) {
      return new Promise((resolve, reject) => {
        projectApi
          .orgByProjectId({ ...data })
          .then(res => {
            commit('SET_ORG_LIST', res.data)
            resolve(res)
          })
          .catch(error => {
            reject(error)
          })
      })
    },
    ListOperator({ commit }, data) {
      return new Promise((resolve, reject) => {
        projectApi
          .getListOperator({ ...data })
          .then(res => {
            resolve(res)
          })
          .catch(error => {
            reject(error)
          })
      })
    }
  }
}
