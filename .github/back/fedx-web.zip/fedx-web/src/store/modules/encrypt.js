import encryptApi from '@/api/encrypt'

export default {
  namespaced: true,
  state: {
    EnycrptTableData: [],
    EnycrptAddData: {},
    EnycrptUpdateData: {},
    EnycrptOwnOrgData: {},
    dialogType: '1',
    dialogVisible: false,
    encryptionTypeList: []
  },
  getters: {
  },
  mutations: {
    SET_Encrytion_List(state, data) {
      state.encryptionTypeList = [...data]
    },
    SET_Enycrpt_OwnOrg(state, data) {
      state.EnycrptOwnOrgData = data
    },
    SET_Enycrpt_QUERY(state, data) {
      state.EnycrptTableData = data
    },
    SET_Enycrpt_Add(state, data) {
      state.EnycrptAddData = data || {}
    },
    SET_Enycrpt_Update(state, data) {
      state.EnycrptUpdateData = data || {}
    },
    SET_Enycrpt_Del(state, data) {
      state.EnycrptDelData = data || {}
    }
  },
  actions: {
    async getEncryptions({ commit }, data) {
      const res = await encryptApi.getEncryptions(data)
      commit('SET_Encrytion_List', res.data)
      return res
    },
    async getEnycrptAdd({ commit }, data) {
      const res = await encryptApi.getAdd(data)
      commit('SET_Enycrpt_Add', res.data)
      return res
    },
    async getEnycrptUpdate({ commit }, data) {
      const res = await encryptApi.getUpdate(data)
      commit('SET_Enycrpt_Update', res.data)
      return res
    },
    async getEnycrptDel({ commit }, data) {
      const res = await encryptApi.getdel(data)
      commit('SET_Enycrpt_Del', res.data)
      return res
    },
    async getEnycrptQuery({ commit }, data) {
      const res = await encryptApi.getQuery(data)
      commit('SET_Enycrpt_QUERY', res.data)
      return res
    },
    async getEnycrptCheck({ commit }, data) {
      const res = await encryptApi.getCheck(data)
      // commit('SET_Enycrpt_Check', res.data)
      return res
    },
    async getEnycrptqueryOwnOrg({ commit }, data) {
      const res = await encryptApi.queryOwnOrg(data)
      commit('SET_Enycrpt_OwnOrg', res.data)
      return res
    }
  }
}
