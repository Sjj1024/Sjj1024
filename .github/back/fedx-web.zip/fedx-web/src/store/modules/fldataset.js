import flApi from '@/api/fldatasets'
import datasetsApi from '@/api/flfate'
// import orgApi from '@/api/org'

export default {
  namespaced: true,
  state: {
    namespaceList: [],
    datasetList: {
      list: []
    },
    datasetPagination: {
      pageNum: 1,
      pageSize: 10
    },
    datasetDetail: {
      isEncry: true,
      useData: [],
      authData: []
    },
    listLoading: false,
    dialogType: '1',
    dialogVisible: false,
    datasetAuditList: [],
    datasettf: false,
    allOrgList: [],
    useDataOption: [],
    authDataOption: []
  },
  getters: {
    treeData(state) {
      const treeData = [{ dirName: '文件夹名称' }]
      const namespaceList = state.namespaceList
      if (namespaceList && namespaceList instanceof Array) {
        treeData[0].children = namespaceList
      }
      return treeData
    },
    totalCount(state) {
      console.log(state.datasetList.length, 'state.datasetList.length')
      return state.datasetList.length
    },
    dialogTitle(state) {
      const dialogType = state.dialogType
      return dialogType === '1'
        ? '添加数据集'
        : dialogType === '2'
          ? '详情'
          : '详情'
    },
    orgOptions(state) {
      const allOrgList = state.allOrgList
      let orgOptions = []
      if (allOrgList instanceof Array) {
        orgOptions = allOrgList.map(item => ({
          id: item.id,
          name: item.name
        }))
      }
      return orgOptions
    }
  },
  mutations: {
    SET_NAMESPACE_LIST(state, data) {
      state.namespaceList = data
    },
    SET_DATASET_LIST(state, data) {
      state.datasetList = data
    },
    Set_datasettf(state, data) {
      state.datasettf = data
    },
    SET_DATASET_DETAIL(state, data) {
      if (data) {
        data['isEncry'] = true
      }
      state.datasetDetail = data || { isEncry: true,
        useData: [],
        authData: [] }
    },
    SET_LIST_LOADING(state, data) {
      state.listLoading = data
    },
    SET_DIALOG_TYPE(state, data) {
      state.dialogType = data
    },
    SET_DIALOG_VISIBLE(state, data) {
      state.dialogVisible = data
    },
    SET_All_ORG_LIST(state, data) {
      state.allOrgList = data || []
    },
    SET_datasetAuditList(state, data) {
      state.datasetAuditList = data || []
    },
    SET_USE_DATA_OPTION(state, payload) {
      state.useDataOption = payload || []
    },
    // authDataOption
    SET_AUTH_DATA_OPTION(state, payload) {
      state.authDataOption = payload || []
    },
    SET_DATASET_PAGINATION(state, payload) {
      state.datasetPagination = payload
    }
  },
  actions: {
    async getNamespaceList({ commit }, data) {
      const res = await flApi.namespacelist(data)
      commit('SET_NAMESPACE_LIST', res.data)
      return res
    },
    // 数据集提交审核列表
    async getdatasetAuditList({ commit }, data) {
      const res = await flApi.GetdatasetAuditList(data)
      commit('SET_datasetAuditList', res.data)
      return res
    },
    async getDatasetList({ commit }, data) {
      commit('SET_LIST_LOADING', true)
      const spec = !!data.spec
      data.spec && delete data.spec
      const res = await flApi.datasetlist(data)
      commit('SET_LIST_LOADING', false)
      if (spec && res.data.list) {
        commit('SET_DATASET_LIST', res.data.list.map(item => {
          return {
            ...item,
            useData: item.usageRange ? item.usageRange.split(',') : []
          }
        }))
        return { data: res.data.list.map(item => {
          return {
            ...item,
            useData: item.usageRange ? item.usageRange.split(',') : []
          }
        }) }
      } else {
        if (res.data.list) {
          res.data.list = res.data.list.map(item => {
            return {
              ...item,
              useData: item.usageRange ? item.usageRange.split(',') : []
            }
          })
          commit('SET_DATASET_LIST', res.data)
        } else {
          commit('SET_DATASET_LIST', {
            list: res.data.map(item => {
              return {
                ...item,
                useData: item.usageRange ? item.usageRange.split(',') : []
              }
            })
          })
        }

        return res
      }
    },
    // 审核数据集
    async setApprove({ commit }, data) {
      const res = await flApi.setapprove(data)
      return res
    },
    async webGetDatasetLists({ commit }, data) {
      commit('SET_LIST_LOADING', true)
      const res = await datasetsApi.datasetlist(data)
      commit('SET_DATASET_LIST', res.data)
      commit('SET_LIST_LOADING', false)
      return res
    },
    async saveShenHe({ commit }, data) {
      const res = await flApi.tjShenhe(data)
      return res
    },
    async getDatasetDetail({ commit }, data) {
      const res = await flApi.detail(data)
      // 对端的数据集后端没有保存summaryData
      if (res.data.summaryData) {
        var body = JSON.parse(res.data.summaryData)
        if (!(body instanceof Array)) {
          const { data: dataed } = body
          if (dataed && dataed instanceof Array && dataed.length > 1) {
            const header = dataed[0]['header']
            const arr = dataed[1]['content']
            body = [header, ...arr]
          } else {
            body = []
          }
        }
        var head = body.shift()
        res.data['head'] = head
        var body_data = []
        body.forEach(v => {
          var tem = {}
          var index = 0
          head.forEach(k => {
            tem[k] = v[index]
            index++
          })

          body_data.push(tem)
        })
        res.data['body'] = body_data
      } else {
        res.data['body'] = []
      }
      commit('SET_DATASET_DETAIL', res.data)
      return res
    },
    async deleteItem({ commit }, data) {
      const res = await flApi.delete(data)
      return res
    },
    async getAllOrgList({ commit, state }) {
      const allOrgList = [...state.allOrgList]
      if (!allOrgList || !allOrgList.length) {
        const res = await flApi.getaddorg()
        commit('SET_All_ORG_LIST', res.data)
        return res
      }
    },
    async changeHdfs({ commit, state }, data) {
      const res = await flApi.changeHdfs(data)
      //   commit('SET_DATASET_HDFS', res.data)
      return res
    },
    async fileUpload({ commit, state }, data) {
      const res = await flApi.fileUpload(data)
      //   commit('SET_DATASET_HDFS', res.data)
      return res
    },
    async addDataset({ commit }, data) {
      const res = await flApi.add(data)
      return res
    },
    async newAddDataset({ commit }, data) {
      const res = await flApi.newadd(data)
      return res
    },
    async checkData({ commit }, data) {
      const res = await flApi.checkData(data)
      return res
    },
    // 数据用途数据获取
    async getUseDataOption({ commit, state }, payload) {
      try {
        const { data } = await flApi.getUsageRange()
        commit('SET_USE_DATA_OPTION', data)
      } catch (error) {
        console.log(error)
      }
    },
    // 授权展示项获取
    async getAuthDataOption({ commit, state }, payload) {
      try {
        const { data } = await flApi.getColumnDetail()
        commit('SET_AUTH_DATA_OPTION', data)
      } catch (error) {
        console.log(error)
      }
    }
  }
}
