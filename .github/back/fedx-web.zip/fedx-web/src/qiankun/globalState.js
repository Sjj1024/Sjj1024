import { initGlobalState } from 'qiankun'
import store from '../store'
// 定义全局下发的数据
export const initialState = {
  // 当前登录用户
  userInfo: null,
  // 全局配置
  globalConfig: null,
  isOpenMenu: false,
  // 路由数据
  routers: null,
  // 实现子应用直接跳转子应用
  currentRoute: {
    // 当前页面
    currentPage: '',
    // 当前模块
    currentModuleName: ''
  }
}

// 初始化全局下发的数据
export const qiankunActions = initGlobalState(initialState)

// 检测全局下发数据的改变
qiankunActions.onGlobalStateChange(state => {
  // 修改全局下发的数据
  console.log(state, 'state---onGlobalStateChange', store)
  for (const key in state) {
    if (Object.prototype.hasOwnProperty.call(state, key)) {
      const item = state[key]
      initialState[key] = item
    }
  }
})
