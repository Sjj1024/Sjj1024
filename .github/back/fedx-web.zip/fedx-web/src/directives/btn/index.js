export default {
  bind: (el, binding) => {
    if (binding.value) {
      const list = localStorage.getItem('btnAuth').split(',')
      const res = list.some(e => +e === binding.value)
      if (!res) {
        if (el.parentNode) {
          el.parentNode.removeChild(el)
        } else {
          el.style.display = 'none'
        }
      }
    }
  }
}
