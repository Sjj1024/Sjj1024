import Vue from 'vue'
import echarts from 'echarts'
import moment from 'moment'
import ThBtn from './components/thBtnComponent.vue'
import ActionComponent from './components/ActionButton/index'
import element from './utils/element-ui'
import App from './App'
import store from './store'
import router from './router'
import Fragment from 'vue-fragment'
import Editor from 'bin-ace-editor'
import VueCropper from 'vue-cropper'
import translate from './utils/translate'

import '@/styles/index.scss'
import './reset.var.scss'
import '@/assets/iconfont/iconfont.css'

require('brace/mode/json')
require('brace/snippets/json')
require('brace/theme/dracula')

Vue.use(VueCropper)
Vue.use(Fragment.Plugin)
Vue.component(Editor.name, Editor)
// Vue.use(ElementUI, { locale })
Vue.use(element)
Vue.component('throatButton', ThBtn)
Vue.use(ActionComponent)

Vue.config.productionTip = false
Vue.filter('projectTypeFormat', type => {
  return store.getters.projectType[type - 1].label || 'Unknown'
})
// 全局方法挂载
Vue.prototype.$translate = translate
Vue.prototype.$echarts = echarts
Vue.prototype.$moment = moment
moment.locale('zh-cn')

import installDirective from '@/directives'
installDirective(Vue)
import { qiankunActions } from './qiankun/index'
if (!global._babelPolyfill) {
  require('babel-polyfill')
}

Vue.prototype.$actions = qiankunActions
new Vue({
  el: '#mainApp',
  store,
  router,
  render: h => h(App)
})
