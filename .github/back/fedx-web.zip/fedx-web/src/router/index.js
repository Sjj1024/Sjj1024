import Vue from 'vue'
import Router from 'vue-router'
import NProgress from 'nprogress'
import 'nprogress/nprogress.css'
import { getuserInfo } from '@/api/newlogin'
import store from '../store'
import { canToPage } from '@/utils/auth'
Vue.use(Router)
const loginPath = '/login'

/* Layout */
import Layout from '@/layout/Layout.vue'
// 使用 $router.replace做路由跳转：
const originalReplace = Router.prototype.replace
Router.prototype.replace = function replace(location) {
  return originalReplace.call(this, location).catch(err => err)
}
// 解决ElementUI导航栏中的vue-router在3.0版本以上重复点菜单报错问题
const originalPush = Router.prototype.push
Router.prototype.push = function push(location) {
  return originalPush.call(this, location).catch(err => err)
}
/*
ZLM栏目是否展示
roles 权限问题，数组空为都要权限
ZLMchild 为true有子栏目，父亲栏目无跳转
*/
export const newRouter = [
  {
    // 项目管理
    path: '/pj',
    name: 'PJ',
    hidden: true,
    redirect: '/pj/project',
    meta: {
      auth: true,
      title: '项目管理',
      ZLM: true,
      roles: [],
      ZLMchild: false,
      icon: 'el-icon-xmgl_sel'
    },
    component: Layout,
    children: [
      {
        path: '/pj/project',
        meta: { auth: true, title: '项目管理' },
        component: () => import('@/views/pj/project/index')
      },
      // {
      //   path: '/pj/job-list/:id',
      //   name: 'job-list',
      //   meta: { auth: true, title: '作业管理' },
      //   component: () => import('@/views/pj/job-list/index.vue')
      // },
      // {
      //   path: '/pj/authdataset/:id',
      //   name: 'AUTHDATASET',
      //   meta: { auth: true, title: '被授权数据集' },
      //   component: () => import('@/views/pj/authdataset/index.vue')
      // },
      // {
      //   path: '/pj/detail/:id',
      //   name: 'project-detail',
      //   meta: { auth: true, title: '项目详情', activePath: '/pj/project' },
      //   component: () => import('@/views/pj/detail/index.vue')
      // },
      // {
      //   path: '/pj/flow-list/:id',
      //   name: 'FLOWLIST',
      //   meta: { auth: true, title: '工作流' },
      //   component: () => import('@/views/pj/flow-list/index.vue')
      // },
      {
        path: '/pj/history',
        name: 'HISTORY',
        meta: { auth: true, title: '历史记录' },
        component: () => import('@/views/pj/history/index.vue')
      }
      // {
      //   path: '/pj/history/:id',
      //   name: 'HISTORY',
      //   meta: { auth: true, title: '历史记录' },
      //   component: () => import('@/views/pj/history/index.vue')
      // },
      // {
      //   path: '/pj/file-list/:id',
      //   name: 'file-list',
      //   meta: { auth: true, title: '文件列表' },
      //   component: () => import('@/views/pj/file-list/index.vue')
      // },
      // {
      //   path: '/pj/model-list/:id/:orgid',
      //   name: 'MODELLIST',
      //   meta: { auth: true, title: '联邦模型仓库' },
      //   component: () => import('@/views/pj/model-list/index.vue')
      // }
    ]
  },
  {
    // 角色管理
    path: '/license',
    name: 'LICENSE',
    hidden: true,
    redirect: '/sys/license',
    meta: {
      auth: true,
      title: 'License管理',
      roles: [],
      ZLM: true,
      ZLMchild: false,
      icon: 'el-icon-license_sel'
    },
    component: Layout,
    children: [
      {
        path: '/sys/license',
        name: 'LICENSE',
        meta: { auth: true, title: 'License管理' },
        component: () => import('@/views/sys/license/index')
      }
    ]
  },
  {
    // 角色管理
    path: '/role',
    name: 'ROLE',
    hidden: true,
    redirect: '/role/list',
    meta: {
      auth: true,
      title: '角色管理',
      roles: [],
      ZLM: true,
      ZLMchild: false,
      icon: 'el-icon-zysjj_sel'
    },
    component: Layout,
    children: [
      {
        path: '/role/list',
        name: 'ROLELIST',
        meta: { auth: true, title: '角色管理' },
        component: () => import('@/views/role/list/index')
      }
    ]
  },
  {
    // 数据集管理
    path: '/fd',
    name: 'FD',
    hidden: true,
    redirect: '/fd/fldataset',
    meta: {
      auth: true,
      title: '数据集管理',
      roles: [],
      ZLM: false,
      ZLMchild: false,
      icon: 'el-icon-zysjj_sel'
    },
    component: Layout,
    children: [
      // {
      //   path: '/fd/fldataset/:id',
      //   name: 'FLDATASET',
      //   meta: { auth: true, title: '自有数据集' },
      //   component: () => import('@/views/fd/fldataset/index')
      // },
      {
        path: '/fd/fldataset',
        name: 'FLDATASET',
        meta: { auth: true, title: '自有数据集' },
        component: () => import('@/views/fd/fldataset/index')
      }
    ]
  },
  // {
  //   path: '/portal/*',
  //   name: 'portal',
  //   meta: {
  //     auth: true,
  //     title: '工作流模版',
  //     moduleName: 'sub',
  //     ZLM: false,
  //     ZLMchild: false,
  //     icon: 'el-icon-icon_gongzuoliupeizhiguanli'
  //   },
  //   component: Layout
  // },

  {
    // 工作流模板
    path: '/flow',
    name: 'FLOW',
    hidden: true,
    redirect: '/flow/flow-template',
    meta: {
      auth: true,
      title: '工作流模版',
      roles: [],
      ZLM: true,
      ZLMchild: false,
      icon: 'el-icon-icon_gongzuoliupeizhiguanli'
    },
    component: Layout,
    children: [
      {
        path: '/flow/flow-template',
        name: 'dragFlowTemplate',
        component: () => import('@/views/flow/flow-template/index.vue'),
        meta: { auth: true, title: '工作流模版' }
      },
      // {
      //   path: '/flow/drag-flow/template/:name/:id',
      //   name: 'dragFlowTemplate',
      //   component: () => import('@/views/flow/drag-flow/template/index.vue'),
      //   meta: {
      //     auth: true,
      //     title: '工作流模版-编辑算法',
      //     activePath: '/pj/project'
      //   }
      // },
      // {
      //   path: '/flow/drag-flow/editor/:proId/:id',
      //   name: 'dragFlowEditor',
      //   component: () => import('@/views/flow/drag-flow/editor/index.vue'),
      //   meta: { auth: true, title: '工作流-算法', activePath: '/pj/project' }
      // },
      {
        path: '/flow/dashboard',
        name: 'DASHBOARD',
        meta: { auth: true, title: '任务面板', activePath: '/pj/project' },
        component: () => import('@/views/flow/dashboard/index.vue')
      },
      // {
      //   path: '/flow/:flowID/:flowName/:proId',
      //   name: 'JobFlow',
      //   meta: { auth: true, title: '工作流-详情' },
      //   component: () => import('@/views/flow/job-flow/index.vue')
      // },
      {
        path: '/flow/details',
        name: 'JobDetails',
        meta: { auth: true, title: '任务详情' },
        component: () => import('@/views/flow/details/index.vue')
      }
    ]
  },
  {
    path: '/encrypt',
    name: 'encrypt',
    hidden: true,
    redirect: '/encrypt',
    meta: {
      auth: true,
      title: '密钥管理',
      roles: [],
      ZLM: true,
      ZLMchild: false,
      icon: 'el-icon-key'
    },
    component: Layout,
    children: [
      {
        path: '/encrypt',
        name: '密钥管理',
        component: () => import('@/views/encrypt/index'),
        meta: { auth: true, title: '密钥管理' }
      }
    ]
  },

  {
    path: '/menu-test',
    name: 'menu-test',
    hidden: true,
    redirect: '/menu-test',
    meta: {
      auth: true,
      title: '菜单测试',
      roles: [],
      ZLM: true,
      ZLMchild: false,
      icon: 'el-icon-key'
    },
    component: Layout,
    children: [
      {
        path: '/menu-test',
        name: '菜单测试',
        component: () => import('@/views/menu-test/index'),
        meta: { auth: true, title: '菜单测试' }
      }
    ]
  },

  {
    path: '/custom-fedx-web/*',
    name: 'custom-fedx-web1',
    meta: {
      auth: true,
      title: '群体筛选',
      moduleName: 'sub',
      ZLM: false,
      ZLMchild: false,
      icon: 'el-icon-box'
    },
    component: Layout
  },
  {
    path: '/custom-fedx-web',
    name: 'custom-fedx-web2',
    redirect: '/custom-fedx-web/index',
    meta: {
      auth: true,
      title: '群体筛选',
      moduleName: 'sub',
      ZLM: true,
      ZLMchild: false,
      icon: 'el-icon-box'
    },
    component: Layout
  },

  // {
  //   path: '/custormerScreen',
  //   name: 'custormerScreen',
  //   hidden: true,
  //   redirect: '/custormerScreen',
  //   meta: {
  //     auth: true,
  //     title: '群体筛选',
  //     roles: [],
  //     ZLM: true,
  //     ZLMchild: false,
  //     icon: 'el-icon-menu'
  //   },
  //   component: Layout,
  //   children: [
  //     {
  //       path: '/custormerScreen',
  //       name: '群体筛选',
  //       component: () => import('@/views/custormer-screen/index'),
  //       meta: { auth: true, title: '群体筛选' }
  //     }
  //   ]
  // },
  // 菜单管理
  {
    path: '/menu',
    name: 'menu',
    hidden: true,
    redirect: '/menu',
    meta: {
      auth: true,
      title: '菜单管理',
      roles: [],
      ZLM: true,
      ZLMchild: false,
      icon: 'el-icon-menu'
    },
    component: Layout,
    children: [
      {
        path: '/menu',
        name: '菜单管理',
        component: () => import('@/views/menu/index'),
        meta: { auth: true, title: '菜单管理' }
      }
    ]
  },
  {
    // 机构管理
    path: '/jg',
    name: 'JG',
    // hidden: true,
    redirect: '/jg/mechanism',
    meta: {
      auth: true,
      title: '机构管理',
      ZLM: true,
      roles: ['isroles'],
      ZLMchild: false,
      icon: 'el-icon-jggl_sel'
    },
    component: Layout,
    children: [
      {
        path: '/jg/mechanism',
        name: 'MECHANISM',
        meta: { auth: true, title: '机构管理' },
        component: () => import('@/views/jg/mechanism/index')
      }
    ]
  },
  {
    // logo设置
    path: '/custorm-logo',
    name: 'custormlogo',
    // hidden: true,
    redirect: '/custorm-logo/list',
    meta: {
      auth: true,
      title: '设置logo',
      ZLM: true,
      roles: ['isroles'],
      ZLMchild: false,
      icon: 'el-icon-orange'
    },
    component: Layout,
    children: [
      {
        path: '/custorm-logo/list',
        name: 'custormLog',
        meta: { auth: true, title: '设置logo' },
        component: () => import('@/views/custorm-logo/list/index')
      }
    ]
  },
  {
    // 数据源管理
    path: '/datasource',
    name: 'DATASOURCE',
    // hidden: true,
    redirect: '/datasource/list',
    meta: {
      auth: true,
      title: '数据源管理',
      ZLM: true,
      roles: ['isroles'],
      ZLMchild: false,
      icon: 'el-icon-orange'
    },
    component: Layout,
    children: [
      {
        path: '/datasource/list',
        name: 'DATASOURCE',
        meta: { auth: true, title: '数据源管理' },
        component: () => import('@/views/datasource/list/index')
      }
    ]
  },
  // {
  //   path: '/sys/*',
  //   name: 'sysFlowTemplate1',
  //   meta: {
  //     auth: true,
  //     title: '系统管理',
  //     moduleName: 'sub',
  //     ZLM: false,
  //     ZLMchild: false,
  //     icon: 'el-icon-icon_gongzuoliupeizhiguanli'
  //   },
  //   component: Layout
  // },
  {
    // 系统管理
    path: '/sys',
    name: 'SYSTEM',
    hidden: true,
    redirect: '/sys/monitor',
    meta: {
      auth: true,
      title: '系统管理',
      ZLM: true,
      roles: ['isroles'],
      ZLMchild: true,
      icon: 'el-icon-sz_sel'
    },
    component: Layout,
    children: [
      {
        path: '/sys/user-list',
        name: 'USERMANAGE',
        meta: { auth: true, title: '用户管理', ZLM: true, roles: [] },
        component: () => import('@/views/sys/user-list/index')
      },
      {
        path: '/sys/monitor',
        name: 'MONITOR',
        meta: { auth: true, title: '系统监控', ZLM: true, roles: [] },
        component: () => import('@/views/sys/monitor/index')
      },
      {
        path: '/sys/log-static',
        name: 'LOG',
        meta: { auth: true, title: '日志审计', ZLM: true, roles: [] },
        component: () => import('@/views/sys/log-static/index')
      }
    ]
  },
  {
    // 机构管理
    path: '/ex',
    name: 'ex',
    // hidden: true,
    redirect: '/ex/Examine',
    meta: {
      auth: true,
      title: '数据集审核',
      ZLM: true,
      roles: ['isroles'],
      ZLMchild: false,
      icon: 'el-icon-postcard'
    },
    component: Layout,
    children: [
      {
        path: '/ex/Examine',
        name: 'EXAMIBE',
        meta: { auth: true, title: '数据集审核' },
        // component: () => import('@/views/datasetExamine/index')
        component: () => import('@/views/ex/Examine/index')
      }
    ]
  }
]

const list = require.context('@/views', true, /index.vue/)
const routesList = list.keys().map(item => {
  const file = require('@/views' + item.substr(1))
  const left = item.substr(1).replaceAll('[', ':')
  const right = left.replaceAll(']', '')
  return {
    path: right.replace('/index.vue', ''),
    meta: file.default.meta || {},
    component: () => import('@/views' + item.substr(1))
  }
})

const thirdSystem = [
  {
    path: '/custom-fedx-web/*',
    name: 'custom-fedx-web1',
    meta: {
      title: '群体筛选',
      moduleName: 'sub',
      icon: 'el-icon-box'
    },
    component: Layout
  },
  {
    path: '/custom-fedx-web',
    name: 'custom-fedx-web2',
    redirect: '/custom-fedx-web/index',
    meta: {
      title: '群体筛选',
      moduleName: 'sub',
      icon: 'el-icon-box'
    },
    component: Layout
  }
]

const noAuthRoutes = {
  path: '/403',
  meta: { auth: false },
  component: () => import('@/views/403'),
  hidden: true
}

export const routersRoutes = routesList.filter(item => item.path !== '/login')

const childrens = [...routersRoutes, ...thirdSystem, noAuthRoutes]

// static config.json
// [
//   {
//     "id": 7,
//     "imgUrl": "el-icon-zylb_nor",
//     "title": "a链接1111",
//     "type": "a链接",
//     "path": "https://www.baidu.com"
//   },
//   {
//     "id": 8,
//     "imgUrl": "el-icon-zylb_nor",
//     "title": "iframe22",
//     "path": "http://172.20.9.1:31000",
//     "type": "iframe"
//   }
// ]
export const routers = [
  {
    // 项目管理
    path: '/',
    name: 'home-pj',
    hidden: true,
    // redirect: '/pj/project',
    meta: {
      auth: true,
      title: 'home',
      ZLM: true,
      roles: [],
      ZLMchild: false,
      icon: 'el-icon-xmgl_sel'
    },
    component: Layout,
    children: childrens
  },
  {
    path: '/404',
    meta: { auth: false },
    component: () => import('@/views/404'),
    hidden: true
  },
  {
    path: '/login',
    meta: { auth: false },
    component: () => import('@/views/login/index'),
    hidden: true
  },
  { path: '*', meta: { auth: false }, redirect: '/404', hidden: true }
]

const router = new Router({
  mode: 'history',
  base: '/',
  scrollBehavior: () => ({ y: 0 }),
  routes: routers
})

router.beforeEach(async(to, from, next) => {
  // 监听当前用户是否有权限去到to对象 如果没有跳到404页面
  NProgress.start()
  let url = window.location.href.split('=')[1]
  if (url && window.location.href.indexOf('sso=') > -1) {
    url = decodeURI(url)
    try {
      const response = await store.dispatch('user/getssoinfo', `${url}`)
      store.commit('user/SET_TOKEN', url)
      localStorage.setItem('token', url)
      localStorage.setItem('username', response.data.username)
      localStorage.setItem('userid', response.data.id)
      localStorage.setItem('user', JSON.stringify(response.data))
      store.commit('user/SET_USERNAME', response.data.username)
      store.commit('user/SET_USERID', response.data.id)
      store.commit('user/SET_USER', response.data)
      next()
    } catch (err) {
      // console.log('获取失效token', err)
    }
  }
  // 用户登录信息存token
  const token = localStorage.getItem('token')
  // const username = localStorage.getItem('username')
  // const userid = localStorage.getItem('userid')
  // const user = localStorage.getItem('user')
  // store.commit('SET_USERNAME', username)
  // store.commit('SET_USERID', userid)
  // store.commit('SET_USER', JSON.parse(user))
  // 获取用户信息判断当前路径是否合法
  if (to.path !== loginPath) {
    // 如果是登录页则不需要去判断路径是否合法
    getuserInfo({ token }).then(res => {
      localStorage.setItem('username', res.data.username)
      localStorage.setItem('userid', res.data.id)
      localStorage.setItem('user', JSON.stringify(res.data))
      store.commit('user/SET_USERNAME', res.data.username)
      store.commit('user/SET_USERID', res.data.id)
      store.commit('user/SET_USER', res.data)
      // 判断是否有license认证
      // if (res.data.token === '') {
      //   next(loginPath)
      // }
      if (to.path === '/') {
        const url = res.data.menu[0].url
        next(url)
      } else if (to.path === '/404') {
        next('/404')
      } else {
        const hasAuth = canToPage(res.data.menu, to.path)
        if (!hasAuth) {
          // 没有权限直接去403页面
          next('/403')
        }
      }
    }).catch(err => {
      console.log(err)
    })
  }
  next()
})

router.afterEach(() => {
  NProgress.done()
})

export default router
