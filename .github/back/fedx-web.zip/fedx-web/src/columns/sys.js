export const userColumns = [
  {
    key: 'id',
    label: '用户编号',
    minWidth: 80
  },
  {
    key: 'username',
    label: '用户名',
    minWidth: 140
  },
  {
    key: 'name',
    label: '姓名',
    minWidth: 140
  },
  {
    key: 'roleName',
    label: '角色',
    minWidth: 160
  },
  {
    key: 'status',
    label: '状态',
    minWidth: 60,
    type: 'slot'
  },
  // {
  //   key: 'lockStatus',
  //   label: '状态',
  //   minWidth: 60,
  //   type: 'slot'
  // },
  {
    key: 'createDate',
    label: '创建时间',
    minWidth: 160,
    type: 'slot'
  },
  {
    key: 'updateDate',
    label: '修改时间',
    minWidth: 160,
    type: 'slot'
  },
  {
    key: 'action',
    label: '操作',
    type: 'slot',
    width: 100,
    fixed: 'right'
  }
]
