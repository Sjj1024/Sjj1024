export const flowTempColumns = [
  {
    key: 'modelName',
    label: '模版名称'
  },
  {
    key: 'federalMlType',
    label: '工作流类型',
    type: 'slot'
  },
  {
    key: 'createDate',
    label: '创建时间'
  },
  {
    key: 'updateDate',
    label: '修改时间'
  },
  {
    key: 'remark',
    label: '备注'
  },
  {
    key: 'action',
    label: '操作',
    type: 'slot',
    width: '100px'
  }
]
