export const uploadDataset = {
  'thresholdTimes': 10,
  'expireTime': 10,
  'type': 5,
  'labelColumn': '',
  'encryColumn': 'id',
  'computeColumn': 'id,SEX,MARRIAGE,AGE,PAY_0,PAY_2,PAY_3,PAY_4,PAY_5,PAY_6,BILL_AMT3,BILL_AMT5,PAY_AMT2,PAY_AMT3',
  'columns': [
    {
      'name': 'id',
      'type': 'String',
      'remark': 'id字段'
    },
    {
      'name': 'SEX',
      'type': 'Float',
      'remark': ''
    },
    {
      'name': 'MARRIAGE',
      'type': 'Float',
      'remark': ''
    },
    {
      'name': 'AGE',
      'type': 'Float',
      'remark': ''
    },
    {
      'name': 'PAY_0',
      'type': 'Float',
      'remark': ''
    },
    {
      'name': 'PAY_2',
      'type': 'Float',
      'remark': ''
    },
    {
      'name': 'PAY_3',
      'type': 'Float',
      'remark': ''
    },
    {
      'name': 'PAY_4',
      'type': 'Float',
      'remark': ''
    },
    {
      'name': 'PAY_5',
      'type': 'Float',
      'remark': ''
    },
    {
      'name': 'PAY_6',
      'type': 'Float',
      'remark': ''
    },
    {
      'name': 'BILL_AMT3',
      'type': 'Float',
      'remark': ''
    },
    {
      'name': 'BILL_AMT5',
      'type': 'Float',
      'remark': ''
    },
    {
      'name': 'PAY_AMT2',
      'type': 'Float',
      'remark': ''
    },
    {
      'name': 'PAY_AMT3',
      'type': 'Float',
      'remark': ''
    }
  ],
  'summaryData': '{"data":[{"columns":[{"name":"id","type":"String"},{"name":"SEX","type":"Float"},{"name":"MARRIAGE","type":"Float"},{"name":"AGE","type":"Float"},{"name":"PAY_0","type":"Float"},{"name":"PAY_2","type":"Float"},{"name":"PAY_3","type":"Float"},{"name":"PAY_4","type":"Float"},{"name":"PAY_5","type":"Float"},{"name":"PAY_6","type":"Float"},{"name":"BILL_AMT3","type":"Float"},{"name":"BILL_AMT5","type":"Float"},{"name":"PAY_AMT2","type":"Float"},{"name":"PAY_AMT3","type":"Float"}]},{"header":["id","SEX","MARRIAGE","AGE","PAY_0","PAY_2","PAY_3","PAY_4","PAY_5","PAY_6","BILL_AMT3","BILL_AMT5","PAY_AMT2","PAY_AMT3"]},{"content":[["0","2","1","23","0","0","0","0","0","0","115633","46425","5659","4680"],["1","1","2","29","0","0","0","-2","-2","-2","0","0","0","0"],["2","1","1","29","0","0","0","0","0","0","66258","48210","3000","6000"],["3","1","1","46","2","2","2","0","0","0","428712","354852","0","16100"],["4","2","1","34","0","0","0","0","0","0","50446","29844","2200","2270"]]}],"retmsg":"success","retcode":0}',
  'userId': 1,
  'username': 'admin',
  'fileName': 'host.csv',
  'dirName': '123',
  'dataName': 'host10',
  'path': '/data/host.csv',
  'remotePartyIdList': [
    '1000'
  ],
  'remarks': 'ces',
  'projectId': '6449435460065300480',
  'usageRange': '联邦学习,隐匿求交,匿踪查询',
  'datasetDetailToRemotes': [
    {
      'code': 'name',
      'name': '字段名'
    },
    {
      'code': 'type',
      'name': '数据类型'
    }
  ],
  partyId: '2000',
  partyName: 'C',
  applyName: 'A',
  projectName: 'demo',
  createUserName: 'admin',
  createDate: '2023-01-13 13:48:25',
  status: 1
}

export const datasetColumns = [
  {
    key: 'dataName',
    label: '数据集名称',
    minWidth: 160
  },
  {
    key: 'useData',
    label: '数据用途',
    type: 'slot',
    minWidth: 120
  },
  {
    key: 'partyId',
    label: '机构ID',
    minWidth: 120
  },
  {
    key: 'partyName',
    label: '机构名称',
    minWidth: 120
  },
  {
    key: 'type',
    label: '来源',
    minWidth: 100
  },
  {
    key: 'labelColumn',
    label: '是否有目标列',
    minWidth: 120
  },
  {
    key: 'createUserName',
    label: '创建人',
    minWidth: 120
  },
  // {
  //   key: 'remotePartyNames',
  //   label: '授权状态',
  //   minWidth: 140
  // },
  {
    key: 'createDate',
    label: '创建时间',
    minWidth: 160
  },
  {
    key: 'status',
    label: '状态',
    minWidth: 160
  },
  {
    key: 'action',
    label: '操作',
    minWidth: 80
  }
]

export const datasetColumnsGuest = [
  {
    key: 'dataName',
    label: '数据集名称',
    minWidth: 160
  },
  {
    key: 'useData',
    label: '数据用途',
    type: 'slot',
    minWidth: 120
  },
  {
    key: 'partyId',
    label: '机构ID',
    minWidth: 120
  },
  {
    key: 'partyName',
    label: '机构名称',
    minWidth: 120
  },
  {
    key: 'type',
    label: '来源',
    minWidth: 100
  },
  {
    key: 'labelColumn',
    label: '是否有目标列',
    minWidth: 120
  },
  // {
  //   key: 'remotePartyNames',
  //   label: '授权状态',
  //   minWidth: 140
  // },
  {
    key: 'createDate',
    label: '创建时间',
    minWidth: 160
  },
  {
    key: 'status',
    label: '状态',
    minWidth: 160
  },
  {
    key: 'action',
    label: '操作',
    minWidth: 80
  }
]

export const authColumns = [
  {
    key: 'dataName',
    label: '数据集名称',
    minWidth: 160
  },
  {
    key: 'useData',
    label: '数据用途',
    type: 'slot',
    minWidth: 120
  },
  {
    key: 'projectName',
    label: '项目名称',
    minWidth: 120
  },
  {
    key: 'applyName',
    label: '申请机构',
    minWidth: 120
  },
  {
    key: 'createDate',
    label: '创建时间',
    minWidth: 160
  },
  {
    key: 'status',
    label: '状态',
    minWidth: 160
  },
  {
    key: 'action',
    label: '操作',
    minWidth: 80
  }
]

export const datasetDetail = {
  'id': 6455108858829344768,
  'projectId': 6449435460065300480,
  'datasourceId': null,
  'schedulerId': 209,
  'partyId': '2000',
  'namespace': '6449435460065300480',
  'tableName': 'host10',
  'hdfsDestDataPath': '/data/project/6449435460065300480/2023011313572361617441/6449435460065300480_host10.csv',
  'hdfsSrcDataPath': '/data/host.csv',
  'uploadType': 5,
  'status': '已绑定',
  'labelColumn': '',
  'isUse': false,
  'fileSize': '7.43 KiB',
  'fileRows': 65,
  'fileCols': 14,
  'remark': 'ces',
  'isDeleted': false,
  'createUserId': 1,
  'createUserName': 'admin',
  'expireTime': '2023-01-23 13:57:25',
  'thresholdTimes': 10,
  'count': 0,
  'expireFlag': 0,
  'createDate': '2023-01-13 13:58:00',
  'updateDate': '2023-01-13 13:59:47',
  'bizStatus': 1,
  'usageRange': '联邦学习,隐匿求交,匿踪查询',
  'summaryData': '{"data":[{"header":["id","SEX","MARRIAGE","AGE","PAY_0","PAY_2","PAY_3","PAY_4","PAY_5","PAY_6","BILL_AMT3","BILL_AMT5","PAY_AMT2","PAY_AMT3"]},{"content":[["0","2","1","23","0","0","0","0","0","0","115633","46425","5659","4680"],["1","1","2","29","0","0","0","-2","-2","-2","0","0","0","0"],["2","1","1","29","0","0","0","0","0","0","66258","48210","3000","6000"],["3","1","1","46","2","2","2","0","0","0","428712","354852","0","16100"],["4","2","1","34","0","0","0","0","0","0","50446","29844","2200","2270"]]}]}',
  'jobParam': '{"taskType":"LOCAL_2_CLICKHOUSE","columns":[{"index":0,"name":"id","type":"String","isLabel":false,"encrypt":true},{"index":1,"name":"SEX","type":"Float","isLabel":false,"encrypt":false},{"index":2,"name":"MARRIAGE","type":"Float","isLabel":false,"encrypt":false},{"index":3,"name":"AGE","type":"Float","isLabel":false,"encrypt":false},{"index":4,"name":"PAY_0","type":"Float","isLabel":false,"encrypt":false},{"index":5,"name":"PAY_2","type":"Float","isLabel":false,"encrypt":false},{"index":6,"name":"PAY_3","type":"Float","isLabel":false,"encrypt":false},{"index":7,"name":"PAY_4","type":"Float","isLabel":false,"encrypt":false},{"index":8,"name":"PAY_5","type":"Float","isLabel":false,"encrypt":false},{"index":9,"name":"PAY_6","type":"Float","isLabel":false,"encrypt":false},{"index":10,"name":"BILL_AMT3","type":"Float","isLabel":false,"encrypt":false},{"index":11,"name":"BILL_AMT5","type":"Float","isLabel":false,"encrypt":false},{"index":12,"name":"PAY_AMT2","type":"Float","isLabel":false,"encrypt":false},{"index":13,"name":"PAY_AMT3","type":"Float","isLabel":false,"encrypt":false}],"src":{"jdbc":{},"fs":{"path":"/data/host.csv"}},"dst":{"path":"/data/project/6449435460065300480/2023011313572361617441","fileName":"6449435460065300480_host10.csv"}}',
  'encryptColumn': 'id',
  'computeColumn': 'id,SEX,MARRIAGE,AGE,PAY_0,PAY_2,PAY_3,PAY_4,PAY_5,PAY_6,BILL_AMT3,BILL_AMT5,PAY_AMT2,PAY_AMT3',
  'columnDetail': '{"columns":[{"name":"id","type":"String","remark":""},{"name":"SEX","type":"Float","remark":""},{"name":"MARRIAGE","type":"Float","remark":""},{"name":"AGE","type":"Float","remark":""},{"name":"PAY_0","type":"Float","remark":""},{"name":"PAY_2","type":"Float","remark":""},{"name":"PAY_3","type":"Float","remark":""},{"name":"PAY_4","type":"Float","remark":""},{"name":"PAY_5","type":"Float","remark":""},{"name":"PAY_6","type":"Float","remark":""},{"name":"BILL_AMT3","type":"Float","remark":""},{"name":"BILL_AMT5","type":"Float","remark":""},{"name":"PAY_AMT2","type":"Float","remark":""},{"name":"PAY_AMT3","type":"Float","remark":""}],"columnToRemote":[{"code":"name","name":"字段名"},{"code":"type","name":"数据类型"},{"code":"remark","name":"字段说明"}]}',
  'authorizePartyNames': 'A',
  'totalDays': 9,
  'remainDays': 9,
  'remainMinutes': 1435,
  'usageRangeList': null,
  'columnList': [{
    'name': 'id',
    'type': 'String',
    'remark': ''
  }, {
    'name': 'SEX',
    'type': 'Float',
    'remark': ''
  }, {
    'name': 'MARRIAGE',
    'type': 'Float',
    'remark': ''
  }, {
    'name': 'AGE',
    'type': 'Float',
    'remark': ''
  }, {
    'name': 'PAY_0',
    'type': 'Float',
    'remark': ''
  }, {
    'name': 'PAY_2',
    'type': 'Float',
    'remark': ''
  }, {
    'name': 'PAY_3',
    'type': 'Float',
    'remark': ''
  }, {
    'name': 'PAY_4',
    'type': 'Float',
    'remark': ''
  }, {
    'name': 'PAY_5',
    'type': 'Float',
    'remark': ''
  }, {
    'name': 'PAY_6',
    'type': 'Float',
    'remark': ''
  }, {
    'name': 'BILL_AMT3',
    'type': 'Float',
    'remark': ''
  }, {
    'name': 'BILL_AMT5',
    'type': 'Float',
    'remark': ''
  }, {
    'name': 'PAY_AMT2',
    'type': 'Float',
    'remark': ''
  }, {
    'name': 'PAY_AMT3',
    'type': 'Float',
    'remark': ''
  }],
  'datasetDetailToRemotes': [{
    'code': 'name',
    'name': '字段名'
  }, {
    'code': 'type',
    'name': '数据类型'
  }, {
    'code': 'remark',
    'name': '字段说明'
  }],
  'partyName': 'C',
  'needFilter': false
}
