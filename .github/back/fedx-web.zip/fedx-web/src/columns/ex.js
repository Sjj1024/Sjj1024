export const exColumns = [
  {
    key: 'createTime',
    label: '时间',
    minWidth: 160
  },
  {
    key: 'creatorName',
    label: '发起人',
    minWidth: 100
  },
  {
    key: 'projectName',
    label: '项目名称',
    minWidth: 120
  },
  {
    key: 'dataName',
    label: '数据集名称',
    type: 'slot',
    minWidth: 140
  },
  {
    key: 'approveStatus',
    label: '状态',
    minWidth: 120
  },
  {
    key: 'action',
    label: '操作',
    type: 'slot',
    minWidth: 80
  }
]
