export const modelColumns = [
  {
    key: 'name',
    label: '模型名称'
  },
  {
    key: 'workflowName',
    label: '工作流名称'
  },
  {
    key: 'workflowId',
    label: '工作流ID',
    type: 'slot',
    minWidth: 120
  },
  {
    key: 'workflowVersionName',
    label: '工作流版本号',
    type: 'slot',
    width: 110
  },
  {
    key: 'partyNames',
    label: '合作机构名称',
    width: 110
  },
  {
    key: 'createDate',
    label: '提交时间',
    minWidth: 120
  },
  {
    key: 'intro',
    label: '备注',
    minWidth: 120
  },
  // {
  //   key: 'jobStatus',
  //   label: '运行状态',
  //   minWidth: 120
  // },
  {
    key: 'action',
    label: '操作',
    type: 'slot',
    fixed: 'right',
    width: 100
  }
]

export const missionColumns = [
  {
    key: 'eventId',
    label: '工作流ID/模型ID',
    minWidth: 170
  },
  {
    key: 'workflowVersionName',
    type: 'slot',
    label: '版本号'
  },
  {
    key: 'id',
    label: '任务ID',
    type: 'slot',
    minWidth: 170
  },
  {
    key: 'name',
    label: '任务名称'
  },
  {
    key: 'role',
    label: '角色'
  },
  {
    key: 'partyNames',
    label: '合作机构（名称）',
    minWidth: 170
  },
  {
    key: 'startTime',
    label: '开始时间',
    type: 'slot',
    width: 160
  },
  {
    key: 'endTime',
    label: '结束时间',
    type: 'slot',
    width: 160
  },
  {
    key: 'status',
    label: '任务状态',
    type: 'slot',
    width: 100
  },
  {
    key: 'action',
    label: '操作',
    type: 'slot',
    fixed: 'right',
    width: 100
  }
]

export const jobColumns = [
  {
    key: 'id',
    label: '作业ID',
    minWidth: 100
  },
  {
    key: 'userId',
    label: '上传者',
    minWidth: 80
  },
  {
    key: 'jobTypeName',
    label: '作业名称',
    minWidth: 140
  },
  {
    key: 'createdAt',
    label: '开始时间',
    minWidth: 190
  },
  {
    key: 'updatedAt',
    label: '结束时间',
    minWidth: 190
    // sortable: 'custom'
  },
  {
    key: 'duration',
    label: '持续时间',
    minWidth: 140,
    hidden: true
  },
  {
    key: 'jobStatus',
    label: '作业状态',
    minWidth: 110
  },
  {
    key: 'jobType',
    label: '作业类型',
    minWidth: 120
  },
  {
    key: 'action',
    label: '操作',
    minWidth: 100
  }
]

export const flowColumns = [
  {
    key: 'id',
    label: '工作流ID'
  },
  {
    key: 'name',
    label: '工作流名称'
  },
  {
    key: 'status',
    label: '工作流状态',
    type: 'slot'
  },
  // {
  //   key: 'memo',
  //   label: '备注',
  //   minWidth: 160
  // },
  {
    key: 'updateTime',
    label: '修改时间'
  },
  {
    key: 'createTime',
    label: '创建时间'
  },
  {
    key: 'action',
    label: '操作',
    type: 'slot',
    width: 100
  }
]

export const datasetColumns = [
  {
    key: 'tableName',
    label: '数据集名称',
    minWidth: 160
  },
  {
    key: 'useData',
    label: '数据用途',
    type: 'slot',
    minWidth: 120
  },
  {
    key: 'partyId',
    label: '机构ID',
    minWidth: 120
  },
  {
    key: 'partyName',
    label: '机构名称',
    minWidth: 120
  },
  {
    key: 'uploadType',
    label: '来源',
    minWidth: 100
  },
  {
    key: 'labelColumn',
    label: '是否有目标列',
    minWidth: 120
  },
  {
    key: 'createUserName',
    label: '创建人',
    minWidth: 120
  },
  // {
  //   key: 'remotePartyNames',
  //   label: '授权状态',
  //   minWidth: 140
  // },
  {
    key: 'createDate',
    label: '创建时间',
    minWidth: 160
  },
  {
    key: 'status',
    label: '状态',
    minWidth: 100
  },
  {
    key: 'bizStatus',
    label: '业务状态',
    type: 'slot',
    minWidth: 100
  },
  {
    key: 'action',
    label: '操作',
    minWidth: 80
  }
]

export const serviceListColumns = [
  {
    key: 'serviceId',
    label: '服务ID',
    fixed: 'left',
    minWidth: 170
  },
  {
    key: 'serviceName',
    label: '服务名称',
    minWidth: 100
  },
  {
    key: 'modelId',
    label: '模型ID',
    minWidth: 220
  },
  {
    key: 'modelVersionId',
    label: '模型版本（任务ID）',
    minWidth: 200
  },
  {
    key: 'rolePartId',
    label: '角色 & 合作机构ID',
    minWidth: 200
  },
  {
    key: 'status',
    label: '服务状态',
    type: 'slot',
    minWidth: 100
  },
  {
    key: 'serviceType',
    label: '模型类型',
    type: 'slot',
    minWidth: 130
  },
  {
    key: 'creator',
    label: '创建人',
    minWidth: 100
  },
  {
    key: 'createDate',
    label: '创建时间',
    minWidth: 160
  },
  {
    key: 'action',
    label: '操作',
    type: 'slot',
    width: 100,
    fixed: 'right'
  }
]

// 黑名单查询
export const blackQueryColumns = [
  {
    key: 'id',
    label: '服务ID',
    fixed: 'left',
    minWidth: 100
  },
  {
    key: 'serviceName',
    label: '服务名称',
    minWidth: 80
  },
  {
    key: 'partnerName',
    label: '合作机构ID',
    minWidth: 80
  },
  {
    key: 'dataName',
    label: '数据集名称',
    minWidth: 80
  },
  {
    key: 'useColumns',
    label: '使用列(请求/返回)',
    minWidth: 80
  },
  {
    key: 'serviceState',
    label: '服务状态',
    minWidth: 80
  },
  {
    key: 'createPerson',
    label: '创建人',
    minWidth: 80
  },
  {
    key: 'createTime',
    type: 'slot',
    label: '创建时间',
    minWidth: 80
  },
  {
    key: 'editTime',
    type: 'slot',
    label: '修改时间',
    minWidth: 80
  },
  {
    key: 'action',
    label: '操作',
    type: 'slot',
    fixed: 'right',
    width: 150
  }
]

// 匿踪查询Guest表头
export const hiddenGuestColumns = [
  {
    key: 'id',
    label: '服务ID',
    fixed: 'left',
    minWidth: 120
  },
  {
    key: 'serviceName',
    label: '服务名称',
    minWidth: 80
  },
  {
    key: 'partyId',
    label: '合作机构ID/名称',
    minWidth: 80,
    type: 'slot'
  },
  {
    key: 'datasetName',
    label: '数据集名称',
    minWidth: 80
  },
  {
    key: 'columnIn',
    label: '请求列',
    minWidth: 80,
    type: 'slot'
  },
  {
    key: 'columnOut',
    label: '返回列',
    minWidth: 80,
    type: 'slot'
  },
  {
    key: 'status',
    label: '任务状态',
    minWidth: 80,
    type: 'slot'
  },
  {
    key: 'creator',
    label: '创建人',
    minWidth: 80
  },
  {
    key: 'createDate',
    type: 'slot',
    label: '创建时间',
    minWidth: 120
  },
  {
    key: 'updateDate',
    type: 'slot',
    label: '修改时间',
    minWidth: 120
  },
  {
    key: 'action',
    label: '操作',
    type: 'slot',
    fixed: 'right',
    width: 150
  }
]

// 匿踪查询Host表头
export const hiddenHostColumns = [
  {
    key: 'id',
    label: '服务ID',
    fixed: 'left',
    minWidth: 120
  },
  {
    key: 'serviceName',
    label: '服务名称',
    minWidth: 80
  },
  {
    key: 'partyId',
    label: '合作机构ID/名称',
    minWidth: 80
  },
  {
    key: 'datasetName',
    label: '数据集名称',
    minWidth: 80
  },
  {
    key: 'columnOut',
    label: '返回列',
    minWidth: 120,
    type: 'slot'
  },
  {
    key: 'status',
    label: '任务状态',
    minWidth: 80,
    type: 'slot'
  },
  {
    key: 'createDate',
    type: 'slot',
    label: '创建时间',
    minWidth: 120
  },
  {
    key: 'updateDate',
    type: 'slot',
    label: '修改时间',
    minWidth: 120
  },
  {
    key: 'action',
    label: '操作',
    type: 'slot',
    fixed: 'right',
    width: 150
  }
]

// 匿踪求交Guest表头
export const hidenSubmissionGuestColumns = [
  {
    key: 'id',
    label: '隐匿求交ID',
    fixed: 'left',
    minWidth: 110
  },
  {
    key: 'psiName',
    label: '任务名称',
    minWidth: 80
  },
  {
    key: 'partyInfoStr',
    label: '合作机构ID/名称/数据集',
    minWidth: 100
  },
  {
    key: 'fateJobId',
    label: '任务ID',
    minWidth: 100,
    type: 'slot'
  },
  {
    key: 'psiType',
    label: '求交方案',
    minWidth: 60,
    type: 'slot'
  },
  {
    key: 'status',
    label: '任务状态',
    minWidth: 60,
    type: 'slot'
  },
  {
    key: 'time',
    type: 'slot',
    label: '运行时长',
    minWidth: 60
  },
  {
    key: 'creator',
    label: '创建人',
    minWidth: 60
  },
  {
    key: 'createDate',
    type: 'slot',
    label: '创建时间',
    minWidth: 120
  },
  {
    key: 'postStatus',
    type: 'slot',
    label: '发布状态',
    minWidth: 60
  },
  {
    key: 'action',
    label: '操作',
    type: 'slot',
    fixed: 'right',
    width: 150
  }
]

// 匿踪求交Host表头
export const hidenSubmissionHostColumns = [
  {
    key: 'id',
    label: '隐匿求交ID',
    fixed: 'left',
    minWidth: 110
  },
  {
    key: 'psiName',
    label: '任务名称',
    minWidth: 80
  },
  {
    key: 'partyInfoStr',
    label: '合作机构ID/名称/数据集',
    minWidth: 100
  },
  {
    key: 'fateJobId',
    label: '任务ID',
    minWidth: 100,
    type: 'slot'
  },
  {
    key: 'psiType',
    label: '求交方案',
    minWidth: 60,
    type: 'slot'
  },
  {
    key: 'status',
    label: '任务状态',
    minWidth: 60,
    type: 'slot'
  },
  {
    key: 'time',
    type: 'slot',
    label: '运行时长',
    minWidth: 60
  },
  {
    key: 'createDate',
    type: 'slot',
    label: '创建时间',
    minWidth: 120
  },
  {
    key: 'postStatus',
    type: 'slot',
    label: '发布状态',
    minWidth: 60
  },
  {
    key: 'action',
    label: '操作',
    type: 'slot',
    fixed: 'right',
    width: 150
  }
]

// 联合分析
export const unionMpcColumns = [
  {
    key: 'mpcId',
    label: '任务ID',
    fixed: 'left',
    minWidth: 150
  },
  {
    key: 'mpcName',
    label: '任务名称',
    fixed: 'left',
    minWidth: 110
  },
  {
    key: 'partyInfoStr',
    label: '合作机构ID/名称/数据集',
    fixed: 'left',
    minWidth: 170
  },
  {
    key: 'type',
    label: '类型',
    type: 'slot',
    fixed: 'left',
    minWidth: 100
  },
  {
    key: 'status',
    label: '状态',
    fixed: 'left',
    minWidth: 110
  },
  {
    key: 'runTime',
    label: '运行时长',
    type: 'slot',
    fixed: 'left',
    minWidth: 110
  },
  {
    key: 'creator',
    label: '创建人',
    fixed: 'left',
    minWidth: 110
  },
  {
    key: 'createDate',
    label: '创建时间',
    fixed: 'left',
    minWidth: 150
  },
  {
    key: 'action',
    label: '操作',
    type: 'slot',
    fixed: 'right',
    width: 150
  }
]
