export const sourceColumns = [
  {
    key: 'datasourceName',
    label: '数据源名称',
    minWidth: '23%'
  },
  // {
  //   key: 'dbUrl',
  //   label: '数据库地址',
  //   minWidth: 120
  // },
  // {
  //   key: 'dbPort',
  //   label: '数据库端口',
  //   minWidth: 120
  // },
  // {
  //   key: 'dbUsername',
  //   label: '用户名',
  //   minWidth: 120
  // },
  // {
  //   key: 'hivePrincipal',
  //   label: 'hive principal',
  //   minWidth: 120
  // },
  // {
  //   key: 'hiveUrl',
  //   label: 'hive url',
  //   minWidth: 160
  // },
  // {
  //   key: 'isloginbykeytab',
  //   label: '是否认证',
  //   width: 80
  // },
  // {
  //   key: 'localNameservices',
  //   label: 'k8s内部dfs地址',
  //   minWidth: 160
  // },
  {
    key: 'datasourceType',
    label: '数据源类型',
    minWidth: '23%'
  },
  {
    key: 'createDate',
    label: '创建时间',
    minWidth: '23%'
  },
  {
    key: 'updateDate',
    label: '修改时间',
    minWidth: '23%'
  },
  {
    key: 'action',
    label: '操作',
    fixed: 'right',
    minWidth: '8%'
  }
]
