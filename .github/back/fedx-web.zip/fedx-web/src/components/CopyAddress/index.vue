<template>
  <span class="copy-wrapper" @click="copy">
    <el-tooltip class="item" effect="dark" content="拷贝" placement="top">
      <i class="el-icon-copy-document" />
    </el-tooltip>
  </span>
</template>

<script>
import { copyAddress } from '@/utils/index'
export default {
  name: 'CopyAddress',
  props: {
    text: {
      type: String,
      required: true
    }
  },
  methods: {
    copy() {
      copyAddress(this.text, () => {
        this.$message.success('拷贝成功')
      })
    }
  }
}
</script>

<style lang="scss" scoped>
@import '~@/reset.var.scss';
.copy-wrapper {
  font-size: 16px;
  color: $--color-primary;
  cursor: pointer;
  line-height: 21px;
  padding: 0 3px;
}
</style>
