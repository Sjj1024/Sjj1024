<template>
  <div class="el-transfer">
    <transfer-panel
      ref="leftPanel"
      v-bind="$props"
      :data="sourceData"
      :title="titles[0] || '列表1'"
      :default-checked="leftDefaultChecked"
      :placeholder="filterPlaceholder"
      :is-right="false"
      @checked-change="onSourceCheckedChange"
    >
      <slot name="left-footer"></slot>
    </transfer-panel>
    <div class="el-transfer__buttons">
      <el-button
        :class="['el-transfer__button', hasButtonTexts ? 'is-with-texts' : '']"
        :disabled="rightChecked.length === 0"
        type="primary"
        @click.native="addToLeft()"
      >
        <i class="el-icon-arrow-left"></i>
        <span v-if="buttonTexts[0] !== undefined">{{ buttonTexts[0] }}</span>
      </el-button>
      <el-button
        :class="['el-transfer__button', hasButtonTexts ? 'is-with-texts' : '']"
        :disabled="leftChecked.length === 0"
        type="primary"
        @click.native="addToRight"
      >
        <span v-if="buttonTexts[1] !== undefined">{{ buttonTexts[1] }}</span>
        <i class="el-icon-arrow-right"></i>
      </el-button>
    </div>
    <transfer-panel
      ref="rightPanel"
      v-bind="$props"
      :data="targetData"
      :title="titles[1] || '列表2'"
      :default-checked="rightDefaultChecked"
      :placeholder="filterPlaceholder"
      :is-right="true"
      @checked-change="onTargetCheckedChange"
      @remove-user="addToLeft"
      @change-role="changeRole"
    >
      <slot name="right-footer"></slot>
    </transfer-panel>
  </div>
</template>

<script>
/* eslint-disable*/
import TransferPanel from './transfer-panel.vue'

export default {
  name: 'TransferMember',

  components: {
    TransferPanel
  },

  props: {
    data: {
      type: Array,
      default() {
        return []
      }
    },
    titles: {
      type: Array,
      default() {
        return []
      }
    },
    buttonTexts: {
      type: Array,
      default() {
        return []
      }
    },
    filterPlaceholder: {
      type: String,
      default: ''
    },
    filterMethod: Function,
    leftDefaultChecked: {
      type: Array,
      default() {
        return []
      }
    },
    rightDefaultChecked: {
      type: Array,
      default() {
        return []
      }
    },
    renderContent: Function,
    value: {
      type: Array,
      default() {
        return []
      }
    },
    format: {
      type: Object,
      default() {
        return {}
      }
    },
    filterable: Boolean,
    props: {
      type: Object,
      default() {
        return {
          label: 'label',
          key: 'key',
          disabled: 'disabled'
        }
      }
    },
    targetOrder: {
      type: String,
      default: 'original'
    }
  },

  data() {
    return {
      leftChecked: [],
      rightChecked: []
    }
  },

  computed: {
    dataObj() {
      const key = this.props.key
      return this.data.reduce((o, cur) => (o[cur[key]] = cur) && o, {})
    },

    sourceData() {
      return this.data.filter((item) => {
        // this.value.indexOf(item[this.props.key]) === -1
        let res = true
        if (this.value.length) {
          res = this.value.every((e) => {
            return +e.key !== +item[this.props.key]
          })
        }
        if (res) {
          return item
        }
      })
    },

    targetData() {
      if (this.targetOrder === 'original') {
        return this.data.filter((item) => {
          let res = true
          res = this.value.some((e) => {
            return +e.key === +item[this.props.key]
          })
          if (res) {
            return item
          }
        })
      } else {
        return this.value.reduce((arr, cur) => {
          const curKey = +cur.key
          const obj = this.dataObj[curKey]
          obj.role = cur.role
          if (obj) {
            arr.push(obj)
          }
          return arr
        }, [])
      }
    },

    hasButtonTexts() {
      return this.buttonTexts.length === 2
    }
  },
  // watch: {
  //   value(val) {
  //     this.dispatch('ElFormItem', 'el.form.change', val)
  //   }
  // },

  methods: {
    getMigratingConfig() {
      return {
        props: {
          'footer-format': 'footer-format is renamed to format.'
        }
      }
    },

    onSourceCheckedChange(val, movedKeys) {
      this.leftChecked = val
      if (movedKeys === undefined) return
      this.$emit('left-check-change', val, movedKeys)
    },

    onTargetCheckedChange(val, movedKeys) {
      this.rightChecked = []
      val.map((e) => {
        this.value.map((item) => {
          if (+item.key === +e) {
            this.rightChecked.push(item)
          }
        })
      })
      if (movedKeys === undefined) return
      this.$emit('right-check-change', val, movedKeys)
    },

    addToLeft(obj = {}) {
      let currentValue = this.value.slice()
      if (Object.keys(obj).length) {
        this.rightChecked = [obj]
      }
      this.rightChecked.forEach((item) => {
        currentValue.forEach((e, index) => {
          if (+e.key === +item.key) {
            currentValue.splice(index, 1)
          }
        })
      })
      this.$emit('input', currentValue)

      this.$emit('change', currentValue, 'left', this.rightChecked)
    },

    addToRight() {
      let currentValue = this.value.slice()
      const itemsToBeMoved = []
      const key = this.props.key
      this.data.forEach((item) => {
        const itemKey = item[key]
        if (
          this.leftChecked.indexOf(itemKey) > -1 &&
          this.value.indexOf(itemKey) === -1
        ) {
          // itemsToBeMoved.push(itemKey)
          itemsToBeMoved.push(item)
        }
      })
      currentValue =
        this.targetOrder === 'unshift'
          ? itemsToBeMoved.concat(currentValue)
          : currentValue.concat(itemsToBeMoved)
      this.$emit('input', currentValue)
      this.$emit('change', currentValue, 'right', this.leftChecked)
    },

    changeRole(obj) {
      let currentValue = this.value.slice()
      const key = this.props.key
      currentValue = currentValue.map((item) => {
        if (+item[key] === +obj[key]) {
          return obj
        } else {
          return item
        }
      })
      
      this.$emit('input', currentValue)
    },

    clearQuery(which) {
      if (which === 'left') {
        this.$refs.leftPanel.query = ''
      } else if (which === 'right') {
        this.$refs.rightPanel.query = ''
      }
    }
  }
}
</script>
