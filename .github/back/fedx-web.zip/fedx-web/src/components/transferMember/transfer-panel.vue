<template>
  <div :class="['el-transfer-panel', isRight?'isRight' : '']">
    <p class="el-transfer-panel__header">
      <el-checkbox
        :indeterminate="isIndeterminate"
        v-model="allChecked"
        @change="handleAllCheckedChange"
      >
        {{ title }}
        <span>{{ checkedSummary }}</span>
      </el-checkbox>
    </p>

    <div :class="['el-transfer-panel__body', hasFooter ? 'is-with-footer' : '']">
      <el-input
        v-if="filterable"
        v-model="query"
        :placeholder="placeholder"
        size="small"
        class="el-transfer-panel__filter"
        @mouseenter.native="inputHover = true"
        @mouseleave.native="inputHover = false"
      >
        <i
          slot="prefix"
          :class="['el-input__icon', 'el-icon-' + inputIcon]"
          @click="clearQuery"
        ></i>
      </el-input>
      <el-checkbox-group
        v-show="!hasNoMatch && data.length > 0"
        v-model="checked"
        :class="{ 'is-filterable': filterable }"
        class="el-transfer-panel__list"
      >
        <div
          v-for="item in filteredData"
          :key="item[keyProp]"
          :class="isRight?'isRight_item':''"
        >
          <el-checkbox
            :label="item[keyProp]"
            :disabled="item[disabledProp]"
            class="el-transfer-panel__item"
          >
            <option-content :option="item"></option-content>
          </el-checkbox>
          <el-select
            v-if="isRight"
            v-model="item.role"
            :disabled="item[disabledProp]"
            placeholder="请选择"
            size="mini"
            class="role_select"
            @change="changeRole(item)"
          >
            <el-option
              v-for="obj in roleList"
              :key="obj.value"
              :label="obj.label"
              :value="obj.value"
              :disabled="obj.disabled"
            >
            </el-option>
          </el-select>
          <el-button
            v-if="isRight"
            :disabled="item[disabledProp]"
            size="mini"
            type="primary"
            class="remove"
            @click="removeUser(item)"
          >移出</el-button>
        </div>
      </el-checkbox-group>
      <p
        v-show="hasNoMatch"
        class="el-transfer-panel__empty"
      >无匹配数据</p>
      <p
        v-show="data.length === 0 && !hasNoMatch"
        class="el-transfer-panel__empty"
      >无数据</p>
    </div>
    <p
      v-if="hasFooter"
      class="el-transfer-panel__footer"
    >
      <slot></slot>
    </p>
  </div>
</template>

<script>
/* eslint-disable*/

export default {
  name: 'TransferMemberPanel',

  componentName: 'TransferMemberPanel',

  components: {
    OptionContent: {
      props: {
        option: Object
      },
      render(h) {
        const getParent = (vm) => {
          if (vm.$options.componentName === 'TransferMemberPanel') {
            return vm
          } else if (vm.$parent) {
            return getParent(vm.$parent)
          } else {
            return vm
          }
        }
        const panel = getParent(this)
        const transfer = panel.$parent || panel
        return panel.renderContent ? (
          panel.renderContent(h, this.option)
        ) : transfer.$scopedSlots.default ? (
          transfer.$scopedSlots.default({ option: this.option })
        ) : (
          <span>
            {this.option[panel.labelProp] || this.option[panel.keyProp]}
          </span>
        )
      }
    }
  },

  props: {
    data: {
      type: Array,
      default() {
        return []
      }
    },
    renderContent: Function,
    placeholder: String,
    isRight: Boolean,
    title: String,
    filterable: Boolean,
    format: Object,
    filterMethod: Function,
    defaultChecked: Array,
    props: Object
  },

  data() {
    return {
      checked: [],
      allChecked: false,
      query: '',
      inputHover: false,
      checkChangeByUser: true,
      roleList: [
        { label: 'owner', value: 0, disabled: true },
        { label: 'contributor', value: 1 },
        { label: 'viewer', value: 2 }
      ]
    }
  },

  watch: {
    checked(val, oldVal) {
      this.updateAllChecked()
      if (this.checkChangeByUser) {
        const movedKeys = val
          .concat(oldVal)
          .filter((v) => val.indexOf(v) === -1 || oldVal.indexOf(v) === -1)
        this.$emit('checked-change', val, movedKeys)
      } else {
        this.$emit('checked-change', val)
        this.checkChangeByUser = true
      }
    },

    data() {
      const checked = []
      const filteredDataKeys = this.filteredData.map(
        (item) => item[this.keyProp]
      )
      this.checked.forEach((item) => {
        if (filteredDataKeys.indexOf(item) > -1) {
          checked.push(item)
        }
      })
      this.checkChangeByUser = false
      this.checked = checked
    },

    checkableData() {
      this.updateAllChecked()
    },

    defaultChecked: {
      immediate: true,
      handler(val, oldVal) {
        if (
          oldVal &&
          val.length === oldVal.length &&
          val.every((item) => oldVal.indexOf(item) > -1)
        )
          return
        const checked = []
        const checkableDataKeys = this.checkableData.map(
          (item) => item[this.keyProp]
        )
        val.forEach((item) => {
          if (checkableDataKeys.indexOf(item) > -1) {
            checked.push(item)
          }
        })
        this.checkChangeByUser = false
        this.checked = checked
      }
    }
  },

  computed: {
    filteredData() {
      return this.data.filter((item) => {
        if (typeof this.filterMethod === 'function') {
          return this.filterMethod(this.query, item)
        } else {
          const label = item[this.labelProp] || item[this.keyProp].toString()
          // item.role = 1
          return label.toLowerCase().indexOf(this.query.toLowerCase()) > -1
        }
      })
    },

    checkableData() {
      return this.filteredData.filter((item) => !item[this.disabledProp])
    },

    checkedSummary() {
      const checkedLength = this.checked.length
      const dataLength = this.data.length
      const { noChecked, hasChecked } = this.format
      if (noChecked && hasChecked) {
        return checkedLength > 0
          ? hasChecked
              .replace(/\${checked}/g, checkedLength)
              .replace(/\${total}/g, dataLength)
          : noChecked.replace(/\${total}/g, dataLength)
      } else {
        return `${checkedLength}/${dataLength}`
      }
    },

    isIndeterminate() {
      const checkedLength = this.checked.length
      return checkedLength > 0 && checkedLength < this.checkableData.length
    },

    hasNoMatch() {
      return this.query.length > 0 && this.filteredData.length === 0
    },

    inputIcon() {
      return this.query.length > 0 && this.inputHover
        ? 'circle-close'
        : 'search'
    },

    labelProp() {
      return this.props.label || 'label'
    },

    keyProp() {
      return this.props.key || 'key'
    },

    disabledProp() {
      return this.props.disabled || 'disabled'
    },

    hasFooter() {
      return !!this.$slots.default
    }
  },
  methods: {
    removeUser(item) {
      this.$emit('remove-user', item)
    },

    changeRole(item) {
      // 下拉框嵌套太深需强制刷新
      this.$forceUpdate()
      this.$emit('change-role', item)
    },

    updateAllChecked() {
      const checkableDataKeys = this.checkableData.map(
        (item) => item[this.keyProp]
      )
      this.allChecked =
        checkableDataKeys.length > 0 &&
        checkableDataKeys.every((item) => this.checked.indexOf(item) > -1)
    },

    handleAllCheckedChange(value) {
      this.checked = value
        ? this.checkableData.map((item) => item[this.keyProp])
        : []
    },

    clearQuery() {
      if (this.inputIcon === 'circle-close') {
        this.query = ''
      }
    }
  }
}
</script>

<style lang="scss" scoped>
.el-transfer-panel {
  .el-transfer-panel__filter {
    width: 85%;
    margin-bottom: 0;
  }
  &.isRight {
    width: 405px;
    .el-transfer-panel__filter {
      width: 93%;
    }
    .isRight_item {
      display: flex;
      height: 30px;
      /deep/.el-checkbox__label {
        width: 150px;
      }
      .role_select {
        width: 150px;
        bottom: 5px;
        margin-right: 15px;
        height: 25px;
      }
      .remove {
        height: 25px;
        line-height: 10px;
        position: relative;
        top: 3px;
      }
    }
  }
}
</style>