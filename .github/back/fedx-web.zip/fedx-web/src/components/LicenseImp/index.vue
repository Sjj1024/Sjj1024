<template>
  <el-dialog
    :visible.sync="licenseImp"
    :before-close="handleClose"
    title="导入License"
    top="20vh"
    width="40%"
  >
    <div class="license-box">
      <div class="license-input" @click="openFiles">
        <span
          :class="{
            place: fileName === '请选择文件',
            file: fileName !== '请选择文件'
          }"
        >{{ fileName }}</span
        >
      </div>
      <el-button
        size="small"
        icon="el-icon-upload"
        @click="uploadLicense"
      >上传文件</el-button
      >
    </div>
    <span slot="footer" class="dialog-footer">
      <el-button size="small" @click="licenseImp = false">取 消</el-button>
      <el-button
        size="small"
        type="primary"
        @click="uploadLicense"
      >确 定</el-button
      >
    </span>
    <input
      id="open"
      type="file"
      name="filename"
      style="display: none"
      @change="changeFile"
    >
  </el-dialog>
</template>

<script>
import licenseApi from '@/api/license'

export default {
  name: 'LicenseImp',
  data() {
    return {
      licenseImp: false,
      fileName: '请选择文件',
      userId: 0,
      initSys: false,
      postForm: {}
    }
  },
  methods: {
    handleClose(done) {
      this.licenseImp = false
    },
    showImport(userId, initSys) {
      this.licenseImp = true
      this.userId = userId
      this.initSys = initSys
    },
    openFiles() {
      console.log('打开文件对话框')
      document.getElementById('open').click()
    },
    async uploadLicense() {
      // licenseApi.upload()
      this.postForm.append('userId', 1)
      this.postForm.append('initSys', this.initSys)
      console.log('上传license文件-----', this.postForm)
      const res = await licenseApi.upload(this.postForm)
      if (res.retcode === 0) {
        this.$emit('direct')
        this.fileName = '请选择文件'
        this.licenseImp = false
        document.getElementById('open').value = ''
      } else {
        this.$message.error(`导入失败：${res.retMsg}`)
      }
    },
    changeFile() {
      const fu = document.getElementById('open')
      if (fu === null || !fu.files[0]) return
      // console.log('fu---', fu.files[0].name)
      this.fileName = fu.files[0].name
      this.fileSize = fu.files[0].size
      this.postForm = new FormData()
      this.postForm.append('file', fu.files[0])
      // 调用上传接口上传吧
      // console.log('form---', this.postForm)
    }
  }
}
</script>

<style lang="scss" scoped>
.license-box {
  display: flex;
  justify-content: center;
  .license-input {
    width: 320px;
    height: 33px;
    border: 1px solid #aeaeaf;
    line-height: 33px;
    border-radius: 3px;
    padding: 0 5px 0 8px;
    margin-right: 15px;
    cursor: pointer;
    .place {
      color: rgb(159, 158, 158);
    }
    .file{
      color: #222;
    }
  }

  .license-input:hover{
    border: 1px solid rgb(55, 52, 52);
  }
}
</style>
