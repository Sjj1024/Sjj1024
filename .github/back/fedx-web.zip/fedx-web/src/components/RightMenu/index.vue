<template>
  <!--右键菜单-->
  <div
    id="rightMenuDom"
    :style="{ display: rightMenuStatus, top: rightMenuTop, left: rightMenuLeft }"
    class="right-menu"
  >
    <ul>
      <li>
        <div v-for="(item, index) in rightMenuList" :key="index">
          <span
            @click="item.handler(item.index && item.index)"
          >{{ item.text }}</span>
        </div>
      </li>
    </ul>
  </div>
</template>

<script>
export default {
  name: 'RightMenu',
  props: {
    rightMenuStatus: {
      type: String,
      default: ''
    },
    rightMenuTop: {
      type: String,
      default: ''
    },
    rightMenuLeft: {
      type: String,
      default: ''
    },
    rightMenuList: {
      type: Array,
      default: () => []
    }
  }
}
</script>

<style scoped lang="scss">
@import '@/reset.var.scss';
// 右键菜单样式
.right-menu {
  position: fixed;
  left: 0;
  top: 0;
  /* width: 136px; */
  height: auto;
  background-color: #fff;
  box-shadow: 0 2px 15px 1px rgba(113, 120, 129, .3);
  display: none;
  z-index: 200;
  ul {
    padding: 0;
    margin: 0;
    font-size: 15px;
    li {
      list-style: none;
      box-sizing: border-box;
      border-bottom: 1px solid rgb(216, 216, 217);
      &:nth-child(1) {
        padding-top: 2px;
      }
      &:nth-last-child(1) {
        border-bottom: none;
      }
      div {
        height: 30px;
        span {
          font-size: 12px;
          font-weight: 500;
          color: #475669;
          display: block;
          height: 100%;
          line-height:30px;
          padding: 0 16px;
          &:hover {
            background-color: $--color-primary;
            cursor: pointer;
            color: #ffffff;
          }
        }
        // 禁止点击样式
        .disable {
          color: #666666;
          &:hover {
            cursor: not-allowed;
            background-color: #f2f2f2;
            color: #666666;
          }
        }
      }
    }
  }
}
</style>
