<template>
  <el-dialog
    :visible.sync="dialogVisible"
    :close-on-click-modal="false"
    :title="`${actionText}服务`"
    width="600px"
    top="10vh"
    @close="handleClose"
  >
    <div class="content">
      <div>
        <p class="service-desc title">服务：{{ serveItem.serviceName }}</p>
        <p class="service-desc">服务ID：{{ serveItem.id }}</p>
      </div>
      <!-- 删除/下线服务 -->
      <p
        v-if="[1,2,3].includes(action)"
        class="tips-message"
      >{{ `确定要${actionText}该匿踪查询服务吗？` }}</p>
      <!-- 上线服务暂时隐藏 -->
    </div>
    <span
      v-if="action < 4"
      slot="footer"
      class="dialog-footer"
    >
      <el-button
        size="small"
        @click="dialogVisible = false"
      >取 消</el-button>
      <el-button
        size="small"
        type="primary"
        @click="onOk"
      >确 定</el-button>
    </span>
    <div
      v-else
      slot="footer"
      class="dialog-test-footer"
    >
      <el-button
        size="small"
        @click="handleClose"
      >关 闭</el-button>
    </div>
  </el-dialog>
</template>

<script>
import CopyAddress from '../CopyAddress'
import hidenApi from '@/api/hidenTraces'
export default {
  name: 'MessageModal',
  components: { CopyAddress },
  data() {
    return {
      action: 1,
      serveItem: {},
      dialogVisible: false
    }
  },
  computed: {
    actionText() {
      if (this.action === 1) return '上线'
      if (this.action === 2) return '下线'
      return '-'
    }
  },
  methods: {
    show({ action, item }) {
      this.action = action
      this.serveItem = item
      this.dialogVisible = true
    },
    handleClose() {
      this.dialogVisible = false
    },
    async onOk() {
      if (this.action === 1) {
        await hidenApi.onlineHiden({ id: this.serveItem.id })
      } else {
        await hidenApi.offlineHiden({ id: this.serveItem.id })
      }
      this.$message.success('操作成功')
      this.$emit('callback')
      this.dialogVisible = false
    }
  }
}
</script>

<style lang="scss" scoped>
.content {
  padding: 0 20px;
  .service-desc {
    flex: 1;
    padding-left: 16px;
    line-height: 32px;
    color: rgba(0, 0, 0, 0.85);
    font-size: 14px;
    &.title {
      font-size: 16px;
      font-weight: bold;
    }
  }
  .tips-message {
    padding-left: 16px;
    margin-top: 20px;
    font-size: 16px;
    font-weight: 500;
  }
  /deep/ .el-input-number .el-input__inner {
    text-align: center !important;
  }
  .response-box,
  .request-box {
    h3 {
      color: #172b4d;
      font-size: 16px;
      margin-bottom: 10px;
    }
  }
  .request-btn-box {
    text-align: center;
    margin: 20px auto 0;
  }
}
.dialog-test-footer {
  text-align: center;
}
</style>
