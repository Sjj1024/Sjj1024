<template>
  <el-dialog
    :title="modalTitle"
    :visible.sync="visible"
    :before-close="onCancel"
    :close-on-click-modal="false"
    width="500px"
  >
    <el-form
      ref="form"
      :model="form"
      :rules="rules"
      label-width="100px"
      class="job-form"
    >
      <el-form-item label="模版名称" prop="modelName">
        <el-input
          v-model.trim="form.modelName"
          placeholder="请输入模版名称"
          size="small"
          maxlength="30"
          show-word-limit
          style="width: 95%;"
          oninput="value=value.replace(/\//g,'')"
          @blur="modelNameChange"
        />
      </el-form-item>
      <el-form-item label="工作流类型" prop="federalMlType">
        <el-select
          v-model="form.federalMlType"
          style="width: 95%;"
          placeholder="请选择工作流类型"
        >
          <el-option
            v-for="item in typeList"
            :key="item.val"
            :label="item.label"
            :value="item.val"
          />
        </el-select>
      </el-form-item>
      <el-form-item label="模版备注" prop="remark">
        <el-input
          v-model="form.remark"
          :rows="3"
          type="textarea"
          placeholder="请输入模版备注"
          maxlength="50"
          show-word-limit
          style="width: 95%;"
        >
        </el-input>
      </el-form-item>
    </el-form>
    <div slot="footer" class="flex justify-right">
      <el-button size="small" @click="onCancel">取 消</el-button>
      <throatButton
        :loading="submitLoading"
        type="primary"
        size="small"
        style="margin-left: 23px;"
        @click="onConfirm"
      >确 定</throatButton
      >
    </div>
  </el-dialog>
</template>

<script>
import { workFlowApi } from '@/api/flow'
import { mapActions } from 'vuex'
export default {
  name: 'SaveToTemp',
  props: {
    typeList: {
      type: Array,
      default: () => []
    }
  },
  data() {
    return {
      visible: false,
      modalTitle: '新建工作流模版',
      submitLoading: false,
      form: {
        remark: '',
        modelName: '',
        federalMlType: ''
      },
      // 保存时候其他的参数
      ret: {},
      type: 1,
      rules: {
        modelName: [
          { required: true, message: '请输入模版名称', trigger: 'blur' }
        ],
        federalMlType: [
          { required: true, message: '请选择工作流类型', trigger: 'change' }
        ]
      }
    }
  },
  methods: {
    ...mapActions('project', ['ProjectDetail']),
    show(ret = {}) {
      this.visible = true
      this.ret = ret
      this.modalTitle = JSON.stringify(ret) === '{}' ? '新建工作流模版' : '保存为工作流模版'
    },
    modelNameChange(e) {
      this.form.modelName = e.target.value
    },
    onCancel() {
      this.visible = false
      this.submitLoading = false
      this.$refs.form.resetFields()
    },
    onConfirm() {
      this.$refs.form.validate(valid => {
        if (valid) {
          this.submitLoading = true
          const data = { ...this.form, ...this.ret }
          workFlowApi
            .workFlowTemplateSave(data)
            .then(res => {
              this.submitLoading = false
              this.onCancel()
              this.$emit('success', { id: res.data, name: data.modelName })
            })
            .catch(() => {
              this.submitLoading = false
              this.$refs.form.resetFields()
            })
        }
      })
    }
  }
}
</script>

<style lang="scss" scoped>
.job-form .el-select > .el-input .el-input__inner,
.job-form .el-input--suffix .el-input__inner {
  height: 32px !important;
}
.el-textarea__inner {
  font-family: Arial, Helvetica, sans-serif;
}
</style>
