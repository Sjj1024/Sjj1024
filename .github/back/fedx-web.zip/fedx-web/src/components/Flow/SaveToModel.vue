<template>
  <el-dialog
    :title="modalTitle"
    :visible.sync="visible"
    :before-close="onCancel"
    :close-on-click-modal="false"
    width="500px"
  >
    <el-form
      ref="form"
      :model="form"
      :rules="rules"
      label-width="60px"
      class="job-form"
    >
      <el-form-item
        label="名称"
        prop="name"
      >
        <el-input
          v-model.trim="form.name"
          placeholder="请输入模型名称"
          size="small"
          maxlength="30"
          show-word-limit
        />
      </el-form-item>
      <el-form-item
        label="备注"
        prop="intro"
      >
        <el-input
          v-model="form.intro"
          :rows="3"
          type="textarea"
          maxlength="50"
          show-word-limit
          placeholder="请输入模型备注"
        >
        </el-input>
      </el-form-item>
    </el-form>
    <div
      slot="footer"
      class="flex justify-right"
    >
      <el-button
        size="small"
        @click="onCancel"
      >取 消</el-button>
      <throatButton
        :loading="submitLoading"
        type="primary"
        size="small"
        style="margin-left: 23px;"
        @click="onConfirm"
      >确 定</throatButton>
    </div>
  </el-dialog>
</template>

<script>
import _ from 'lodash'
import { modelApi } from '@/api/flow'
import { mapActions } from 'vuex'
export default {
  name: 'SaveToModel',
  data() {
    return {
      visible: false,
      modalTitle: '模型入库',
      submitLoading: false,
      form: {
        intro: '',
        name: ''
      },
      // 保存时候其他的参数
      ret: {},
      type: 1,
      rules: {
        name: [
          { required: true, validator: _.debounce(this.validateName, 600), trigger: 'change' }
        ],
        intro: [{ required: true, message: '请输入模型备注', trigger: 'blur' }]
      }
    }
  },
  methods: {
    ...mapActions('project', ['ProjectDetail']),
    validateName(rule, value, callback) {
      const { projectId } = this.ret
      if (!value) {
        callback(new Error('请输入工作流名称'))
        return
      }
      modelApi.checkName({ projectId, name: value }).then(res => {
        if (res && res.data) {
          callback()
        } else {
          callback(new Error('工作流名称不能重复'))
        }
      })
    },
    show(ret = {}) {
      this.visible = true
      this.ret = ret
    },
    onCancel() {
      this.visible = false
      this.submitLoading = false
      this.$refs.form.resetFields()
    },
    onConfirm() {
      this.$refs.form.validate((valid) => {
        if (valid) {
          this.submitLoading = true
          const data = { ...this.form, ...this.ret }
          modelApi
            .deployModel(data)
            .then((res) => {
              this.submitLoading = false
              this.onCancel()
              this.$emit('success', { id: res.data, name: data.name })
            })
            .catch(() => {
              this.submitLoading = false
              this.$refs.form.resetFields()
            })
        }
      })
    }
  }
}
</script>

<style lang="scss">
.job-form .el-select > .el-input .el-input__inner,
.job-form .el-input--suffix .el-input__inner {
  height: 32px !important;
}
.el-textarea__inner {
  font-family: Arial, Helvetica, sans-serif;
}
</style>
