/* eslint-disable */ 
import registerEdge from './shape/edges/base-edge';

export default (G6, graph) => {
  registerEdge(G6, graph)
}
