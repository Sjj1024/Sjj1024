/* eslint-disable */

export default G6 => {
  G6.registerBehavior("hover-node", {
    getEvents() {
      return {
        "node:mouseenter": "onNodeEnter",
        "node:mouseleave": "onNodeLeave",
      
      };
    },
    shouldBegin(e) {
      return true;
    },

    onNodeEnter(e) {
      this._clearSelected();
      if (!this.shouldBegin(e)) return;
      // 显示当前节点的锚点
      e.item.setState("anchorShow", true); // 二值状态
    },
    // 清空已选
    _clearSelected() {
      const selectedNodes = this.graph.findAllByState(
        "node",
        "nodeState:selected"
      );

      selectedNodes.forEach(node => {
        node.clearStates(["nodeState:selected", "nodeState:hover"]);
      });

      const selectedEdges = this.graph.findAllByState(
        "edge",
        "edgeState:selected"
      );

      selectedEdges.forEach(edge => {
        edge.clearStates(["edgeState:selected", "edgeState:hover"]);
      });
    },
    onNodeLeave(e) {
      this._clearSelected();
      if (!this.shouldBegin(e)) return;
      // 将锚点再次隐藏
      e.item.setState("anchorShow", false); // 二值状态
      this.graph.emit("anchors-hover-leave", e);
    }
  });
};
