<template>
  <div class="iframe-content">
    <iframe id="iframe" ref="iframe" :src="src"></iframe>
  </div>
</template>

<script>
export default {
  props: {
    src: {
      type: String,
      default: () => ''
    }
  }
}
</script>

<style lang="scss" scoped>
#iframe,
.iframe-content {
  width: 100%;
  height: 100%;
  border: 0;
  background-color: transparent;
}
</style>
