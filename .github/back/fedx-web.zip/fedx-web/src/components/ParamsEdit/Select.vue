<template>
  <div>
    <el-select v-model="modelValue" size="mini" style="width: 100%" placeholder="请选择" @change="handleChange">
      <el-option
        v-for="item in options"
        :key="item"
        :label="item"
        :value="item">
      </el-option>
    </el-select>
  </div>
</template>

<script>
export default {
  name: 'Select',
  // 定义要传给外部的数据类型和事件（事件默认是input）
  model: {
    prop: 'value',
    event: 'change'
  },
  props: {
    options: {
      type: Array,
      default: () => []
    },
    value: {
      type: String,
      default: () => ''
    }
  },
  data() {
    return {
      modelValue: this.value
    }
  },
  methods: {
    handleChange(value) {
      this.$emit('change', value)
    }
  }
}
</script>

<style>

</style>
