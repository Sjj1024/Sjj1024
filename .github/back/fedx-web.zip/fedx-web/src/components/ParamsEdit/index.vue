<template>
  <div class="setting">
    <el-tabs v-model="activeName">
      <el-tab-pane
        v-for="role in roles"
        :key="role"
        :label="role"
        :name="role"
      >
        <el-form
          v-loading="formLoading"
          ref="form"
          :model="form[role]"
          class="form-content"
          label-width="240px"
        >
          <!-- 支持三层结构 -->
          <div
            v-for="item in params"
            :key="item.id"
          >
            <div
              v-if="conditionFlag(item, role)"
              class="field-item"
            >
              <p class="field-item-label">
                <span>
                  {{ item.sub_key ? $translate(item.sub_key) + ">" + $translate(item.key) : $translate(item.key) }}
                </span>
                <el-tooltip
                  :content="item.type + ':' + item.name"
                  effect="dark"
                  placement="top"
                >
                  <span class="el-icon-warning-outline"></span>
                </el-tooltip>
              </p>
              <component
                v-if="item.sub_key"
                :is="item.component"
                :options="item.options"
                v-model="form[role][item.sub_key][item.key]"
              />
              <component
                v-else
                :is="item.component"
                :options="item.options"
                v-model="form[role][item.key]"
              />
              <!-- 第二层 -->
              <template v-if="item.children && item.children.length > 0">
                <div
                  v-for="child in item.children"
                  :key="child.id"
                >
                  <div
                    v-if="conditionFlag(child, role)"
                    class="field-item"
                  >
                    <p class="field-item-label">
                      <span></span>{{ child.sub_key ? $translate(child.sub_key) + ">" + $translate(child.key) : $translate(child.key) }}
                      <el-tooltip
                        :content="child.name"
                        effect="dark"
                        placement="top"
                      >
                        <span class="el-icon-warning-outline"></span>
                      </el-tooltip>
                    </p>
                    <component
                      v-if="child.sub_key"
                      :is="child.component"
                      :options="child.options"
                      v-model="form[role][child.sub_key][child.key]"
                    />
                    <component
                      v-else
                      :is="child.component"
                      :options="child.options"
                      v-model="form[role][child.key]"
                    />
                    <!-- 第三层 -->
                    <template v-if="child.children && child.children.length > 0">
                      <div
                        v-for="sun in child.children"
                        :key="sun.id"
                      >
                        <div
                          v-if="conditionFlag(sun, role)"
                          class="field-item"
                        >
                          <p class="field-item-label">
                            <span></span>{{ $translate(sun.sub_key) ? $translate(sun.sub_key) + ">" + $translate(sun.key) : $translate(sun.key) }}
                            <el-tooltip
                              :content="sun.name"
                              effect="dark"
                              placement="top"
                            >
                              <span class="el-icon-warning-outline"></span>
                            </el-tooltip>
                          </p>
                          <component
                            v-if="sun.sub_key"
                            :is="sun.component"
                            :options="sun.options"
                            v-model="form[role][sun.sub_key][sun.key]"
                          />
                          <component
                            v-else
                            :is="sun.component"
                            :options="sun.options"
                            v-model="form[role][sun.key]"
                          />
                        </div>
                      </div>
                    </template>
                  </div>
                </div>
              </template>
            </div>
          </div>
        </el-form>
      </el-tab-pane>
    </el-tabs>
    <div
      v-if="canEdit"
      class="flex justify-center btn-footer"
    >
      <el-button
        size="small"
        @click="closeDialog"
      >取 消</el-button>
      <el-button
        size="small"
        type="primary"
        style="margin-left: 23px"
        @click="handleSubmit"
      >保 存</el-button>
    </div>
  </div>
</template>

<script>
/* eslint-disable */

import _ from 'lodash'
import { paramsApi } from '@/api/flow'
import Select from './Select.vue'
import Input from './Input.vue'
import Radio from './Radio.vue'
import { isVoid, flattenObjArray } from '@/utils/index'

const translateType = {
  int: 'blur',
  float: 'blur',
  text: 'blur',
  list: 'change',
  boolean: 'change'
}

export default {
  name: 'ParamsModel',
  props: ['config', 'canEdit'],
  components: {
    Radio,
    Input,
    Select
  },
  data() {
    return {
      form: {},
      nodeName: '',
      showDialog: false,
      formLoading: false,
      paramsDataset: null,
      translateType,
      params: [],
      noShowParams: [],
      activeName: 'guest',
      roles: ['common', 'guest', 'host']
    }
  },
  methods: {
    setRoles(roles) {
      // 通过roles配置默认激活项，并初始化form表单结构
      this.roles = roles
      this.activeName = roles[0]
      roles.forEach((role) => {
        this.$set(this.form, role, {})
      })
    },
    getFormField(item, role) {
      return this.form[role][item.key]
    },
    conditionFlag(item, role) {
      // 根据condition条件判断是否渲染
      let flag = false
      if (item.condition_field) {
        if (item.sub_key) {
          // 需要区分condition_inner来决定使用外层外层
          if (item.condition_inner) {
            flag =
              this.form[role][item.sub_key][item.condition_field] ===
              item.condition_value
          } else {
            flag =
              this.form[role][item.condition_field] === item.condition_value
          }
        } else {
          flag = this.form[role][item.condition_field] === item.condition_value
        }
      } else {
        flag = true && item.show === 1
      }
      return flag
    },
    getFieldValue(item, ownValue) {
      // 空值时候才取默认值 此处需要注意原本值是0-false等
      let value = isVoid(ownValue) ? item.default : ownValue
      if (item.type === 'json' && value) {
        if (value) {
          // 可能已经转为字符串了 所以需要判断一下
          value = typeof value == 'string' ? value : JSON.stringify(value)
        } else {
          value = item.default
        }
      } else if (item.type === 'list') {
        // list 存在多种情况：null/-1/[]/1,2,3
        value = Array.isArray(value)
          ? JSON.stringify(value)
          : this.isNumber(value)
          ? '' + value
          : value
      } else if (item.type === 'int' || item.type === 'float') {
        // 将数字转为字符串，解决input类型错误
        value = this.isNumber(value) ? '' + value : value
      } else if (item.type === 'str' && value === null) {
        value = 'null'
      }
      if (value === null) {
        value = undefined
      }
      return value
    },
    show({ label, cfg }, paramRoles = ['common'], configJson) {
      // cfg是算子的库中配置，paramRoles是顶部配置项，configJson是图表配置对象
      if (!cfg) {
        this.form = {}
        return false
      }
      this.form = {}
      this.params = []
      this.setRoles(paramRoles)
      this.nodeName = label.toLowerCase()
      this.showDialog = true
      this.formLoading = true
      // 对算子表单结构排序
      cfg.sort((a, b) => a.order - b.order)
      // 扁平化 后台存的是树结构
      this.fields = flattenObjArray(cfg, 'children')
      // 初始化表单数据
      this.fields.forEach((item, index) => {
        const fieldCommonJson =
          configJson.component_parameters.common.hasOwnProperty(label)
            ? configJson.component_parameters.common[label]
            : {}
        const fieldGuestJson = configJson.component_parameters.role.guest[
          '0'
        ].hasOwnProperty(label)
          ? configJson.component_parameters.role.guest['0'][label]
          : {}
        const fieldHostJson = configJson.component_parameters.role.host[
          '0'
        ].hasOwnProperty(label)
          ? configJson.component_parameters.role.host['0'][label]
          : {}
        if (paramRoles.includes('common')) {
          // common,有sub_key需要将此项添加到sub_key中
          this.makeForm(item, 'common', fieldCommonJson)
        } else {
          this.makeForm(item, 'guest', fieldGuestJson)
          this.makeForm(item, 'host', fieldHostJson)
        }
      })
      this.$nextTick(() => {
        this.params = [...cfg]
        this.formLoading = false
      })
    },
    makeForm(item, role, fieldJson) {
      // 组装form表单，多级嵌套
      if (!!item.sub_key) {
        // 先组装第一层，例如tree_param
        this.$set(
          this.form[role],
          item.sub_key,
          this.form[role].hasOwnProperty(item.sub_key)
            ? this.form[role][item.sub_key]
            : {}
        )
        // 然后将key存入sub_key中
        this.$set(
          this.form[role][item.sub_key],
          item.key,
          // this.getFieldValue(item, fieldJson[item.key])
          this.getFieldValue(
            item,
            fieldJson.hasOwnProperty(item.sub_key)
              ? fieldJson[item.sub_key].hasOwnProperty(item.key)
                ? fieldJson[item.sub_key][item.key]
                : ''
              : fieldJson[item.key]
          )
        )
      } else {
        this.$set(
          this.form[role],
          item.key,
          this.getFieldValue(item, fieldJson[item.key])
        )
      }
    },
    closeDialog() {
      this.showDialog = false
      this.$emit('paramsResult', 'cancle')
    },
    isNumber(val) {
      var regPos = /^\d+(\.\d+)?$/ //非负浮点数
      var regNeg =
        /^(-(([0-9]+\.[0-9]*[1-9][0-9]*)|([0-9]*[1-9][0-9]*\.[0-9]+)|([0-9]*[1-9][0-9]*)))$/ //负浮点数
      if (regPos.test(val) || regNeg.test(val)) {
        return true
      } else {
        return false
      }
    },
    parseFormdata(roleForm) {
      // 将form表单深度解析为对象
      let newForm = {}
      for (const key in roleForm) {
        if (Object.hasOwnProperty.call(roleForm, key)) {
          let val = roleForm[key]
          // 判断原始数据类型，并重新赋值
          const field = this.fields.find((item) => {
            return item.key === key
          })
          if (typeof val === 'string') {
            // 判断是不是list或者json
            if (val.includes('[') || val.includes('{')) {
              val = val.replace(/'/gi, '"')
              try {
                // 规定输入list或者json的时候就格式正确，比如数字/布尔就不要带引号
                val = JSON.parse(val)
              } catch (error) {
                console.log('form转换错误', error)
              }
            } else {
              if (field.type === 'str') {
                val = '' + val
              } else if (this.isNumber(val)) {
                val = +val
              } else if (field.type === 'json' && val === '') {
                console.log('是json是空字符串:', field.key)
                val = null
              } else if (field.type === 'list' && val === '') {
                console.log('是list是空字符串:', field.key)
                val = null
              } else if (field.type === 'float' && val === '') {
                console.log('是float是空字符串:', field.key)
                val = null
              } else if (field.type === 'int' && val === '') {
                console.log('是int是空字符串:', field.key)
                val = null
              }
              // val =
              //   field.type === 'str'
              //     ? '' + val
              //     : this.isNumber(val)
              //     ? +val
              //     : val
              if (val === 'null') {
                val = null
              }
            }
          } else {
            // 是对象或者数字或者布尔
            if (typeof val === 'object') {
              // val可能是数组？
              val = this.parseFormdata(val)
            } else if (typeof val === 'undefined') {
              val = null
            } else if (typeof val === 'number') {
              val = field.type === 'str' ? '' + val : val
            }
          }
          newForm[key] = val
        }
      }
      return newForm
    },
    handleSubmit() {
      const data = this.parseFormdata(this.form)
      console.log("handleSubmit-----", data, this.roles);
      // 返回的data包含所有的form数据
      this.$emit('paramsResult', data, this.roles)
    }
  }
}
</script>

<style lang="scss" scoped>
.setting {
  width: 100%;
  .form-content {
    width: 100%;
    overflow: auto;
    overflow-x: hidden;
    padding-right: 10px;
    .el-form-item__label {
      height: 40px;
      display: flex;
      justify-content: flex-end;
      align-items: center;
      line-height: inherit !important;
      word-break: break-all;
      -webkit-line-clamp: 2;
      -webkit-box-orient: vertical;
      overflow: hidden;
      text-overflow: ellipsis;
    }
  }
}
.data-service-wrapper {
  width: 600px;
  padding: 20px;
  border: 1px solid rgb(220, 223, 230);
  border-radius: 10px;
  margin: 10px auto 20px;
  h3 {
    margin-bottom: 10px;
    font-size: 14px;
    color: #606266;
  }
  .data-service-box {
    display: flex;
    flex-wrap: wrap;
    > div {
      width: 50%;
    }
  }
}
.el-form.form-content {
  min-height: 200px;
}
.form-label-160 {
  width: 160px;
}
.el-input-number input {
  text-align: left !important;
}
.form-label-80 {
  width: 80px;
}
.form-content-160 {
  margin-left: 160px;
}
.params-service-wrapper h3 {
  padding-left: 100px;
}
.field-item {
  margin-bottom: 5px;
  .field-item-label {
    line-height: 36px;
    color: #1f2d3d;
    font-size: 16px;
    font-weight: 500;
  }
}
.btn-footer {
  margin-top: 10px;
}
</style>
