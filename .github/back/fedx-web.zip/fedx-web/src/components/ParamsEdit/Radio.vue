<template>
  <div class="radio-group">
    <el-radio-group v-model="modelValue" size="mini" @change="handleChange">
      <el-radio-button :label="true" class="radio-model" >是</el-radio-button>
      <el-radio-button :label="false" class="radio-model">否</el-radio-button>
    </el-radio-group>
  </div>
</template>

<script>
export default {
  name: 'Radio',
  // 定义要传给外部的数据类型和事件（事件默认是input）
  model: {
    prop: 'value',
    event: 'change'
  },
  props: {
    value: {
      type: Boolean,
      default: () => false
    }
  },
  data() {
    return {
      modelValue: this.value
    }
  },
  methods: {
    handleChange(value) {
      this.$emit('change', value)
    }
  }
}
</script>

<style lang="scss" scoped>
// 双击出现阴影
.radio-group .radio-model{
  box-shadow: unset !important;
}
</style>
