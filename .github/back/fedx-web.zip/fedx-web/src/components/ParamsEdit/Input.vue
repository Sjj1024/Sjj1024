<template>
  <div>
    <el-input v-model="modelValue" placeholder="请输入" size="mini" style="width: 100%" @input="handleInput"/>
  </div>
</template>

<script>
export default {
  name: 'Input',
  // 定义要传给外部的数据类型和事件（事件默认是input）
  model: {
    prop: 'value',
    event: 'change'
  },
  props: {
    value: {
      type: String,
      default: () => ''
    }
  },
  data() {
    return {
      modelValue: this.value
    }
  },
  methods: {
    handleInput(value) {
      this.$emit('change', value)
    }
  }
}
</script>

<style>

</style>
