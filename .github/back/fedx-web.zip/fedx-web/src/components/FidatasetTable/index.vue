<template>
  <div>
    <div class="fidatasets">
      <div class="fidatasetLeft">
        <el-checkbox
          v-model="allChecked"
          style="float: left;padding-left: 10px;"
          @change="allcheck"
        >全选</el-checkbox>
        选择计算列
      </div>
      <div class="fidtable">
        <el-table
          :data="dataArr"
          :header-row-class-name="'t-header'"
          header-cell-class-name="headercellname"
          row-class-name="rowname"
          style="width: 100%;"
          element-loading-text="Loading"
          highlight-current-row
          empty-text="无数据"
        >
          <el-table-column
            v-for="item in Object.keys(checkList)"
            :key="item"
            :prop="item"
            show-overflow-tooltip
            min-width="140px"
          >
            <template
              slot="header"
              slot-scope="scope"
            >
              <span
                :a="scope"
                class="check-select"
              >
                <el-checkbox
                  :label="item"
                  v-model="checkList[item]"
                  @change="handleCheckedCitiesChange"
                ></el-checkbox>
                <el-select
                  v-if="true"
                  :disabled="item === 'id'? true : false"
                  v-model="columns[item]"
                  style="width:100px;margin-top: 5px"
                  size="mini"
                  @change="correlationChange"
                >
                  <el-option
                    v-for="(item, index) in optionData"
                    :key="index"
                    :label="item.name"
                    :value="item.value"
                  />
                </el-select>
                <div class="input-wrapper">
                  <el-input v-model="resaultColumns.find(target=> target.name === item).remark" placeholder="字段说明" size="small" maxlength="30" width="100"></el-input>
                </div>

              </span>
            </template>
          </el-table-column>
        </el-table>
      </div>
    </div>
  </div>
</template>
<script>
export default {
  name: 'FidatasetTable',
  props: {
    dataArr: {
      type: Array,
      default: () => {
        return []
      }
    },
    checkListed: {
      type: Object,
      default: () => {
        return {}
      }
    },
    columnsData: {
      type: Object,
      default: () => {
        return {}
      }
    },
    optionData: {
      type: Array,
      default: () => {
        return []
      }
    },
    resaultColumns: {
      type: Array,
      default: () => {
        return []
      }
    }
  },
  data() {
    return {
      checkList: this.checkListed,
      allChecked: true,
      columns: this.columnsData
    }
  },
  watch: {
    checkListed() {
      this.checkList = this.checkListed
      this.handleCheckedCitiesChange(1)
    }
  },
  methods: {
    correlationChange(status) {
      // console.log('------------1',status,this.columns,this.columnsData)
      this.$emit('selectCloumnTypeChange', this.columns)
    },

    handleCheckedCitiesChange(status) {
      let alltf = true
      for (const item in this.checkList) {
        if (!this.checkList[item]) {
          alltf = false
          break
        }
      }
      this.allChecked = alltf
      if (status !== 1) this.$emit('handleSelectionChange', this.checkList)
    },

    allcheck() {
      for (const item in this.checkList) {
        this.checkList[item] = this.allChecked
      }
      this.$emit('handleSelectionChange', this.checkList)
    }
  }
}
</script>

<style lang="scss" scoped>
.fidatasets {
  overflow-y: auto;
  /* display: flex; */
  /* justify-content: start; */
  padding-bottom: 30px;
  .fidatasetLeft {
    width: 100%;
    text-align: center;
    vertical-align: middle;
    font-size: 14px;
    color: #606266;
    background-color: #fafafa;
    line-height: 40px;
    padding: 0 12px 0 0;
    font-weight: 700;
  }
  .fidtable {
    max-width: 600px;
  }

  /deep/ .t-header {
    height: 40px;
    color: rgba(16, 38, 58, 0.85);
    background-color: #fafafa;
    font-size: 14px;
    font-weight: bold;
    text-align: left;
    .is-leaf {
      width: 300px;
      overflow: auto;
    }
  }
  .allcheck {
    background-color: #f1f1f1;
    padding: 5px 10px;
    padding-left: 20px;
  }
  .check-select {
    /* display: flex;
    align-items: center; */
  }
}
.input-wrapper{
  padding-top: 10px;
  /deep/ .el-input--small .el-input__inner{
    width: 100px;
  }
}
</style>
