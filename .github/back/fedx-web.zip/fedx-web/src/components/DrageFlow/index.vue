<template>
  <div class="app-container">
    <div id="canvasPanel" ref="canvasPanel"></div>
  </div>
</template>

<script>
/* eslint-disable */

import G6 from "@antv/g6/dist/g6.min.js";
import registerFactory from "@/components/graph/graph";
import okSvg from "../../assets/ok.svg";

export default {
  data() {
    return {
      mode: "drag-shadow-node",
      graph: {},
      tooltip: "",
      top: 0,
      left: 0,
      breads: null,
      commonParams: {},
      newConfig: {},
      highLight: {
        undo: false,
        redo: false
      },
      configJson: {
        dsl_version: 2,
        initiator: {
          role: "guest",
          party_id: 9999
        },
        role: {
          arbiter: [9999],
          host: [9998],
          guest: [9999]
        },
        job_parameters: {
          common: {
            job_type: "train",
            backend: 0,
            work_mode: 1
          }
        },
        component_parameters: {
          common: {},
          role: {
            guest: {
              0: {
                reader_0: {
                  table: {
                    name: "",
                    namespace: ""
                  }
                }
              }
            },
            host: {
              0: {
                reader_0: {
                  table: {
                    name: "",
                    namespace: "experiment"
                  }
                }
              }
            }
          }
        }
      },
      workflowid: 0,
      // 保存线条样式
      lineStyle: {
        type: "line",
        width: 1
      },
      label: "",
      labelCfg: {
        fontSize: 12,
        style: {
          fill: "#fff"
        }
      },
      node: {
        fill: "",
        lineDash: "none",
        borderColor: "",
        width: 160,
        height: 60,
        shape: "rect-node"
      },
      canvasJson: null,
      nodeShapes: [
        {
          name: "矩形",
          shape: "rect-node"
        }
      ],
      cfgcommon: {},
      res: {},
      headVisible: false,
      configVisible: false,
      config: {},
      tooltip: "",
      top: 0,
      left: 0
    };
  },
  props: ["cwidth", "cheight", "cmode", "cdata"],
  mounted() {
    // 创建画布
    this.$nextTick(() => {
      this.createGraphic();
    });
  },
  destroy() {
    this.graph.destroy();
  },
  methods: {
    createGraphic() {
      const vm = this;
      const grid = new G6.Grid();
      console.log(this.cdata, 'cdata')
       const inner = document.getElementsByClassName("app-main")&&document.getElementsByClassName("app-main")[0].offsetWidth;
       console.log(inner)
      const cfg = registerFactory(G6, {
        width: inner-100,
        height: window.innerHeight,
        // fitView: true,
        fitViewPadding: [80],
        // fitCenter: true,
        // renderer: 'svg',
        layout: {
          type: "" // 位置将固定
        },
        // 所有节点默认配置
        defaultNode: {
          type: "rect-node",
          style: {
            radius: 4,
            width: 200,
            height: 34,
            cursor: "move"
            // fill: "#ecf3ff"
          },
          labelCfg: {
            fontSize: 20,
            style: {
              cursor: "move"
            }
          }
        },
        // 所有边的默认配置
        defaultEdge: {
          type: "cubic-edge", // 扩展了内置边, 有边的事件
          style: {
            radius: 5,
            offset: 15,
            stroke: "#aab7c3",
            lineAppendWidth: 10, // 防止线太细没法点中
            endArrow: true
          }
        },
        // 覆盖全局样式
        nodeStateStyles: {
          "nodeState:default": {
            opacity: 1
          },
          "nodeState:hover": {
            opacity: 0.8
          },
          "nodeState:selected": {
            opacity: 0.9
          }
        },
        // 默认边不同状态下的样式集合
        edgeStateStyles: {
          "edgeState:default": {
            stroke: "#1976d2"
          },
          "edgeState:selected": {
            stroke: "#1976d2"
          },
          "edgeState:hover": {
            animate: true,
            animationType: "dash",
            stroke: "#1976d2"
          }
        },
        modes: {
          // 支持的 behavior
          default: [
            "zoom-canvas",
            "drag-canvas",
            "drag-shadow-node"
          ]
        }
        // ... 其他G6原生入参
      });
      this.graph = new G6.Graph(cfg);
      //   const id = this.$route.params.id;
      // console.log(this.cdata)
      this.cdata && this.graph.read(this.cdata);
      this.graph.fitCenter()
      this.graph.zoomTo(0.7)
    }
  }
};
</script>

<style lang="scss" scoped>
.flow-list {
  width: 100%;
  .breadtitle {
    margin-bottom: 10px;
    span,
    a {
      cursor: pointer;
      font-size: 14px;
      color: rgba(16, 38, 58, 0.65);
    }
  }
  .drag-flow {
    display: flex;
    justify-content: space-between;
    overflow: hidden;
    position: relative;
    .g6-grid-container {
      z-index: 5 !important;
    }
    .g6-component-contextmenu {
      z-index: 20;
    }
    #canvasPanel {
      .g6-component-toolbar {
        left: 50%;
        z-index: 16;
        font-size: 16px;
        border: none;
        transform: translateX(-50%);
        box-shadow: rgba(9, 30, 66, 0.25) 0px 4px 8px -2px,
          rgba(9, 30, 66, 0.08) 0px 0px 0px 1px;
        li {
          line-height: 24px;
          width: 24px;
          margin-right: 10px;
          transition: all 0.2s linear;
          &:last-child {
            margin-right: 0;
          }
          &:hover {
            color: #fff;
            background-color: #1976d2;
            border-radius: 50%;
          }
        }
      }
      & > canvas {
        position: relative;
        z-index: 10;
      }
    }
    .drag-left {
      width: 220px;
      height: calc(100vh - 100px);
      background-color: #fff;
    }
    .drag-center {
      flex: 1;
      position: relative;
      .g6-minimap {
        position: absolute;
        right: 0;
        top: 0;
        z-index: 15;
        background: #fff;
        border: 1px solid rgba(25, 118, 210, 1);
      }
    }
    #configPanel {
      position: absolute;
      top: 0;
      right: 0;
      bottom: 0;
      z-index: 20;
      width: 500px;
      height: calc(100vh - 130px);
      overflow: hidden;
      background: #fff;
      padding: 20px;
      transition: transform 0.3s ease-in-out;
      h4 {
        margin-bottom: 20px;
      }
      .btn-footer {
        position: absolute;
        left: 50%;
        transform: translateX(-50%);
        bottom: 15px;
      }
      box-shadow: 0 0 2px 0 rgba(0, 0, 0, 0.1);
      &.hidden {
        transform: translate(100%, 0);
      }
    }
  }
}

/* 提示框的样式 */
.g6-tooltip {
  position: fixed;
  top: 0;
  left: 0;
  font-size: 12px;
  color: #545454;
  border-radius: 4px;
  border: 1px solid #e2e2e2;
  background-color: rgba(255, 255, 255, 0.9);
  box-shadow: rgb(174, 174, 174) 0 0 10px;
  padding: 10px 8px;
  z-index: 10;
}
</style>
