export default {
  name: 'PTable',
  props: Object.assign({}, {
    columns: {
      type: Array,
      default: () => []
    },
    showPagination: {
      type: Boolean,
      default: true
    },
    getData: {
      type: Function,
      required: true
    },
    selectionChange: {
      type: Function
    },
    pagination: {
      type: Object,
      default: () => ({})
    },
    headerCellClassName: {
      type: String | Function,
      default: ''
    }
  }),
  data() {
    return {
      pageKey: 1,
      pageNum: 1,
      localLoading: false,
      localDataSource: [],
      localPagination: Object.assign({ }, this.pagination)
    }
  },
  created() {
    // const { pageNum } = this.$route.params
    // const localPageNum = this.pageURI && (pageNum && parseInt(pageNum)) || this.pageNum
    this.localPagination = ['auto', true].includes(this.showPagination) && Object.assign({}, this.localPagination, {
      current: 1,
      pageSize: 10,
      showSizeChanger: true
    }) || false
    // this.needTotalList = this.initTotalList(this.columns)
    this.loadData()
  },
  methods: {
    /**
     * 表格重新加载方法
     * 如果参数为 true, 则强制刷新到第一页
     * @param Boolean bool
     */
    refresh(bool = false) {
      bool && (this.localPagination = Object.assign({}, {
        current: 1,
        pageSize: this.localPagination.pageSize
      }))
      // 解决jsx下pagination不更新的问题
      this.pageKey = 0
      this.loadData()
    },
    /**
     * 加载数据方法
     * @param {Object} pagination 分页选项器
     */
    loadData(pagination) {
      this.localLoading = true
      const parameter = {
        pageNum: (pagination && pagination.current) || this.showPagination && this.localPagination.current || this.pageNum,
        pageSize: (pagination && pagination.pageSize) || (this.showPagination && this.localPagination.pageSize) || this.pageSize
      }
      const result = this.getData(parameter)
      // 对接自己的通用数据接口需要修改下方代码中的 r.pageNum, r.totalCount, r.data
      // eslint-disable-next-line
      if ((typeof result === 'object' || typeof result === 'function') && typeof result.then === 'function') {
        result.then(r => {
          this.localPagination = this.showPagination && Object.assign({}, this.localPagination, {
            current: r.data.pageNum, // 返回结果中的当前分页数
            total: r.data.total, // 返回结果中的总记录数
            showSizeChanger: this.showSizeChanger,
            pageSize: (pagination && pagination.pageSize) || this.localPagination.pageSize
          }) || false
          // 解决jsx下pagination不更新的问题
          this.pageKey = parameter.pageNum
          // 为防止删除数据后导致页面当前页面数据长度为 0 ,自动翻页到上一页
          if (r.data.list.length === 0 && this.showPagination && this.localPagination.current > 1) {
            this.localPagination.current--
            this.loadData()
            return
          }

          // 这里用于判断接口是否有返回 r.totalCount 且 this.showPagination = true 且 pageNum 和 pageSize 存在 且 totalCount 小于等于 pageNum * pageSize 的大小
          // 当情况满足时，表示数据不满足分页大小，关闭 table 分页功能
          try {
            if ((['auto', true].includes(this.showPagination) && r.data.total <= (r.data.pageNum * this.localPagination.pageSize))) {
              this.localPagination.hideOnSinglePage = true
            }
          } catch (e) {
            this.localPagination = false
          }
          this.localDataSource = r.data.list // 返回结果中的数组数据
        }).finally(() => {
          this.localLoading = false
        })
      }
    },
    handleSizeChange(val) {
      this.localPagination.pageSize = val
      this.localPagination.current = 1
      this.loadData()
    },
    handleCurrentChange(val) {
      this.localPagination.current = val
      this.loadData()
    }
  },
  render() {
    const { localDataSource, localPagination, columns, localLoading, props, $listeners, pageKey } = this
    return (
      <div class='table-wrapper'>
        <el-table
          data={localDataSource}
          v-loading={localLoading}
          {...{ props, on: $listeners, scopedSlots: { ...this.$scopedSlots }}}
          headerCellClassName={this.$props.headerCellClassName}
        >
          {columns.map((column) => {
            if (column.type === 'slot') {
              return (
                <el-table-column {...{ props: column }} prop={column.key} scopedSlots={{
                  default: props => this.$scopedSlots[column.key]({ ...props })
                }}></el-table-column>
              )
            } else if (column.type === 'selection') {
              return (
                <el-table-column
                  type='selection'
                  width={column.width}>
                </el-table-column>
              )
            } else {
              return (
                <el-table-column {...{ props: column }} prop={column.key}></el-table-column>
              )
            }
          })}
        </el-table>
        <div class='pagination-box'>
          <el-pagination
            background
            key={pageKey}
            layout='total, prev, pager, next, sizes'
            total={localPagination.total}
            page-size={localPagination.pageSize}
            current-page={localPagination.current}
            on-size-change={this.handleSizeChange}
            on-current-change={this.handleCurrentChange}
          >
          </el-pagination>
        </div>
      </div>
    )
  }
}
