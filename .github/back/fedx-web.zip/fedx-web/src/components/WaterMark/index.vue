<template>
  <div
    :id="watermarkWrapperId"
    class="water-mark-wrapper"
  >
    <div
      v-if="userinfo.isWatermark"
      id="watermarkId"
      key="watermarkId"
      :style="styles"
    />
  </div>
</template>

<script>
import { getCanvasUrl, genRandomId, getToday } from './utils'
import { mapGetters } from 'vuex'

export default {
  name: 'WaterMark',
  data() {
    return {
      watermarkWrapperId: genRandomId('water-mark-wrapper')
    }
  },
  computed: {
    ...mapGetters(['userinfo']),
    styles() {
      const watermarkInfoArr = this.userinfo.watermarkInfo
        ? this.userinfo.watermarkInfo.split(',')
        : []
      const infoEnum = [
        '',
        this.userinfo.partyName,
        this.userinfo.name,
        getToday()
      ]
      const m = watermarkInfoArr.map((val) => infoEnum[+val])
      const text = m.join(' | ')
      const url = getCanvasUrl(text)
      return {
        position: 'absolute',
        left: 0,
        right: 0,
        top: 0,
        bottom: 0,
        opacity: 0.7,
        zIndex: 9999,
        pointerEvents: 'none',
        overflow: 'hidden',
        backgroundImage: `url("${url}")`,
        backgroundColor: 'transparent',
        backgroundRepeat: 'repeat'
      }
    }
  }
}
</script>

<style lang="scss" scoped>
.water-mark-wrapper {
  pointer-events: none;
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 99%;
  z-index: 10000;
}
</style>
