const defaultOptions = {
  chunkWidth: 500,
  chunkHeight: 200,
  textAlign: 'left',
  textBaseline: 'bottom',
  globalAlpha: 0.17,
  font: '14px Microsoft Yahei',
  rotateAngle: -0.26,
  fillStyle: '#666'
}

export function getToday() {
  const current = new Date()
  const year = current.getFullYear()
  const month = current.getMonth() + 1
  const day = current.getDate()
  return `${year}-${month}-${day}`
}

export function getCanvasUrl(text) {
  const newOptions = Object.assign({}, defaultOptions, {})
  return getWaterMarkCanvas(text, newOptions)
}

export function getWaterMarkCanvas(text, options) {
  const canvas = document.createElement('canvas')
  const ctx = canvas.getContext('2d')
  const canvasWidth = 4000
  const canvasHeight = 4000
  canvas.width = canvasWidth
  canvas.height = canvasHeight
  ctx.textAlign = options.textAlign
  ctx.textBaseline = options.textBaseline
  ctx.globalAlpha = options.globalAlpha
  ctx.font = options.font

  ctx.translate(canvasWidth / 2, canvasHeight / 2)
  ctx.rotate(options.rotateAngle)

  ctx.translate((-canvasWidth / 2) * 1.2, (-canvasHeight / 2) * 1.2)
  ctx.fillStyle = options.fillStyle

  const waterMarkText = []
  const chunkWidth = options.chunkWidth
  const chunkHeight = options.chunkHeight
  const horizontalChunkCount = Math.ceil(canvasWidth / chunkWidth) + 1
  const verticalChunkCount = Math.ceil(canvasHeight / chunkHeight) + 1

  for (
    let j = 0, initY = chunkHeight / 2, indent = 0;
    j <= verticalChunkCount;
    j += 1
  ) {
    indent = parseInt(j % 2, 0)

    for (let i = 0, initX = chunkWidth / 2; i <= horizontalChunkCount; i += 1) {
      waterMarkText.push({
        text,
        x: i * chunkWidth + indent * initX,
        y: j * chunkHeight + initY
      })
    }
  }

  waterMarkText.forEach((item) => {
    ctx.fillText(item.text, item.x, item.y)
  })

  return ctx.canvas.toDataURL()
}

export function encrypt(str) {
  return window.btoa(decodeURI(encodeURIComponent(str)))
}
export function genRandomId(prefix = '') {
  return `${encrypt(prefix)}-${new Date().getTime()}-${Math.floor(
    Math.random() * 100000000
  )}`
}
