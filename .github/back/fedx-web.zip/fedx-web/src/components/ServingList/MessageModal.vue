<template>
  <el-dialog
    :visible.sync="dialogVisible"
    :close-on-click-modal="false"
    :title="`${actionText}服务`"
    width="600px"
    top="10vh"
    @close="handleClose"
  >
    <div class="content">
      <div>
        <p class="service-desc title">{{ tempaletObj.title[0] }}：{{ serveItem.serviceName }}</p>
        <p class="service-desc">{{ tempaletObj.title[1] }}：{{ serveItem.serviceId }}</p>
        <p
          v-if="action === 4"
          class="service-desc"
        >{{ tempaletObj.title[2] }}：{{ serveItem.servingAddress }}
          <CopyAddress :text="serveItem.servingAddress" />
        </p>
      </div>
      <!-- 上线/下线服务 -->
      <p
        v-if="[1,2,3].includes(action)"
        class="tips-message"
      >{{ `确定要${actionText}该${tempaletObj.title[3]}吗？` }}</p>
      <!-- 测试服务 -->
      <div v-else-if="action === 4">
        <div class="request-box">
          <h3>{{ tempaletObj.title[4] }}：</h3>
          <b-ace-editor
            v-if="requestStr"
            ref="editor1"
            v-model="requestStr"
            :line-wrap="false"
            :auto-format="true"
            :smart-indent="true"
            :indent-unit="2"
            theme="chrome"
            height="200"
          >
          </b-ace-editor>
        </div>
        <div class="request-btn-box">
          <el-button
            type="primary"
            size="mini"
            @click="verify"
          >测试</el-button>
        </div>
        <div class="response-box">
          <h3>{{ tempaletObj.title[5] }}：</h3>
          <b-ace-editor
            ref="editor2"
            v-model="responseStr"
            :line-wrap="false"
            :auto-format="true"
            :smart-indent="true"
            :indent-unit="2"
            :readonly="true"
            theme="chrome"
            height="200"
          >
          </b-ace-editor>
        </div>
      </div>
    </div>
    <span
      v-if="action < 4"
      slot="footer"
      class="dialog-footer"
    >
      <el-button
        size="small"
        @click="dialogVisible = false"
      >取 消</el-button>
      <el-button
        size="small"
        type="primary"
        @click="onSubmit"
      >确 定</el-button>
    </span>
    <div
      v-else
      slot="footer"
      class="dialog-test-footer"
    >
      <el-button
        size="small"
        @click="handleClose"
      >关 闭</el-button>
    </div>
  </el-dialog>
</template>

<script>
import CopyAddress from '../CopyAddress'
import { templateInfo } from './templateInfo'
export default {
  name: 'MessageModal',
  components: { CopyAddress },
  data() {
    return {
      tempaletObj: {
        title: ['', '', '', '', '', '']
      },
      action: 1,
      serveItem: {},
      requestStr: '',
      responseStr: '',
      dialogVisible: false,
      ruleForm: {
        num: 1
      },
      module: 0 // 弹框类型：0模型服务；1匿踪查询单条2匿踪查询批量
    }
  },
  computed: {
    actionText() {
      if (this.action === 1) return '上线'
      if (this.action === 2) return '下线'
      if (this.action === 3) return '删除'
      if (this.action === 4) return '测试'
      return '-'
    }
  },
  methods: {
    async show({ action, item, module }) {
      this.module = module
      this.tempaletObj = templateInfo[this.module]
      this.action = action
      this.serveItem = item
      this.dialogVisible = true
      // 分情况获取请求信息
      if (this.action === 4) {
        if (!this.module) {
          const res = await this.tempaletObj.getRequest({
            id: this.serveItem.id
          })
          if (res.retcode === 0) {
            this.requestStr = JSON.stringify(res.data, null, '\t')
          }
        } else {
          const rAray = this.serveItem.columnIn.split(',')
          const rObj = {}
          rAray.map((item) => {
            rObj[item] = Math.round(Math.random() * 100000000).toString()
          })
          const params = {
            resource: 1,
            queryData: this.module === 1 ? rObj : [rObj]
          }
          this.requestStr = JSON.stringify(params, null, '\t')
        }
      }
    },
    handleClose() {
      this.requestStr = ''
      this.responseStr = ''
      this.dialogVisible = false
    },
    async onSubmit() {
      const { action, serveItem } = this
      let res = {}
      if (this.action === 1) {
        res = await this.tempaletObj.online({
          id: serveItem.id,
          opType: action
        })
      } else if (this.action === 2) {
        res = await this.tempaletObj.offline({
          id: serveItem.id,
          opType: action
        })
      }

      if (res.retcode === 0) {
        this.$message.success('操作成功')
        this.$emit('callback')
        this.dialogVisible = false
      }
    },
    verify() {
      try {
        const requestJson = JSON.parse(this.requestStr)
        const url = this.serveItem.servingAddress || ''
        this.tempaletObj.getRespones(requestJson, url).then((res) => {
          if (res.retcode === 0) {
            this.responseStr = JSON.stringify(res.data, null, '\t')
            this.$emit('callback')
          }
        })
      } catch (e) {
        this.$message.error('请求参数错误')
      }
    }
  }
}
</script>

<style lang="scss" scoped>
.content {
  padding: 0 20px;
  .service-desc {
    flex: 1;
    line-height: 32px;
    color: rgba(0, 0, 0, 0.85);
    font-size: 14px;
    &.title {
      font-size: 16px;
      font-weight: bold;
    }
  }
  .tips-message {
    margin-top: 20px;
    font-size: 16px;
    font-weight: 500;
    color: rgba(0, 0, 0, 0.85);
  }
  /deep/ .el-input-number .el-input__inner {
    text-align: center !important;
  }
  .response-box,
  .request-box {
    h3 {
      color: #172b4d;
      font-size: 16px;
      margin-bottom: 10px;
    }
  }
  .request-btn-box {
    text-align: center;
    margin: 20px auto 0;
  }
}
.dialog-test-footer {
  text-align: center;
}
</style>
