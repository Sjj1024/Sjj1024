import { servingApi } from '@/api/modelServing'
import hidingTracesApi from '@/api/hidenTraces'
export const templateInfo = [
  {
    title: ['服务', '服务ID', '服务地址', '模型服务', '请求信息', '返回结果'],
    getRequest: servingApi.getParams,
    online: servingApi.oprateServing,
    offline: servingApi.oprateServing,
    getRespones: servingApi.verifyServing
  },
  {
    title: ['服务', '服务ID', '服务地址（单条）', '匿踪查询服务', '请求信息（单条）', '返回结果'],
    getRequest: () => { },
    online: hidingTracesApi.onlineHiden,
    offline: hidingTracesApi.offlineHiden,
    getRespones: hidingTracesApi.verifyHiden
  },
  {
    title: ['服务', '服务ID', '服务地址（批量）', '匿踪查询服务', '请求信息（批量）', '返回结果'],
    getRequest: () => { },
    online: hidingTracesApi.onlineHiden,
    offline: hidingTracesApi.offlineHiden,
    getRespones: hidingTracesApi.verifyHiden
  }
]
