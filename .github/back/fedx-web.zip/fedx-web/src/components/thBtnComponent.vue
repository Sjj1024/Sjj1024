<template>
  <el-button
    v-bind="$attrs"
    size="small"
    v-on="evet"
  >
    <slot></slot>
  </el-button>
</template>
<script>
/* eslint-disable */
export default {
  name: 'Thbtn',
  data() {
    return {
      timer: null
    }
  },
  computed: {
    evet() {
      if (this.$listeners.click) {
        this.$listeners.click = this.throat('click')
      }
      return this.$listeners
    },
    disabled() {
      if (this.timer) {
        return true
      } else {
        return false
      }
    }
  },
  methods: {
    throat(method) {
      const me = this
      return (...args) => {
        if (!me.timer) {
          me.$emit(method, ...args)
          me.timer = setTimeout(() => {
            me.timer = null
          }, me.$attrs.throat || 1000) // 默认1s的，节流
        } else {
          me.$emit('droped', ...args) // 点击太频繁的事件提示
        }
      }
    }
  }
}
</script>
