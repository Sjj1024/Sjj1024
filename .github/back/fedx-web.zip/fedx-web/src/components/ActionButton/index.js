import ActionComponent from './action.vue'

const action = {
  install: function(Vue) {
    Vue.component('ActionBtn', ActionComponent)
  }
}

export default action
