<template>
  <div>
    <!-- <slot v-if="list.length < 2"></slot> -->
    <el-dropdown :hide-timeout="time" :show-timeout="100" size="small">
      <span class="action-dian">
        <i class="el-icon-dian"></i>
      </span>
      <el-dropdown-menu slot="dropdown">
        <el-dropdown-item>
          <div class="dropdow-list">
            <slot></slot>
          </div>
        </el-dropdown-item>
      </el-dropdown-menu>
    </el-dropdown>
  </div>
</template>

<script>
import _ from 'lodash'
export default {
  name: 'ActionBtns',
  data() {
    return {
      list: [],
      time: 350
    }
  },
  mounted() {
    const filterList = this.$slots.default.filter(item => item.tag)
    this.list = filterList
  },
  updated() {
    const filterList = this.$slots.default.filter(item => item.tag)
    if (!_.isEqual(filterList, this.list)) {
      this.list = filterList
    }
  },
  methods: {
    isComponent(vnode) {
      const isComponent = vnode.componentOptions
      return !!isComponent
    }
  }
}
</script>

<style lang="scss">
@import '@/reset.var.scss';

.action-dian {
  font-size: 24px;
  cursor: pointer;
  color: $--color-primary;
}
.action-dian:hover {
  color: $--color-hover-primary;
}
.el-dropdown-menu .el-dropdown-menu__item {
  &:hover {
    background-color: transparent;
    & > .dropdow-list {
    .el-button:hover{
      background-color: $--color-primary !important;
      color: #fff;
    }
  }
  }
  & > .dropdow-list {
    .el-button {
      display: block !important;
      text-align: center;
      width: 100%;
      padding: 8px 5px;
    }
    .el-button+.el-button{
      margin: 0;
    }
  }
}
</style>
