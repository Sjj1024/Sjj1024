import user from './user'
import projects from './project'
import jobs from './job'

export default [
  ...user,
  ...projects,
  ...jobs
]

