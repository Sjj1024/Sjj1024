#!/bin/bash

times=$(date +"%Y%m%d-%H%M%S")
# 获取参数
content="fedx-web: release/v1.3.7"

# 设置请求参数
url="https://qyapi.weixin.qq.com/cgi-bin/webhook/send?key=89c9eedd-31db-4e36-bbb3-6176ed9b4395"
data='{
        "msgtype": "text",
        "text": {
            "content": "'"【 ${content} 】,开始构建! ${times}"'"
        }
    }'

# 发送POST请求
response=$(curl -s -X POST -H "Content-Type: application/json" -d "$data" "$url")

# 处理响应
if [[ "$response" ]]; then
  echo "success!"
else
  echo "failed!"
fi
