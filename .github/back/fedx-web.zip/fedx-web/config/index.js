'use strict'
// Template version: 1.2.6
// see http://vuejs-templates.github.io/webpack for documentation.

const path = require('path')
const { target } = require('./dev.env')

module.exports = {
  dev: {
    // Paths
    assetsSubDirectory: 'static',
    assetsPublicPath: '/',
    proxyTable: {
      '/fl_portal': {
        target: 'http://172.20.60.30:31000',
        changeOrigin: true
      },
      '/fedx-api/ws': {
        target: 'ws://172.20.60.30:31000', // 后端目标接口地址
        changeOrigin: true, // 是否允许跨域
        ws: true // 开启ws, 如果是http代理此处可以不用设置
      },
      '/fedx-api': {
        target: 'http://172.20.60.30:31000/fedx-api',
        // target: 'http://192.168.110.130:8083', // 李兴文本地
        changeOrigin: true,
        pathRewrite: {
          '^/fedx-api': ''
        }
      },
      '/fl_fate': {
        target: 'http://172.20.60.30:31000',
        changeOrigin: true
        // pathRewrite: {
        //   '^/fl_fate': ''
        // }
      },
      '/v1': {
        target: 'http://172.20.60.30:32039/v1',
        changeOrigin: true
        // pathRewrite: {
        //   '^/fl_fate': ''
        // }
      },
      '/fl_api': {
        target: 'http://172.20.60.30:31000',
        changeOrigin: true
        // pathRewrite: {
        //   '^/fl_fate': ''
        // }
      },
      '/newapi': {
        target: 'http://172.20.60.30:31000',
        changeOrigin: true,
        pathRewrite: {
          '^/newapi': ''
        }
      },
      '/fate-serving/api': {
        target: 'http://172.20.60.30:31000',
        changeOrigin: true
        // pathRewrite: {
        //   '^/fl_fate': ''
        // }
      },
      // '/websocket': {
      //   target: 'ws://172.20.60.30:31000',//后端目标接口地址
      //   changeOrigin: true,//是否允许跨域
      //   ws: true //开启ws, 如果是http代理此处可以不用设置
      // },
      // '/log': {
      //   target: 'ws://172.20.60.30:31000',//后端目标接口地址
      //   changeOrigin: true,//是否允许跨域
      //   ws: true //开启ws, 如果是http代理此处可以不用设置
      // },
      '/fate': {
        target: 'ws://172.20.60.30:31000', // 后端目标接口地址
        changeOrigin: true, // 是否允许跨域
        ws: true // 开启ws, 如果是http代理此处可以不用设置
      },
      '/grafana': {
        target: 'http://172.20.60.30:31170',
        // target: 'http://172.20.60.30:32170',
        changeOrigin: true, // 是否允许跨域
        pathRewrite: {
          '^/grafana': ''
        }
      }
    },
    // Various Dev Server settings
    host: 'localhost', // can be overwritten by process.env.HOST
    port: 8028, // can be overwritten by process.env.PORT, if port is in use, a free one will be determined
    autoOpenBrowser: true,
    errorOverlay: true,
    notifyOnErrors: false,
    poll: false, // https://webpack.js.org/configuration/dev-server/#devserver-watchoptions-

    // Use Eslint Loader?
    // If true, your code will be linted during bundling and
    // linting errors and warnings will be shown in the console.
    useEslint: true,
    // If true, eslint errors and warnings will also be shown in the error overlay
    // in the browser.
    showEslintErrorsInOverlay: false,

    /**
     * Source Maps
     */

    // https://webpack.js.org/configuration/devtool/#development
    devtool: 'source-map',

    // CSS Sourcemaps off by default because relative paths are "buggy"
    // with this option, according to the CSS-Loader README
    // (https://github.com/webpack/css-loader#sourcemaps)
    // In our experience, they generally work as expected,
    // just be aware of this issue when enabling this option.
    cssSourceMap: false
  },

  build: {
    // Template for index.html
    index: path.resolve(__dirname, '../dist/index.html'),

    // Paths
    assetsRoot: path.resolve(__dirname, '../dist'),
    assetsSubDirectory: 'static',

    /**
     * You can set by youself according to actual condition
     * You will need to set this if you plan to deploy your site under a sub path,
     * for example GitHub pages. If you plan to deploy your site to https://foo.github.io/bar/,
     * then assetsPublicPath should be set to "/bar/".
     * In most cases please use '/' !!!
     */
    assetsPublicPath: '/',

    /**
     * Source Maps
     */

    productionSourceMap: false,
    // https://webpack.js.org/configuration/devtool/#production
    devtool: 'source-map',

    // Gzip off by default as many popular static hosts such as
    // Surge or Netlify already gzip all static assets for you.
    // Before setting to `true`, make sure to:
    // npm install --save-dev compression-webpack-plugin
    productionGzip: false,
    productionGzipExtensions: ['js', 'css'],

    // Run the build command with an extra argument to
    // View the bundle analyzer report after build finishes:
    // `npm run build --report`
    // Set to `true` or `false` to always turn it on or off
    bundleAnalyzerReport: process.env.npm_config_report || false,

    // `npm run build:prod --generate_report`
    generateAnalyzerReport: process.env.npm_config_generate_report || false
  }
}
