'use strict'
// const baseUrl = window.location.origin
// const baseWsUrl = baseUrl.replace(/http|https/g, 'ws')
module.exports = {
  NODE_ENV: '"production"',
  VUE_APP_MICRO_SUB01: '"http://localhost:8040/"',
  VUE_APP_MICRO_SUB02: '"/custom-fedx-web/"'
  // BASE_API: '',
  // BASE_API: baseUrl,
  // WEBSOCKET_BASE_API: ''
  // WEBSOCKET_BASE_API: baseWsUrl
}
