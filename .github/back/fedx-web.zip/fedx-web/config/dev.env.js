'use strict'
const merge = require('webpack-merge')
const prodEnv = require('./prod.env')

module.exports = merge(prodEnv, {
  NODE_ENV: '"development"',
  VUE_APP_MICRO_SUB01: '"http://localhost:8040/"',
  VUE_APP_MICRO_SUB02: '"http://localhost:8050/"'
  // BASE_API: '',
  // WEBSOCKET_BASE_API: ''
})
